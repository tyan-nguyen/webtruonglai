-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th3 07, 2024 lúc 03:46 PM
-- Phiên bản máy phục vụ: 8.0.31
-- Phiên bản PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `fulladmin_nt`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `created_at` int DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', 1, 1556454369),
('bientapvien', 1, 1570155479),
('Default', 1, 1556454369),
('thongketruycap', 1, 1687142184);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `type` int NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `rule_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  `group_code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/admin/*', 3, NULL, NULL, NULL, 1555604426, 1555604426, NULL),
('/admin/catelogies/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/default/*', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/default/index', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/links/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/del-folder-not-used', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/thong-ke-truy-cap/*', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/bulk-delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/create', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/index', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/update', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/view', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/page/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/about-us', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/captcha', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/contact', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/*', 3, NULL, NULL, NULL, 1555604424, 1555604424, NULL),
('/site/cat', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/index', 3, NULL, NULL, NULL, 1555604425, 1555604425, NULL),
('/site/news', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/newsletter', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/not-found', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/search', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1426062189, 1426062189, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('bientapvien', 1, 'Biên tập viên', NULL, NULL, 1570120917, 1570120917, NULL),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('cauhinh', 2, 'Cấu hình', NULL, NULL, 1570156160, 1570156160, 'userCommonPermissions'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1426062189, 1426062189, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1426062188, 1426062188, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('dangtin', 2, 'Đăng tin', NULL, NULL, 1570156034, 1570156034, 'userCommonPermissions'),
('Default', 1, 'Default', NULL, NULL, 1555604497, 1555604497, NULL),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('duyettin', 1, 'Duyệt tin', NULL, NULL, 1570120962, 1570120962, NULL),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('per_dashboard', 2, 'Access Dashboard', NULL, NULL, 1664291118, 1664291118, 'userManagement'),
('permission_thongketruycap', 2, 'Thống kê truy cập', NULL, NULL, 1586086798, 1586086798, 'userCommonPermissions'),
('qltaikhoan', 2, 'Quản lý tài khoản', NULL, NULL, 1570156229, 1570156229, 'userManagement'),
('thongketruycap', 1, 'Thống kê truy cập', NULL, NULL, 1586086766, 1586086766, NULL),
('truycaptrangadmin', 2, 'Truy cập trang admin', NULL, NULL, 1570121444, 1570121444, 'userCommonPermissions'),
('user-default', 2, 'user-default', NULL, NULL, 1555604419, 1555604419, 'userCommonPermissions'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1426062189, 1426062189, 'userManagement');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `child` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('per_dashboard', '/admin/*'),
('per_dashboard', '/admin/catelogies/*'),
('per_dashboard', '/admin/default/*'),
('truycaptrangadmin', '/admin/default/*'),
('user-default', '/admin/default/*'),
('user-default', '/admin/default/index'),
('per_dashboard', '/admin/links/*'),
('per_dashboard', '/admin/news/*'),
('per_dashboard', '/admin/settings/*'),
('per_dashboard', '/admin/socials/*'),
('per_dashboard', '/admin/thong-ke-truy-cap/*'),
('permission_thongketruycap', '/admin/thong-ke-truy-cap/*'),
('user-default', '/site/*'),
('qltaikhoan', '/user-management/*'),
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('viewVisitLog', '/user-management/user-visit-log/grid-page-size'),
('viewVisitLog', '/user-management/user-visit-log/index'),
('viewVisitLog', '/user-management/user-visit-log/view'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'cauhinh'),
('Admin', 'changeOwnPassword'),
('bientapvien', 'changeOwnPassword'),
('duyettin', 'changeOwnPassword'),
('user-default', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'dangtin'),
('bientapvien', 'dangtin'),
('duyettin', 'dangtin'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('bientapvien', 'per_dashboard'),
('thongketruycap', 'permission_thongketruycap'),
('Admin', 'qltaikhoan'),
('Default', 'thongketruycap'),
('Admin', 'truycaptrangadmin'),
('bientapvien', 'truycaptrangadmin'),
('Default', 'truycaptrangadmin'),
('duyettin', 'truycaptrangadmin'),
('Admin', 'user-default'),
('bientapvien', 'user-default'),
('Default', 'user-default'),
('duyettin', 'user-default'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1426062189, 1426062189),
('userManagement', 'User management', 1426062189, 1426062189);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` int DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE IF NOT EXISTS `blocks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `links`
--

DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `link` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `link_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `open_new_tab` tinyint(1) NOT NULL,
  `pid` int DEFAULT NULL,
  `priority` tinyint(1) NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lang` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `links`
--

INSERT INTO `links` (`id`, `name`, `name_en`, `link`, `link_en`, `open_new_tab`, `pid`, `priority`, `type`, `lang`) VALUES
(1, 'Trang chủ', '', '/', '', 0, 0, 1, 'MENU_TOP', 'vi'),
(2, 'Thông tin chung ', '', '#', '', 0, 0, 2, 'MENU_TOP', 'vi'),
(3, 'Lĩnh vực hoạt động', '', '#', '', 0, 0, 3, 'MENU_TOP', 'vi'),
(5, 'Tin tức', '', '#', '', 0, 0, 4, 'MENU_TOP', 'vi'),
(6, 'Tuyển dụng', '', '/posts/tuyen-dung', '', 0, 0, 1, 'QUICK_LINK', 'vi'),
(7, 'Liên hệ', '', '/contact', '', 0, 0, 2, 'QUICK_LINK', 'vi'),
(8, 'Hồ sơ năng lực', '', '/post/ho-so-nang-luc', '', 0, 0, 3, 'QUICK_LINK', 'vi'),
(12, '<i class=\"fab fa-facebook-f\" style=\'font-size:16px\'></i>', '', 'https://www.facebook.com/profile.php?id=100094631493232', '', 1, 0, 1, 'SOCIAL_LINK', 'vi'),
(19, 'Tuyển dụng', '', '/posts/tuyen-dung', '', 0, 0, 5, 'MENU_TOP', 'vi'),
(20, 'Liên hệ', '', '/contact', '', 0, 0, 6, 'MENU_TOP', 'vi'),
(21, 'Thư ngõ', '', '/post/thu-ngo', '', 0, 2, 1, 'MENU_TOP', 'vi'),
(23, 'Hồ sơ năng lực', '', '/post/ho-so-nang-luc', '', 0, 2, 2, 'MENU_TOP', 'vi'),
(24, 'Thành viên của chúng tôi', '', '/post/thanh-vien-cua-chung-toi', '', 0, 2, 3, 'MENU_TOP', 'vi'),
(27, 'Vật liệu xây dựng - Trang trí nội thất', '', '/post/vat-lieu-xay-dung-trang-tri-noi-that', '', 0, 3, 5, 'MENU_TOP', 'vi'),
(28, 'Gạch không nung', '', '/post/gach-khong-nung', '', 0, 3, 4, 'MENU_TOP', 'vi'),
(29, 'Cửa nhôm', '', '/post/cua-nhom', 'https://cua.nguyentrinh.com', 1, 3, 3, 'MENU_TOP', 'vi'),
(30, 'Đào tạo và sát hạch lái xe', '', '/post/dao-tao-sat-hach-lai-xe', '', 0, 3, 6, 'MENU_TOP', 'vi'),
(31, 'Hoạt động doanh nghiệp', '', '/posts/hoat-dong-doanh-nghiep', '', 0, 5, 1, 'MENU_TOP', 'vi'),
(32, 'Công bố thông tin', '', '/posts/cong-bo-thong-tin', '', 0, 5, 2, 'MENU_TOP', 'vi'),
(46, 'Về chúng tôi', '', '/post/thu-ngo', '', 0, 0, 1, 'FOOTER_LINK', 'vi'),
(47, 'Tuyển dụng', '', '/posts/tuyen-dung', '', 0, 0, 3, 'FOOTER_LINK', 'vi'),
(49, 'Liên hệ', '', '/contact', '', 0, 0, 2, 'FOOTER_LINK', 'vi'),
(50, 'Sơ đồ tổ chức', '', '/post/so-do-to-chuc', '', 0, 2, 4, 'MENU_TOP', 'vi'),
(51, 'Chứng nhận, chứng chỉ, giấy phép', '', '/post/chung-nhan-chung-chi', '', 0, 2, 7, 'MENU_TOP', 'vi'),
(52, 'Vận tải hàng hóa', '', '/post/van-tai-hang-hoa', '', 0, 3, 4, 'MENU_TOP', 'vi'),
(53, 'Bê tông', '', '/post/be-tong', '', 0, 3, 8, 'MENU_TOP', 'vi'),
(54, 'Bê tông tươi', '', '/post/be-tong-tuoi', '', 0, 53, 1, 'MENU_TOP', 'vi'),
(55, 'Cống bê tông ly tâm', '', '/post/cong-be-tong', '', 0, 53, 2, 'MENU_TOP', 'vi'),
(56, 'Cọc bê tông ly tâm', '', '/post/coc-be-tong', '', 0, 53, 3, 'MENU_TOP', 'vi'),
(57, 'Bê tông nhựa nóng', '', '/post/be-tong-nhua-nong', '', 0, 53, 4, 'MENU_TOP', 'vi'),
(58, 'Sản xuất điện', '', '/post/san-xuat-dien', '', 0, 3, 7, 'MENU_TOP', 'vi'),
(59, 'Ép cọc công trình', '', '/post/ep-coc', '', 0, 3, 8, 'MENU_TOP', 'vi'),
(61, '<i class=\'fab fa-facebook-messenger\' style=\'font-size:16px\'></i>', '', 'https://www.facebook.com/messages/t/109789528842656', '', 1, 0, 2, 'SOCIAL_LINK', 'vi'),
(66, '&nbsp;<img src=\"/images/icons/zalo.png\" width=\"18px\" height=\"\" style=\"padding-bottom: 4px\">', '', 'https://zalo.me/', '', 1, 0, 3, 'SOCIAL_LINK', 'vi'),
(67, '<i class=\'fab fa-youtube\' style=\'font-size:16px\' ></i>', '', 'https://www.youtube.com/@NguyenTrinhGroup', '', 1, 0, 4, 'SOCIAL_LINK', 'vi');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `apply_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1480859869),
('m140209_132017_init', 1480859873),
('m140403_174025_create_account_table', 1480859874),
('m140504_113157_update_tables', 1480859876),
('m140504_130429_create_token_table', 1480859876),
('m140506_102106_rbac_init', 1480867652),
('m140830_171933_fix_ip_field', 1480859877),
('m140830_172703_change_account_table_name', 1480859877),
('m141222_110026_update_ip_field', 1480859877),
('m141222_135246_alter_username_length', 1480859877),
('m150425_012013_init', 1570158165),
('m150425_082737_redirects', 1570158165),
('m150614_103145_update_social_account_table', 1480859878),
('m150623_212711_fix_username_notnull', 1480859878),
('m151218_234654_add_timezone_to_profile', 1480859878);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `site` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `site`, `date_created`) VALUES
(16, 'thaipn@bachthuanan.com', 'localhost', '2023-09-19 14:09:04'),
(17, 'bouongsting@gmail.com', 'localhost', '2023-09-27 15:09:24');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `news_catelogies`
--

DROP TABLE IF EXISTS `news_catelogies`;
CREATE TABLE IF NOT EXISTS `news_catelogies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cover` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `pid` int DEFAULT NULL,
  `priority` tinyint DEFAULT NULL,
  `level` tinyint DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `seo_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `seo_image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lang` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `code` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `news_catelogies`
--

INSERT INTO `news_catelogies` (`id`, `cover`, `name`, `slug`, `pid`, `priority`, `level`, `description`, `content`, `seo_title`, `seo_description`, `seo_image`, `lang`, `code`, `status`, `post_type`, `date_created`, `user_created`) VALUES
(1, NULL, 'Hoạt động doanh nghiệp', 'hoat-dong-doanh-nghiep', 0, 1, 1, '', NULL, '', '', NULL, 'vi', '44dnvz', 'PUBLISH', 'POST', '2024-02-24 09:42:32', 1),
(2, '/images/posts/_categories/88chbn/banner3.jpg', 'Công bố thông tin', 'cong-bo-thong-tin', 0, 2, 1, '', '<p><img src=\"/images/posts/_categories/88chbn/bg_fact.png\" alt=\"bg_fact\" /></p>', '', '', '', 'vi', '88chbn', 'PUBLISH', 'POST', '2024-03-05 08:36:34', 1),
(3, NULL, 'Tuyển dụng', 'tuyen-dung', 0, 3, 1, 'Tuyển dụng nhân lực', NULL, '', '', NULL, 'vi', '57bdsp', 'PUBLISH', 'POST', '2024-03-05 10:48:25', 1),
(5, '', 'Quyết định', 'quyet-dinh', 0, 5, 1, '', '', '', '', '', 'vi', '81shwj', 'PUBLISH', 'POST', '2024-03-06 16:31:31', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `input_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `options`
--

INSERT INTO `options` (`id`, `group_type`, `name`, `value`, `input_type`) VALUES
(1, 'SETTING', 'site_name', 'DNTN SX-TM Nguyễn Trình', 'text'),
(2, 'SETTING', 'site_logo', '/ntweb/images/logo.png', 'image'),
(3, 'SETTING', 'site_logo_white', '/ntweb/images/footer-logo.png', 'image'),
(4, 'SETTING', 'site_copyright', 'Copyright © 2024 DNTN Sản xuất - Thương mại Nguyễn Trình. All rights reserved.', 'text'),
(5, 'SETTING', 'site_copyright', '<span>Copyright &copy; <script>\r\n              document.write(new Date().getFullYear()) \r\n            </script> </span> DNTN Sản xuất - Thương mại Nguyễn Trình. All rights reserved.', 'text'),
(6, 'SETTING', 'site_description', 'DNTN Sản xuất - Thương mại Nguyễn Trình', 'text'),
(7, 'SETTING', 'site_hotline', '0903336470', 'text'),
(8, 'SETTING', 'site_email', 'nguyentrinh@gmail.com', 'text'),
(9, 'SETTING', 'site_mst', '2100236683', 'text'),
(10, 'SETTING', 'site_address', 'Đường Nguyễn Đáng, Khóm 10, Phường 9, TP. Trà Vinh', 'text'),
(11, 'SETTING', 'site_hotline_text', '090.333.6470', 'text'),
(12, 'SETTING', 'site_seo_title', 'Doanh nghiệp tư nhân Sản xuất - Thương mại Nguyễn Trình', 'TEXT'),
(13, 'SETTING', 'site_seo_description', 'Website chính thức của DNTN SX-TM Nguyễn Trình', 'TEXT');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pcounter_by_day`
--

DROP TABLE IF EXISTS `pcounter_by_day`;
CREATE TABLE IF NOT EXISTS `pcounter_by_day` (
  `id` int NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `user` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pcounter_by_day`
--

INSERT INTO `pcounter_by_day` (`id`, `day`, `user`) VALUES
(5, '2020-04-04', 10),
(6, '2020-04-03', 15),
(7, '2020-04-02', 10),
(8, '2020-04-05', 1),
(9, '2020-04-07', 0),
(10, '2020-04-08', 1),
(11, '2020-04-09', 1),
(12, '2020-04-11', 0),
(13, '2020-04-12', 1),
(14, '2020-04-13', 1),
(15, '2020-04-14', 1),
(16, '2020-04-15', 1),
(17, '2020-05-11', 0),
(18, '2020-05-18', 0),
(19, '2020-06-07', 0),
(20, '2020-06-08', 1),
(21, '2020-06-24', 0),
(22, '2020-06-25', 1),
(23, '2020-07-08', 0),
(24, '2020-11-02', 0),
(25, '2020-11-03', 1),
(26, '2020-11-04', 1),
(27, '2020-11-05', 1),
(28, '2020-11-08', 0),
(29, '2021-02-24', 0),
(30, '2021-02-26', 0),
(31, '2021-03-08', 0),
(32, '2021-03-09', 1),
(33, '2021-03-10', 1),
(34, '2021-03-11', 1),
(35, '2021-06-03', 0),
(36, '2021-06-04', 1),
(37, '2021-06-05', 1),
(38, '2021-06-06', 1),
(39, '2021-07-11', 0),
(40, '2021-11-16', 0),
(41, '2021-11-18', 0),
(42, '2021-11-21', 0),
(43, '2021-11-22', 1),
(44, '2021-11-23', 1),
(45, '2021-11-24', 1),
(46, '2021-11-25', 1),
(47, '2021-12-01', 0),
(48, '2022-01-19', 0),
(49, '2022-02-07', 0),
(50, '2022-02-10', 0),
(51, '2022-02-11', 1),
(52, '2022-02-12', 1),
(53, '2022-02-13', 1),
(54, '2022-09-12', 0),
(55, '2022-09-17', 0),
(56, '2022-09-18', 1),
(57, '2022-09-23', 0),
(58, '2022-09-24', 1),
(59, '2022-09-25', 1),
(60, '2022-09-26', 1),
(61, '2022-09-27', 2),
(62, '2022-09-28', 1),
(63, '2022-09-30', 0),
(64, '2022-10-01', 1),
(65, '2022-10-04', 0),
(66, '2022-10-05', 1),
(67, '2022-10-06', 1),
(68, '2022-10-07', 1),
(69, '2022-10-09', 0),
(70, '2022-10-27', 0),
(71, '2022-12-18', 0),
(72, '2023-02-15', 0),
(73, '2023-02-16', 1),
(74, '2023-02-18', 0),
(75, '2023-02-19', 1),
(76, '2023-02-20', 1),
(77, '2023-02-21', 1),
(78, '2023-02-22', 1),
(79, '2023-02-23', 1),
(80, '2023-02-25', 0),
(81, '2023-02-26', 1),
(82, '2023-02-27', 1),
(83, '2023-02-28', 1),
(84, '2023-03-01', 1),
(85, '2023-03-13', 0),
(86, '2023-03-15', 0),
(87, '2023-03-16', 1),
(88, '2023-03-17', 2),
(89, '2023-04-06', 0),
(90, '2023-04-08', 0),
(91, '2023-05-02', 0),
(92, '2023-05-04', 0),
(93, '2023-06-13', 0),
(94, '2023-06-18', 0),
(95, '2023-07-17', 0),
(96, '2023-07-19', 0),
(97, '2023-07-21', 0),
(98, '2023-07-31', 0),
(99, '2023-08-02', 0),
(100, '2023-08-06', 0),
(101, '2023-08-09', 0),
(102, '2023-08-13', 0),
(103, '2023-08-17', 0),
(104, '2023-08-23', 0),
(105, '2023-08-26', 0),
(106, '2023-08-27', 1),
(107, '2023-09-05', 0),
(108, '2023-11-20', 0),
(109, '2024-01-07', 0),
(110, '2024-01-08', 1),
(111, '2024-01-09', 1),
(112, '2024-01-11', 0),
(113, '2024-01-12', 1),
(114, '2024-01-14', 0),
(115, '2024-01-16', 0),
(116, '2024-01-23', 0),
(117, '2024-01-30', 0),
(118, '2024-01-31', 1),
(119, '2024-02-01', 1),
(120, '2024-02-04', 0),
(121, '2024-02-19', 0),
(122, '2024-02-20', 1),
(123, '2024-02-22', 0),
(124, '2024-02-27', 0),
(125, '2024-03-03', 0),
(126, '2024-03-04', 2),
(127, '2024-03-05', 1),
(128, '2024-03-06', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pcounter_save`
--

DROP TABLE IF EXISTS `pcounter_save`;
CREATE TABLE IF NOT EXISTS `pcounter_save` (
  `save_name` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `save_value` int UNSIGNED NOT NULL,
  PRIMARY KEY (`save_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pcounter_save`
--

INSERT INTO `pcounter_save` (`save_name`, `save_value`) VALUES
('counter', 79),
('day_time', 2460377),
('max_count', 126),
('max_time', 1585890000),
('yesterday', 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `pcounter_users`
--

DROP TABLE IF EXISTS `pcounter_users`;
CREATE TABLE IF NOT EXISTS `pcounter_users` (
  `user_ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_time` int UNSIGNED NOT NULL,
  PRIMARY KEY (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `pcounter_users`
--

INSERT INTO `pcounter_users` (`user_ip`, `user_time`) VALUES
('057e83ee18065863d52becd6dca0e470', 1709772864);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `cover` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `categories` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `title` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `slug` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `summary_one` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `summary_two` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `content_one` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `seo_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `seo_image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `tags` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `lang` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2010 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `posts`
--

INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `summary_one`, `summary_two`, `content`, `content_one`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1941, '99eqxm', NULL, NULL, 'New Post Title here...', 'new-post-title-here-19', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:16:13', '2024-01-25 09:16:13', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1942, '31rliy', NULL, NULL, 'New Post Title here...', 'new-post-title-here-20', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:17:25', '2024-01-25 09:17:25', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1943, '34izeq', NULL, NULL, 'New Post Title here...', 'new-post-title-here-21', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:17:32', '2024-01-25 09:17:32', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1944, '52pnbu', '', NULL, 'New Post Title here...', 'new-post-title-here-22', '', NULL, NULL, '', NULL, '2024-01-25 09:23:32', '2024-01-31 16:29:24', 1, '', '', '', 'DRAFT', '', 'vi', 'PRODUCT'),
(1946, '92tlyc', NULL, 'yiytiyuiy', 'New Post Title here...', 'new-post-title-here-23', '', NULL, NULL, '', NULL, '2024-01-25 11:00:48', '2024-01-25 11:00:48', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1949, '98xhbg', NULL, NULL, 'New Post Title here...', 'new-post-title-here-25', NULL, NULL, NULL, NULL, NULL, '2024-01-31 14:10:33', '2024-01-31 14:10:33', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'DOCUMENT'),
(1950, '60ioqz', NULL, NULL, 'New Post Title here...', 'new-post-title-here-26', NULL, NULL, NULL, NULL, NULL, '2024-01-31 14:10:40', '2024-01-31 14:10:40', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'en', 'DOCUMENT'),
(1966, '59sexz', '/images/posts/59sexz/tintuc.jpg', 'hoat-dong-doanh-nghiep', '[TIN TỨC] CHÍNH THỨC THÔNG XE QUA CẦU LONG BÌNH 1', 'cau-tam-long-binh-1', 'Sáng ngày 26-7, cầu tạm Long Bình 1 đã được chính thức cho người đi bộ, xe máy, xe đạp, và các loại xe thô sơ lưu thông.', NULL, NULL, '<p style=\"text-align: justify;\">S&aacute;ng ng&agrave;y 26-7, cầu tạm Long B&igrave;nh 1 đ&atilde; được ch&iacute;nh thức cho người đi bộ, xe m&aacute;y, xe đạp, v&agrave; c&aacute;c loại xe th&ocirc; sơ lưu th&ocirc;ng.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/59sexz/caulongbinh1.jpg\" alt=\"caulongbinh1\" width=\"474\" height=\"\" /></p>', NULL, '2023-07-26 07:20:48', '2024-03-07 13:39:14', 1, '', '', '', 'PUBLISH', 'tin-tuc', 'vi', 'POST'),
(1969, '16kqtb', '/images/posts/16kqtb/bg5.jpg', NULL, 'Thi công công trình', 'xxxxxxxxx', 'Đội ngũ kỹ sư giàu kinh nghiệm', 'Với hơn 20 năm kinh nghiệm trong lĩnh vực thi công xây dựng hạ tầng, cầu đường, thảm nhựa', '#fdsaffdsafasfd', '<p>&nbsp;</p>\r\n<div class=\"ddict_btn\" style=\"top: 20px; left: 44.6406px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>', '<p>&nbsp;</p>\r\n<div class=\"ddict_btn\" style=\"top: 29px; left: 51.625px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>', '2024-02-24 22:17:17', '2024-02-26 09:25:31', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'SLIDE'),
(1970, '90zwex', '/images/posts/90zwex/bg4.jpg', NULL, 'Cấu kiện bê tông đúc sẵn', 'new-post-title-here-3', 'Phục vụ đa dạng cho công trình của bạn', '', 'ffffffffff', NULL, NULL, '2024-02-24 22:53:38', '2024-02-26 09:25:26', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SLIDE'),
(1971, '15mbpl', '/images/posts/15mbpl/contruction.png', NULL, 'THI CÔNG XÂY DỰNG HẠ TẦNG - ÉP CỌC', 'new-post-title-here-4', 'Lĩnh vực thi công xây dựng hạ tầng, lĩnh vực cầu đường, thảm nhựa, thi công ép cọc công trình', '/post/ep-coc', NULL, NULL, NULL, '2024-02-24 23:02:33', '2024-03-06 08:58:13', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1972, '88rnwb', '/images/posts/88rnwb/service-icon1.png', NULL, 'CẤU KIỆN BÊ TÔNG ĐÚC SẴN', 'new-post-title-here-5', 'Sản xuất, kinh doanh cấu kiện bê tông đúc sẵn phục vụ đa dạng cho công trình của Quý khách hàng', '/post/coc-be-tong', NULL, NULL, NULL, '2024-02-24 23:04:39', '2024-03-06 08:58:50', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1973, '37owea', '/images/posts/37owea/gach-khong-nung-icon.png', NULL, ' GẠCH KHÔNG NUNG', 'new-post-title-here-6', 'Sản xuất và kinh doanh Gạch không nung theo nhu cầu của Quý khách hàng', '/post/gach-khong-nung', NULL, NULL, NULL, '2024-02-24 23:05:09', '2024-03-06 08:25:20', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1974, '18xvmc', '/images/posts/18xvmc/vlxd.png', NULL, 'VẬT LIỆU XÂY DỰNG - TRANG TRÍ NỘI THẤT', 'new-post-title-here-7', 'Kinh doanh: Gạch men và Granite, gạch bông, gạch kính và thiết bị vệ sinh với giá thành cạnh tranh', '/post/vat-lieu-xay-dung-trang-tri-noi-that', NULL, NULL, NULL, '2024-02-24 23:05:40', '2024-03-06 08:42:48', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1975, '55lnty', '/images/posts/55lnty/door.png', NULL, 'CỬA NHÔM', 'cua-nhom1', 'Thiết kế, sản xuất và lắp đặt cửa nhôm, cam kết bảo hành 10 năm bảo đảm lợi ích tối đa cho khách hàng', 'https://cua.nguyentrinh.com', NULL, NULL, NULL, '2024-02-24 23:06:11', '2024-03-04 15:28:14', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1976, '97vfaj', '/images/posts/97vfaj/driving.png', NULL, 'ĐÀO TẠO VÀ SÁT HẠCH LÁI XE', 'new-post-title-here-9', 'Trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại I chuyên đào tạo và sát hạch nghề lái xe các hạng', '/post/dao-tao-sat-hach-lai-xe', NULL, NULL, NULL, '2024-02-24 23:06:36', '2024-03-07 08:01:41', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1977, '11lhgo', NULL, NULL, 'Thư ngõ', 'thu-ngo', 'Thư ngõ của Chủ DNTN SX-TM Nguyễn Trình.', NULL, NULL, '<p>Lời đ&acirc;̀u ti&ecirc;n, Doanh nghiệp Nguy&ecirc;̃n Tr&igrave;nh xin gửi lời ch&uacute;c sức khoẻ v&agrave; lời ch&agrave;o tr&acirc;n trọng nh&acirc;́t đ&ecirc;́n to&agrave;n thể Qu&yacute; kh&aacute;ch h&agrave;ng.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/HOME.jpg\" alt=\"HOME\" width=\"679\" height=\"\" /></p>\r\n<p>Nguy&ecirc;̃n Tr&igrave;nh được th&agrave;nh lập từ năm 2005, t&iacute;nh đ&ecirc;́n nay Doanh nghiệp đ&atilde; t&ocirc;̀n tại v&agrave; ph&aacute;t triển g&acirc;̀n 20 năm. Hiện nay, Nguy&ecirc;̃n Tr&igrave;nh hoạt động rộng r&atilde;i đa ng&agrave;nh ngh&ecirc;̀ với nhi&ecirc;̀u lĩnh vực. Nhưng ti&ecirc;u biểu nh&acirc;́t l&agrave; lĩnh vực x&acirc;y dựng, ch&uacute;ng t&ocirc;i sở hữu nhi&ecirc;̀u cơ sở với c&aacute;c trang thi&ecirc;́t bị hiện đại c&ugrave;ng đội ngũ th&agrave;nh vi&ecirc;n d&agrave;y dạn kinh nghiệm v&agrave; t&acirc;m huy&ecirc;́t với ngh&ecirc;̀. V&igrave; th&ecirc;́ Nguy&ecirc;̃n Tr&igrave;nh đ&atilde; ph&aacute;t triển nhanh ch&oacute;ng, trở th&agrave;nh Doanh nghiệp uy t&iacute;n, đứng đ&acirc;̀u trong lĩnh vực thi c&ocirc;ng x&acirc;y dựng tại tỉnh Tr&agrave; Vinh.</p>\r\n<p>Với phương ch&acirc;m &ldquo;Uy t&iacute;n, ch&acirc;́t lượng v&agrave; ti&ecirc;́n độ&rdquo;, ch&uacute;ng t&ocirc;i lu&ocirc;n lắng nghe, tận t&igrave;nh tư v&acirc;́n, chia sẻ kinh nghiệm l&agrave;m việc c&ugrave;ng qu&yacute; kh&aacute;ch h&agrave;ng. Đ&ecirc;́n với Nguy&ecirc;̃n Tr&igrave;nh, qu&yacute; kh&aacute;ch h&agrave;ng sẽ thực sự h&agrave;i l&ograve;ng khi nhận được những lời tư v&acirc;́n tận t&igrave;nh nh&acirc;́t của những ki&ecirc;́n tr&uacute;c sư, kỹ sư v&agrave; đội ngũ c&ocirc;ng nh&acirc;n thi c&ocirc;ng l&agrave;nh ngh&ecirc;̀, kh&ocirc;ng những mang gi&aacute; trị thẩm mĩ m&agrave; c&ograve;n đảm bảo ch&acirc;́t lượng kỹ thuật với gi&aacute; cả hợp l&yacute; nh&acirc;́t. Với phương ch&acirc;m v&agrave; t&ocirc;n chỉ l&agrave;m việc đ&oacute;, ch&uacute;ng t&ocirc;i tin tưởng rằng Doanh nghiệp đang d&acirc;̀n trở th&agrave;nh c&ocirc;ng ty Thương mại v&agrave; X&acirc;y dựng ph&aacute;t triển b&ecirc;̀n vững.</p>\r\n<p>C&ugrave;ng với việc &aacute;p dụng c&aacute;c c&ocirc;ng nghệ mới trong x&acirc;y dựng, ch&uacute;ng t&ocirc;i tin tưởng v&agrave; quy&ecirc;́t t&acirc;m ti&ecirc;́p tục mang lại cho Qu&yacute; kh&aacute;ch h&agrave;ng những sản phẩm ch&acirc;́t lượng cao v&agrave; dịch vụ t&ocirc;́t nh&acirc;́t. C&aacute;c c&ocirc;ng tr&igrave;nh thi c&ocirc;ng lu&ocirc;n đảm bảo ch&acirc;́t lượng, an to&agrave;n lao động, trật tự trị an, vệ sinh m&ocirc;i trường để mang lại lợi &iacute;ch t&ocirc;́t nh&acirc;́t cho kh&aacute;ch h&agrave;ng v&agrave; cho x&atilde; hội, xứng đ&aacute;ng với ni&ecirc;̀m tin v&agrave; kỳ vọng của Qu&yacute; kh&aacute;ch h&agrave;ng.</p>\r\n<p>Với mong mu&ocirc;́n ti&ecirc;́p tục mở rộng li&ecirc;n k&ecirc;́t v&agrave; hợp t&aacute;c với c&aacute;c đơn vị, để c&ugrave;ng nhau ph&aacute;t triển v&agrave; chung tay x&acirc;y dựng đ&acirc;́t nước gi&agrave;u mạnh.</p>\r\n<p>Xin ch&acirc;n th&agrave;nh c&aacute;m ơn v&agrave; h&acirc;n hạnh phục vụ Qu&yacute; kh&aacute;ch h&agrave;ng!</p>', NULL, '2024-03-01 14:25:32', '2024-03-05 07:58:41', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1978, '94wxzj', NULL, NULL, 'Hồ sơ năng lực', 'ho-so-nang-luc', '', NULL, NULL, '<p><img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxsAAAEtCAYAAABgYn1QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAE41SURBVHhe7d0FgBTlwwbwZ7auj+NIAQFBKekSEBAwAEElVQRRMfHzbydii4oNioUKigooKYKIIkh3SXdJHnBdG/PNu7zo7uV23fP7vv077+wde7szO/M+M28oqgZEREREREQ+ppP/JSIiIiIi8imGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDSIiIiIi8guGDQobakYGLBs22v9LRERERKFPUTVymShk2c6lIu3anlBPntL2WgX6yxvB0LYNjO3awNCmNXQVK8qfJCIiIqJQwbBBYSHvp+nIevxpWSpMV+cSGK9oC8MVWvjQ/quvUV0+Q0RERETBwrBBYSHni6+Q89obslQ6XbVqMF7VCdEP3g997VpyLREREREFEvtsUESyHTuGvMlTkd53IFSzWa4lIiIiokBi2KCIpqacge3QYVkiIiIiokBi2KDIZ7PJBSIiIiIKJIYNIiIiIiLyC4YNIiIiIiLyC4YNIiIiIiLyC4YNIiIiIiLyC4YNCgv66tXkEhERERGFC4YNCgvGa7rBdOtAwGCQa4iIiIgo1HEGcQoranY2LGvXw7xmLSzisWETkJ8vny1auSULob+ktiwRERERUaAwbFBIU/PyADEDeFwcFEWRa/8jnrds+RuW1VrwWL0GZi2IICtLPgvoLq6BcssXF/m7RFQ01WqFmpEpS4UpRgMQG+vS90oV89xo30nVWvR8N0qUCUpMjCwREVGkYdigkCJ2R+umzcibMQvmJctg23/Avl5JTobpxl6I6t8P+mZNiq3kiEqSdfsO+10P2/ETMA3sD0P9evJZIipN7g9TkfPmaKipaXJN0fSNL0fitMlQ4uLkmsKse/chfeAg+0z+JTG0a4v4Lz6FrnySXENERJGCYYNCgvXAQeTPnI087WE7eEiuLZquziVa6OgLU78+0NeoLtcSkbdEWE9t1hpqWrpcU7KEyd/C2PFKWSos56NPkPP2e7JUsthXXkD0sDtliYiIIgU7iFPQ2M6cQe6Eb5F2Y3+kdb4aOR+MLTVoCOJuR8477yOtfWekD7jVfiXWlp4hnyUiT4mmU64GDUHNzpFLRVNzc+VS6ayHjsglIiKKJAwbFFCij0Xe7DnIuOMepLZqj+wXX4F14yb5rPtEX43sZ0YgtUVbZD7wEPL/+NN+dZaIAqC0G+Oiv4areJOdiCgiMWxQQIhOorlffo3Udp2Q9dCjMP+5CPBlKMjPR/7cX5F5171I69gVeVN+svf/ICL/EYMzFEd8/+yjxRERUZnGsEEBkfvpF8h+ZVSpHUV9wXb0H2Q99SzyJv8o1xCRS9wctU18r3M+/hTm9RtgO3Xa3jTSqn3/8hctRtaTz8KyYqX8SRdwxDgioojEDuIUEOk3D4Zl5SpZCgxjj+5IGP+JLBFRadT8fJyr21CWAiv6oeGIfeZJWSIiokjBOxsUEGpqqlwKnGC8JlE4U0wmIEp7BIGSkCCXiIgokjBsUATjTTsidxlaNJdLgWVo2UIuERFRJGHYICKifxmv7iaXAkdJTIChFcMGEVEkYtggIqJ/iQkzERMjS4ERNegWKEajLBERUSRh2CAion/pKlVE3Og3ZMn/9A0bIOaJx2SJiIgiDUejooBIu64XrDt2ylIpoqNhvLI9DK1aQndRVfvEYGI4TTGBn2XNWsBikT9YMkO7tkj8abIsUTgSQ6mKoVXV0yli4ga5tgh6HQxNmyDq9sFQoqLkSvJGziefIefNd2TJP/QN6iN+wnjoa1SXa4jI36wHDyH38y+hpqfLNcUwGmFsfwVMA/tD0fHaNHmOYYMCIq17b1i375ClwnQX14Dx6q4wdtMe7dtBiS66wqhmZMC8bDnyFy6C+c/F5yuhxTC0u0ILGz/IEoWjrOdeQN53rm/D6If/D7FPPS5L5C3zmnVa4HgblnXr5RrfEH00ooYOQczDD0GJiZZriSgQ0gfdDsuyFbJUurj330aUFjiIPMWwQQGRcfswmBf/JUsavR6Gtm3sAcOkPXR160Bxc1IvMSu5ddt2mLXgIcKHddNm+cx5pr43In7sB7JE4Shj2H0w/75Qlkon7oYlzvpJlshXLJu3IO+HqTD/tQS2f47JtW4ymWBo0xqmnt0RNaAvlLg4+QQRBVJqt+6w7dkrS6Uz9e+L+A/flSUi9zFsUEDkL/gDuV9OgK5mDZi6doGhU0foEn07rr5ocmNe9BfMS5fDdvwEYh59CMYO7eWzFI4y7rzHHiZdpW/aBOXmzpIl8gfx3bJs3wHbyZNQT56yzxwu7jjCarVfAFAMBnvzC9H3Q1elMpTKlaG/+GLoGzVgEzeiEJDa5VrY9u2XpdKZbuyN+HFjZInIfQwbRBSy0vvfAsuadbJUOoYNIqKSnWvd3n6hwFUMG+Qthg0KCjUvz94EyrJlK2zHjsN2SlwhPQX11GnYtIOgmp1tv1Jqfwiic5rBYO/LoVSqBF3lyvarprrK2nLVqtA3bgRDs6ZQYmPP/zwFhC01DZZNm2Hduev8lW6x/cS2PKE9UlIAbTvbt6HNdv4X9Hr7QzShEVe+lQoV7IMA6KpXg75mTS0sNIa+3mVAfj7yZs1B9jMjzv+eixg2iIiKpmZmIm/yj8h+dZRc4xqGDfIWw0aQiEpa9ogXYF6+ErCY5drSKQkJMN08ADGPPexWHwfr3n3Iev4lWLdv/6/i5wLRBCLmfw8iql8fucZz1mPHkD9jNsx/LYVl/QbA7Pr7dokWSPRa4DB27oiovjdBX7eOfCL0qFoF3LJ+o72zu+3AQVgPHYbt+HEgV6uc22TA8hElLh6mPjcg5tmnfDKiiGXjZuTPnWffjiJk+JyYb0GMOObBoUnMQp04e5os+Y71n2PIfnakPViVuH30BuiqXWTvkxA1ZHCxAx2UxrxkGbLfege2w4dd/xyMJvsobrFvvu6zJor5c3+1jwYmLgi4c5wqjdgnDZ2uROwzT9ovGPhC/i/zkDPmY+1vLaVPSXQ0DE0aI/q+uz1uZilOmzlvv2c/nqmZGXJt6ZTkZETfNRTRw+6Ua7wj/g7r7j2wrFhlH2FIvHf7xRst+CNf215W10buK5VOD0PzZoh963Xoq1eTKwMnb8as86PSifflKnE+aNgQcW++FvRzgaqd67JfewP5v/4GiAtprjIY7aMqxmmfu658ebmydLZz55Aljler1vz7vVVt2nFECxueMGnn0/ix78uSe8R5TTRttu7Ze37f1I6loimmmpt7fv/0RRU0Ksre/zPutVc8PuaSfzFsBIk4cOaM9rzDVeLcWfahPl2Vce9wmOcvkCU3RZlQfst6j+8aWDZstPfXEBUXd4KOt8TIVtH3DYNBq1C42/ncX2wnTiJn3KfIn/0LVO2EEEgJU7/zvHKlVf7F/pM7/mv79gxVxq5dkPDtV7LkO1nPPI+8H6bIkmtE8En4boL9AoE7xCE5rcNVsB39R65xjwiVMf/3gCx5Lm/aDGQ99pQs+YeYYyNxzgyv+3KIyty5pq3drkzFPKd9Vg+6/1mJUboy+t8iS+5LWrMMuosukiX3iT4zuV9PhHnxEreaw3gratDNiHv7TVkKDDUnR9u2rc5fiPGAsUd3JIz/RJaCQ4SMzPselCX3RT/6P8Q+8agslS77nfeRO3acLHkv6q47EPfqi7JUOtE6Ifericj/Y6FbHdG9FffOW4i6daAsUSjhwMlBIlK+N8SdCneIq18ey8uH9chRWXCd7XQKMu64B+k3DUD+nLkBDRqC+c9FyLj1dmQMHGS/Mh1Man4+srVwmdqxC/ImTgp40BCse9zbZy6wbNqCtG7dkTn8fyEdNAR9M9cDuDuse93/vorPKkOrYIht7xatUuVp0BC8+q5L9iv3H/m/gibm3rFf7fWSqNx4ctVWzCOS+8NUWXKddY93n7HH30Xt88q4+36kd++N/KnTAho0BE//bm/YRz/zMGgInnx3fc3r872b32nrbt++Z0OTy+VSyUTT2awXX0XqlVch99PPAxo0BG+/l+Q/DBvB4u0NJXcr7l6/nnu/b9nyN9J69LZX+INNTAaYLv4WcUs5CMQt7YxbhiD340/twS1oPAh7eT9OQ3rfgfamXuHA0KKZXPIxD78+Yix7cVfEvRvIXn5Xvf2uayxr18O2/4As+VfeVB8MVezFe85+biTyFzkMy+0KLz9jMWqXu3K/n4z0Xn1gXvCHXBMEAb5gZOf1uSsIf3NBXr8Hd3/fy9crQDShK4153Xr7fFp5E74J2nnOk+8VBQbDBvmcmO07Y9Dt9s7CoUJNTUPG7XfCsmu3XBMYoiN8xmDtdX08KVog5M9fgKwnntFqnj5q9+1nSuVKMHa8UpZCR/60Gcj9YKwshQefBAAXiUDmyZ1Tn9EqKJkPPATLtu1yRegRd5lEnyGf93MjKoW4W6y/7FJZKproe5hx65CQOudTaGHYIJ8SbaczH3wYarrrnSYDJjfPXqmwj3QVINmj3oL1762yFD5EYMx64mlZCg8xjz8CxWSSpdCSo4UNcZcoHIgRa+zNHgMo/6fpcilItGNCxh132wexCDXmFSvtndGJgiHmycflUtFE06nMhx4L7l17CnkMG+RTolOYdeMmWQo9tr377BW/QLDs2IW8Cd/KUnjJfu6F0AyMxYh+5CFE3XarLIWmrKdH2EdlCXX5v/yqpaMcWQoMEcSC3QRC9H/IHHo3bCG034u/JfORJ2WJKLDEYACmLp1lqWjiuKaeOSNLREVj2CCfEe3S8779TpZClxhVSPWiw6Gr8r6ZJJfCixhC07zYzTbswRITg9hRryL2ycdCZsSxYlmt9g7jIoSGskA2obpAdAK2rFgpS8Fj3bXbPmqQ2536/UQ0wVNPnJAlosAQ8x/Ff/axffSxkli2boP594WyRFQ8hg3yGeumLbAFs+21i8QVe9HG1J/EULFibPhwJOYrCBfl5s9B9NDBshQGMjORMXSYfZz5UGTdtz9o/YvypoZGMzPLck869fue/eLNZPdHyiLyVuKMqTD16ilLxcub8qNcIioZwwb5TDh1gvb33yoqbYFuiuIrYiSicGH/nMOMuFIt+geIvhGhJpgV/vx58+2TnYaCUOjUb9252z+TZhKVxoW+b2Ji2vyZs2WJqGQMG+Qz3o4lHkj+/lut23fKpfATCuPSu0o0ewlHYn4J+2AFITS6kP1u3LQgdtTOz0f+z7/IQvAFu1O/dds2uUQUemyHD4dVvz4KLoYN8hl3JxoMJl9PelSQLQTbWSvR0XKpeGpOrnYSOSJLoc+bye+CzfzXUmQ//2LQm+tcYJ+N+nSKLAVHqDXLCGanfl9MzuhzRoNcoLLO3+dQTyhGo1yiUMOwQT5jO3tWLvlAXBz0jS+HoVVL+0PftAmUpCT5pPfUVD/P4B1q4+FrB2FDxw6yUDw1zbfNWMTcF2KcdkPrVjC0bAF9o4ZAdJR81ntiwsRwljf5R+QGYKZuV4RCRV8ME23ZvkOWQkAQO/WH4sUbwxVt5RKVddw/yR2KGiqX1cqYzIcf96q9Y9wH7yBqQD9ZKl1q56u9mgU6ccE8GBrWl6WipXbsCtuhw7LkmegHH0DUrQOgq1ULis45C4tdVYxaY57/G7JHjYZXk83FxCB5t//mv8gZOw4577wvS56xV9BbtQB0ernGM0p8HIzdr4Whfj25pnhifo209iUPdVgqLSjGvfICjF2ugq5KZbnyP6K5jjhR5X41AflTvBv5yHjt1Uj4+gtZ8p/0frfAsnadLPle3Jj3ENWvj31ZzcnBuXqN7cueMPW9CfFj3dv3bKdTkNpGC6Na5doTupoXa0GykX1ZNP/xZqCIqGF32vcfd4hJAdM6XCVLvqdUrYpyP0+H7qKq9nLudz/Yh4f2VPykCaUOKZo+cBAsq9bIkheio+1BX0lM0N6IZyO2KXo99C2aI3roECg+vFjgCtHkNa1bd1lyn67OJUj6K4izrmtyxnyMnHc/kCX3GXt0R8J41y9KZNw7XDtPLpAl95VbuQT6GtVlqWjZb4xG7qc+OPZq+6S+aWPotO8YCpzzXSXu2hu7doGpzw2hPyphGcWwESQMG4WJeRLiRo+SpZLlfDYeOaPekiUPhHjY0F/eCIm/zIRiCGyzBV+EjbhxYxB1Y29ZKp449Ih5DbwZZjdSwga07Zzw/UQYO7QPStjI+fxL5Lz+piy5R0kqh3JLF0Gn/VewnUtF2lXXQPXwrpO4g5m0bgWUKNcrtf4OG4K+YQMkTp8CJSEhMGGjz0BY1m+QJc/EvjwSUUNuc+uzDDUMG6EZNrJefh15X02QJc+YbuiF2Ndfhi45Wa6hSMVmVBQyogbdIpdK587PhiND2zYBDxq+ICpirgyZKIgrUKWN415mWCzIvGc4LEHo8C5Cnzdza5h69/o3aAi68klaJeJ6WXKfmpoK8x9/ylLosHfqH/6/kOrUXxJT/76IvvuusA4aFLmUKpXtd3QZNMoGhg0KGUq5BLlUOnuTgAgWqvMwlCouzt7kwlUinNB5akbG+RmsT56SawLDumkzbF6Mzma87hq59B/TddfKJc/kedm8zl9Ep/6sES+IhCbXhC5Tb88DH5G/mXpcxw7dZQjDRphS09NhO3Xa5YenbbFDVaS3yxT9UnK/+c6+7SK6pSOb1zqxHTuGzLvvl6XA8Kpir4VLY4d2svAfQ/srgPh4WXKf+a8lWuA+LkuhRfQzyps4SZZCl+LF50/kb9w/yxaGjTCV/dJrSG3VzuVHOA1nSudlj3zJvu3O1W+CtGuvR8Y9DyD71VH2EJK/6C9Y9x+Amp8vf5oiRSCHPBVDHed5MbeFqetVRTbTUUwm+3MeE027ps2UhdATksPSFsSOshTKuH+WKQwbRKEuJ8c+k7D5t9+RO/5rewjJHDrM3gn3XN2GSL2iE9IH3oasES8id9L3QRmmk8JT/oLfAS9mMjeW0FyqqOZV7sibPjOy7+oREZURDBtE/uBGvwVviaY3llWrkacFjWwtcKRfdz3Sbuhnn/1YXLkmKk6+N3cPtH3c2K2LLBQmhqL05ntg27cf1s1/yxIREYUrhg0iP1BiY+VScIhOv1lPPIPU1u3sw/CqEdZnh7wn+gOJvhGeEv0ydOUSZakw8Zy974YX8qbPkEtERBSuGDaI/EBXu5ZcCi41PcM+30fG4Dvt8x8QXZAvhpf1opmSKyNOeTsqVf7839mUiogozDFsEPmBvs4lcik0WJav0ALHHexQTv+yLFkqlzzjSp8Mb/ttqCdOwLZ3nyyRP4mZ/dXcPNcfEXi3VEwOKSZszPniK5ceuV9+DfPK1QzERKVg2CDyA13Ni6GrVVOWQoP1763I+cj1WWgpcomKonnZcllyn5jhXl+9miwVT/yM+FlveNPUi0on5vQRM+Sfu6Q+zl3WyPVHgyb2QSlUm03+S+HNeuAg0rpdZ58ZPue1N1x6ZL8yChk334a8L72bSZso0jFsEPmBmAfE1OdGWQoduZ+Nh5qVJUsUCEqFCjB28WIYWD+w7tkLNS1dltynlE9C7g9TXHqIn/WGee16ueQ/4g5MpE8UWpzcCd/CsnadLLkhN88+KEWkdOI3L1psf0+eyJszVy4RUVEYNoj8JPquoVpFq7wshYjcXOTPXyALFBB6HeLGjYGubh25Ivism7bIJc9Ylq1A9jPPu/QQP+sNb/9WV4hmj/GffqydEcveKdF2+LBc8oz14CG5FN7U7By55IHsbLlAREVh2CDyE12FCogb/boshQ7zUs+bz5BndIkJSJgwHkoJozcFkmXbNrkU+sTQzoEY3MDYuSNiX3pelsoOr/sbsL8CEZWCYYPIj0w9eyD+04+AmBi5JvjEzOMUePpLaiP+s9C4eq6mpcml8BCovzfqrjsQNegWWSIiIl9g2CDyM1Pv61Hu159h7NJZrgkuW4Q0ewhHxo5XIvaVF2UpeNTM8Oq3E6h+RqKvVezrL8NwRRu5hoiIvMWwQRQA+rp1kDBpAsotW4To4fdDSU6WzwSemsP2xcEUdccQRA25TZaCJNxGEArgMKuKyYT4z8dBV6O6XENERN5g2CAKIH2tmogd8TSS1ixDwo/f269yi2YbhvbtoLvoIvlTfmaNjKEqw5X96vmrL8LQzrvZtcl/RH+r+K/HA7Gxcg0REXmKYSNM6Zs3g+mmG1x+8KQZWpSoKBi1gBE97A7Evf0GErXgIQJI+d3bUG7hfK2i8wViX3weUUMHw9C5o33ejrI4Uk6kUoxGxH/+MXQX15BrKNQYGtZH/Nj3ZYmIiDzF2kuYir5jCOI//tDlh65KZfmbFMqUmGjo610G07VXI/reYYgb9SoSv/8GScsXo/ze7Uj8fZ49aFL40yUnI34Cr56HMlP3axHz9BOyREREnmDYoLDk9XCNYUhcDTc0qI/YF0fINRGgjI+aaahfD/HjxsgShaLoh4afvzscbixmuUDhz80DZTicH/M8m0CRwhPDBoUMNT1DLpVOzciUS2WPrmIFuRSCsrKgutH5WM10fZtHKtM13RDz3NOyRKFG9LGJe+ct6Js1kWvCg+Xv8JlLhUpmO3FSLrnGdtK9nw+G/MVLyuRFw7KKYYNCRt70mXKpdPnTZsilssey0f8zKntKzciAecEfslS6vGmub/NIFj38Ppj69ZElCjWieWPC+M+gVK4k14S+vO9+gO3sWVmicGbdtBmWDRtlqWTmNesCMuu+t2x79iJn9LtQ8/PlGopkipYsGS2DIPPhx5E/c7YsuS/ug3cQNaCfLJUutfPVsB04KEvuS1wwz95hsiSpHbvCduiwLHkm5rmntPfVH7piTuq21DSYf/8DWSNeAHK9uA0bE4Pk3VtlwT+sBw7AvHAR1JxcucZ7ano6cr/5DsjJkWs8YDQief9OWXBmPfoP0tp7Nx+IkpSEuLdH2eeUUBIS5Nr/iEOO7fhx5H01EblffCXXesZ47dVI+PoLWfKf9H63wLJ2nSy5R1RQy69fJUvFU7X9OX3gIHvFwhumvjeV2rE548577PtmuEicOwuGpsXfWbAeOYq0DlfJkvuiH7gXsc8/K0vFs2zcrG2jW7WavHcVpPhJE2AqZd6d9IG3wbJqtSx5RkkqB1PP7tBVr47iBpjIn/UzrLv3yJL74sa8j6h+N8mS71m1Smlat+6y5D5xPIq+725ZKp555SpYli6XJffo69dDuT9+laXCcsZ8jJx3P5Alz4htGfPIQzC0aQ19g/r2QUYuEMcO685dsKxbh5wPxrrVSqAo5VYugb6UoZ+z3xiN3E99cOzVzsWGVi20c35lwGCQK91jH3Dl6q4waQ8KTQwbQRKRYaPLtbDt2y9L3hEVNH2dS84fUBUFar4ZtiNHtMdR+RPeUcolovxW164UecKqfQ5p1/XSzuQheNXGZELyvh2y4Mx28hRSW7eXJe/pLqltH9JXMRnPN6/K006Ku/dCPXdO/oR3jNf3QMLn42TJfwIRNgTx+af17gPVzWYTjvwdNsTIaGIUNXfkfv0NbIePyJL7QiVsCHkzf0bWw4/JkmdcCRsZ9w6Hef4CWQpdoR42AqHUsPHJZ8h58x1Z8gG9HkpcrPZfrXJusZyf9NKHc+ckrVtZ6qAyOeO09/SWD9+TDyRM/tZ+kYtCD5tRkc+I0XV8RT11GpZVa2D+aynMi5fAsmKlz4KGoJT376R65j8Xh2bQELSwURylXDl7uPMVEXDFtrNvwyXLYFm91mdBQ/DlPhcKxAk+4YtPZSk06S6qiui773LrIX4nUkT1vRFRd94uS/6jv+xSuUThTufr843Var97IY6loumqTyfp1I7/9vNAKUJx/zQvXSGXKNQwbJDPhNPJUX9ZXbnkH6o3zZz8rKTb40p01Pk5PcKEv7djMOgb1JNLFKrElWx/E0NgU2TQ1Qufc6M4/ovzQGlCcf9U8znCVahi2CCf0YfRAVV/adm9aqhv1FAuFS2sQmPdyAsbREJJzcYovITT+UZ/qWvHVDEhqWiOTOQKhg3yGUOrVnIp9BnatpZLZY+hWVO5VDRDmzDZjgYDJzikiCX6rOlbNJclCmc6rVKuC5OLOK6eGxW9HqZ+fWWJqGQMG+QzYhx6cbUj1CmJCWW3E1mUCaa+N8pC0UzX95RLoc3YuZP9JE4UqaJvu1UuUbiL6n29XApt7hz/owbdIpeISsawQT4jJr+KunOoLIUucYB0pU1qJIrq1we68uVlqWj62rVg7Bb6QwgGopMuUTCZbuoNXZ1LZInCWdTgQdr/FD84RygwdrnKfvx3lRihUowISFQahg3yKTEkpqF16DbDEbeyYx5/RJbKFqVqFcQ886QslSz2zVft47qHKtOtA2Hq6vlQp0ThQImJQfzHH9qbDFJ4EyPNxb76siyFHnG8jx39uiy5Lu6tUfZzC1FJGDbIpxTtpBg37kP7REohJzoaCZ99DCU2Vq4oQ/R6xI8bC12FCnJFyfTVqiHug3dlKbSICa3iQvikTeRLhiaNEfs69/dIEDXo5lKbsQZL3Jj37Md9d+nKJ9nPLSiL51VyGcMG+Zw4YCX89AN0pcxAGkhKpYpI/PH7MjmcpOijkjBpAoxudoo3XdNNC45jQurWv6FVS/vETUpMtFxDFPmiBw9C/BfjtBphnFxD4Ug0NY575y2Y3JiQ1++ioxD/+TiYvGg6K84tiTOmhkWfTQoOho1g0Xn50bv7+16/nnsTvRka1Efir3NC4iqOsfu1KLdgLgyBHNnF28/bR4xaYBDbwdjJsw7xUTf2Rrl5P0Mf7GE4jUZE/+9BJGiBUVexolwZQG7u/07c3ReUABwbvNk/Pfn7/P2evP2+ufv3efl6ige/b+rZA+V+n2e/Oh5Szaq8+W64wtttGwhuTISqREUh7v23EffeaCgJCXJtcIjR/MqJ87QP+l0YLm+ExPm/IPqxh4P2vjz5XlFgcMsEib5hA7nkmdLmSihIHAg8FhsLfS3XO41doEsqh/ixH6Dcn78h6vbB9mZMAWMywXTLACRqISPhy88CXkHVX+7e9vEp7XM29uiOxNnTkDBhPPReTtIn7gYl/jITCT98C+PVge04riQn209eSauWIvbpJ6CUMPu5P7n7fXNkaOTmdy/K5FWnYFe+63ovjgee/K6hecnDLZdI+zzEMLAlEe3hlVIGPiiJvrF778ntbVqAp8d//cU1EPf2myi3bBGih9/v9XnEF7w6t7jAfoc8xO/ouPudsA+mcvMAJK1ZhthXXoSuVk35TGCIi1AJU79D4s/TXZ5XwxW6xATEPv4IymnH65gRz8BwRRvtw9HLZ/3Pm+Ma+ZeiauQyBZCanY3sN0bDvGIVYLbItaVTyiUgauAARN8xRK5xjfXYMeS8/hYs27YDNtc3ua5qZUQ/cB9MPqhk2lLTkD/vV1iWLIN55WqoZ8/KZ3xDXE0xtL8Cxk4dYerdMzhXwCXVZkPu2HHI//U3bVv7aTZxRft/o1GrZCVBV7OmPVSI4YeN7dv7dbQt64GD2vuaD/OS5bCs3wDk5spnfENXrRoMHTvAeFUnmK67NiRGDrOlpCBbfH82bdY+AJtcWwqdYu9fEvvc026N8CJYNm5CzvtjYD10WNuZ5MpSKFql3NChvf31SmtmpmZk2N+Pec1a7cWscm0p9DoYWrZA7AvPlTqiWUH213v7PVhWrYGa6/osv/bjz713a/vBNXJN8cx/LUXOJ5/Dduy4XFM68TmJilfME4/a5w1wlTht5n01AXkzf4aaniHXlk5XsQKihg5BlA/v+NpOp2jH01WwHTxkf+/2x6lTUPPz3Tq3uEt0KI66RTsXDblNrvGf/IWLkPvZF7CdOCXXhAjtOy4mX4zVKta6i6rKle5TrVbteLoU5j8Xw7x0OWz79stnfEQcG1q2hLGLdkzt2QP6S2rLJ/xPzcqCWfveW/fs1fbNY+f3z+Mn7OcN1WzWfkD+oBfEOUKMoBjz1GP2fqMUehg2KCjEbmc7fATWrdu0A484OabYT5D2k+Sp0/YwJip1qlU7WWo/qxiMgEGvHVSioVSqBF1l7VGlsvbfylC0/4qrazrtAMrbqIGlWiyw7toN685dsJ0U20/bdqdPy215WqslaBWeC9tR2zb2Cp32UOLj5bYT2/L8dtRV10KGduIW25WIqKyynUu1X9iwHTn67znxwjFVTUvTjqlWe0CBzaYdU7XKtXZuFE3rdJUqnj+uiuOpPLaKO9PiDpi4MEUULAwbRERERETkFwwbRERERCHIlpYO6/Yd2oKLzR01Sly8vR8SmxRRqGDYICIiIgox+X8uQuY9wwHRt8FNutq1kPjLLOjKJco1RMHDBu5EREREISZv4nceBQ1BDBggOpwThQKGDSIiIqIQYzt7Ri55Rk1JkUtEwWO1Whk2iIiIiIjIt0TQmDlzJsMGERERERH5zoWgYTabGTaIiIiIiMg3HIOGwLBBREREREReKxg0BIYNIiIiIiLySlFBQ2DYICIiIiIijxUXNASGDSIiIiIi8khJQUNg2CAiIiIiIreVFjQEhg0iIiKiUKPTywUP6VnFI/9yJWgI3BOJiIiIQoyheTO55Blvf5+oJK4GDUFRNXKZiIiIiEKALS0dOR+MhXXzFqhaxc5VSlwsTDf0RvRtt8g1RL7lTtAQGDaIiIiIiKhU7gYNgc2oiIiIiIioRCJozJgxw62gITBsEBERERFRsS4EDYvFIte4jmGDiIiIiIiK5E3QEBg2iIiIiIioEG+DhsCwQURERERETnwRNASGDSIiIiIi+pevgobAsEFERERERHa+DBoCwwYREREREfk8aAgMG0REREREZZw/gobAsEFEREREVIb5K2gIDBtERERERGWUP4OGoKgauUxBYhw0Ui4RERGRN8yTX5dLRFQafwcNgXc2iIiIiIjKmEAEDYFhg4iIiIioDAlU0BAYNoiIiIiIyohABg2BYYOIiIiIqAwIdNAQGDaIiIiIiCJcMIKGwLBBRERERBTBghU0BIYNIiIiIqIIFcygITBsEBERERFFoGAHDYFhg4iIiIgowoRC0BAYNoiIiIiIIkioBA2BYYOIiIiIKEKEUtAQGDaIiIiIiCJAqAUNgWGDiIiIiCjMhWLQEBg2iIiIiIjCWKgGDYFhg4iIiIgoTIVy0BAYNoiIiIiIwlCoBw2BYYOIiIiIKMyEQ9AQGDaIiIiIiMJIuAQNgWGDiIiIiChMhFPQEBRVI5cpSIyDRsqlIFGMqFShHCrHmWCw5OJ0WgZOZpphlU/7hSEGtatVRr0qCagQbYJRtSArJwtHT6Zgx7E0pNvkzxFR2cZjBbnJPPl1uUQUecItaAgMGyEg8GFDQfka9XDLlZejZ+NaaFuzPCqYdNraC1RYstOwZe8hLN22GzOXb8fyM2b5nOeU2ErofmUL3HZFfXS9tBKqRDm+5gUqzOK1d+/FLys24pvVh3AkXz7lptj2A7FzWD1Ey7L4t0+smYluX+5Aik/2eiOuGHAnpnevDJNcA9tZfPrOF3hpb/FRrfDfVRoVVu2gkp6Rhj2HDuGPNZvw3boTPnoPGiUZ/3vmXoysa3DYHlZsmPklrp+XAm/qcgXfq2pLx6wvJ+CBtZnau/KQEo97Hn8IbzTQyxUaywE88+xkTEhz+Fdj6+Dt52/GHZX1Tvt27tFVGPDmn1jj4X4FpTzufnQYRjWKdrg1rCJj90L0fHc1dnu1XYy4+aHH8XEzgyyXTtW2kDk/DylnUrB59z7MXLIRPx/OdnG7uf964hVVmxXZWoX/8PETWPX3TvyoHSPWp/mu1h/8Y4V38nbMR+sP1uOk476gq4JnRt6FJy522G9dZMvYgjuenoPfiqxbFLENrf9g1EvfYIzTH+A9n35OtlMY88ZXGHXI92mRYYMiVTgGDYFhIwQELmwoqHhpSzzbvxOGNa2ABF3h03dRVEsmNqxehdenLccvJzwIHcZk9LrhWrzSoxGaJjhW/EqjIufMQUya/Tte/uMwTru5p8Z1HoyTwxsiSpYF1ZKCT0d/ike25sk1njPW6oI/X74a7aId3pE1BR++9hGe2lV82Cjq73KLasW5w1sxasI8fLQry6swIOhrdsPKUV3RwuC4ZbSK3KHF6DhiITZ48QJFvVdb6k4Mf+l7fH3Kw0OPkoD/e/4JfHi5Q+XKsg8P/28iPk11/De1UN20N5Y+1Rb1Hd+basbmORPRZfIhZMpVrlNwcedBWHl/I1RxaISq5h7Byy9/iTcOeXs/0ITbnxiBr1u7U/l3plpz8PeqRXj425VYnl7aZ+z964l9xZZ7Fgt++x1PzdyKnd58tULoWOGN/K1zcOkbq3Hc8e/QVcVLbwzHyFoehI30jRjw0HTMKfLwW8Q2tBzByGe+wOhjHn7HiuHTz8lyEm+9NA4v7GfYIHJFuAYNgX02ygpjRQwceg82vtQHjzSv6HLQEBRDPFpdeQ1mvPkgplxfExVd/1Uk1m6DiaMexIwBTdDMrcqDoCCmwiW47667seHF7rihovsn6YIUQwXcPaQz2v97K8JDukp4cGhHtHUMGoGi6FG+VjO8M+I+TOpSycsTvx7tOjdFE6egISgw1miC2+p5/5kXpEuqh9HDO6GZUa7wGxXntvyG4b+eRK5TBjGi6fU34ZXL3b8+qyQ1xpu3NHAKGlDzsWbOHLzrddDwDUUfg6ZX9sT8VwbirurehAhXKdBFV0CPm27G0pduQL9Knp1WQu1YQUQUKsI5aAgMG2WAknQZRo3UKqY9aqFqoUql65ToSug/5E4sfqAZLiv1XK7gohbXY8ELN2DwxdFwI9sUplWuqzboiKmvDMZjdbxNCQqiarbHO72qwvO6roJLuvbEcw0cm9EEnmKqgIF3D8bY1vFuVswcRNXF7e2SUWSVVJ+MAZ3rIk4WfUeHpPpd8dXA2kiUa/wnH0unzcI7+/O16PEfxVAJw+++Dj3i3fjklFjccOt16F/eKWkga/9SPDLnmPZKoURBdNUm+PiJ3rgxyZsvnzu07XpJW3zzzA24wa3XDNVjBRFR8IV70BDYjCoE+LMZlZJUH2NG3IIHLjYVXSFVbchOP4ttR1JwJC0XuToTkssn4/KalVAjtpiri6oFu/+cgq5f7UTRLWEUJDfugd+e6IDmRV35114z/fQRLPz7ENYfPoOjGXnIU4xISkpCg1oX46qmddAsybH/wAUqrOn78PSo7zD2cOlfupJu+duy9uHJFybiI6d2Dq5RyjfH1Df6oW9SEVHDo2ZUNpw9cgArThXfRE1visUltaqhfmLhz8V6djOGjJiGaY79FVxUvt3N2Pa/pijuYrQtfQuGPP4jfsqSK9xU0jZQLWcwccwXuH9dllMQKJXLzaj+Y6rZCfNfuhadYh3eqGrFgb+moOMXO4rZj50lNbsRK59sg0sdArua9w9ef3U8Xt3vq5NAEU1ibNnYtv0wDhTbPElBTEIyml5SEZWMBfcOG/5Z/iOuGLfVuf/Avzx4PUWHmNg41KpRBXXjtP2x0BfVhpPrZqPT++txoNTPNVSPFaV/J0tiObQG9/20G+dk2U6JR9dr26KL43FDW9exS0t0dlin5p/AtF93Yo9D6yI17xgmz9mOXUW2OApmMyovPidbKqZ9Pxff+7hficBmVBQpIiFoCAwbIcBvYcNYDc+MuAuvNogpdAVetWbj7/Vr8dH89Zi28ywyC+4FpgS0a9sWj93YDjfViIHe8WyuVQBOb/sNPUYvx5Yi9n9d5VaY9spNuKFgZVz7vdSj2/DB1IUYuyGl8GteoI9Hu06d8dqAtriqQsGKhIr842vQ/8VfML/Yf+C8kiq64iR5et0stHt/Aw678w1Q4tB3+IOY3Kkciry541HYsGL1lI/QeXYpnbENSejepy/G96mDixw3iFZp/nv2F7hi6j9w65SvVXSGPfkoPmsZLT9jFTmpmchLTMC/m07NxbzxH6LPIs86dJe8DbR3fm47Hnh5Mia603/Dg7AhrrrX7z4US4ZeimSH3VK1pWHKR5/hjlUZJb+/6Evw3ut34n/VHQK4asb6mV+h609HkSNXec/ziqOp4mV49v5+eO7yBDh1UbGcwFsvf4oX9xW1T3pRUVVi0PSKDnjt1o7oWcXo/D21peO7Dz/CXWtL/mRC91jh4nfSW7rqeO2t+/CsQ6dxW+Zm3PrgT5jp8pc5mGEjQJ+Tmxg2KBJEStAQCtZBKWKY0HFAP4ysXzBoaBXK49vx3KixaPvB75i4o4igIeRnYNWyhbjluY9xw7RdOJh/4YdsOLdrEQZ+UHTQECMb3XNXd/QqVHnIw5bF09Fp5FS8sb6EyoNgzcSqxfNw3YiJeGFTOsxOP6vAVLU1PrqtHpKdaxZu0qFSy2vwetu4AhWUkiU1vQZvdkgsOmj4myUVv037DgNnH0OW42ei6NGoQwt0cKhruEJXqRluaxzlUHnOx+LZCzEvw6HaoESha8cmqO3VZ108ffkGeOf+K9HEzb/dfTbsWjAbz27IdKoUKbpyuHlobwyuUNIbNKJD3164v5rjnT7te3RwOR6Z7cug4Z38lD149d3v8VahJmOVcWunmtoRwcfUHGxZtRB9XpiEd/flOYc1XQL6XNME1Ur6WMPmWEFEFFiRFDQEho0IZax1Jd7uUQXOLRNsSNu3DP1fmYz3dmS6No+GNQ2/z/gOHd9ZjCXpVqTtXYqb31uM5dnyeScKklt3xYimsc47llaJ3bJgKq4fvxk73WjYrqYfxOj3J+CR9emwFqhc1+p0LR6v62UNVasQDRx0Da5ztVNC9CUYeXtL1HG6zRNoZqz++Q9MTnG+jqhProWrqrvzddbh8k5N0cGh2Y2adwg/r9qK2VtzHCrkCqLrNcdgt/7t4llT03HM4rgxdUhq2A1fDaiFeLnGb9RzmPj1XPx0xuZUMdaXb4jRw1rhkmI2a1SdTni/exVEOTwvmrqMmfAXVodWRw0g7yje/WkzDjvtHjrUqH8JGvrpaK9m7MdL45djg9N2VRB32aXoFiuLhYTZsYKIKEAiLWgIfjr9UFApcejfpx1amRxrTyrMpzbj/vcW4He32/arOLl1IW56fQJ6vvMHFhd3qVGpgGG9GqOa015lQ+r2hRj63e5i2oyXwnwaX342A18ctxa6WntP78tRyZ16vyUF6w/mOlWkDZVb4O0+tV3oBG3EFTf1LHB124bj+47icKAHIco7iPk7HQOBRp+EelXduN+ir4EhHariv6yhInvXDsxNy8XC9fuR6vCPK4aquLlTNS861P/HdmYDRs4reGfGhOa9+uLdlu7dZfKEem4rHpu4EQcLBJ7Kza/DuGsrFr5jpa+CR++4Ei2dkoYZW+bPwZt7PGvP729ZO3djWabT3gFDpYq41I/1bfPhTZhWYAhTxVQRDS8qZp8M9WMFEVEQRGLQEBg2IpCuSgvc39L5iqFqPYtvJs7DjHOenMXPyzxyEGtLGLffWLclbr/Uue22mn8MYyatwjYvvjdq1l689P3GQldrk5u3xM0lNn8pKA/zZi/HGsdxUBUDGl7XE4/XKbmibqzZAe/2uMjpTpH17DY8/+vxIjrI+psNJ9MKTNqmGBEf7frXObZxCwxwDCdaBXrFup04oX00aVt24M9sx39dj3rtW6CTD9rh6BKicXjGNIz82/nvF0MS33n3jRjizrjKHlFxet2v+L+FKfi3ZaCgi8XVN9+Ih2s47gc6NOjeC09d6tDUTPv9vCOr8MiMwyjy5l4osGTiRIbz91QxmRBf8i7uHTUde0/lFdgnY1CxmNG+Qv9YQUQUWJEaNASGjYijoN4VjdHWaVQaG9I2L8Frm3Kcrvj5lh7N2zSA87QMNqSsX45PfHDp/9zG5fh8r9n5iqWpJm5qlej61XAlGklpK/D4vOPIcfiHFFM1PDq4XfHNTHQV8eDQTs5zatgy8PPk+ZihxqJ8wOswCpLiCgy7q1qRk+dUwypBNHp2aogaDv+AaEI1a73sBJ61G9O3ON850VdohNubFdfN23W6hHhUUU9j3Odz8GOK4xVoBfrkhnjvgQ643J+VYrtc/D5lNsYedt6fdHGX4IV7O+LCRMy6yq3xXt/aKOf4OZlP4eMJi7Dc+zkh/UcXg/Kxzjulqp28sv16B05BlLHg6HUqrDbHT/iCMDhWEBEFUCQHDYFhI9Io8ejWuIpD8xiNLRtzF2+FjwcmcaYkolP9Cs7zNdiyMG/5Tpz1xeuqKfh+2SGnkCDuSrRoWAsJslgqJQqJsVas/XkuPjlqcaroJja4CqO7li/iC6GgtphTo6Fj5d6GUxt+x1PL0xEXGwWn1mqBYKiObg0KtHW3pWH/adfChlKuEYa0iHP4fRUZ27fi539HcsrFgjV7ccbxn9PFoVfHhl43RVGMcaiaoEA9+zf+99lqbHe+vYDyja7GV/1rltKsTavEertP5R7Eq+OXYp3zbH9IuOwqfNanBmKUJAy9vRuuiXf4lFULti+Yg9fd6UwQBKY6ddAx0XlPtp45i4P+DBv6i9Di4gKjQdnScaRA3yK7cDhWEBEFiAga06dPj9igITifkSj8aRXR1jWdrzCquYexYLufL8UaL0Lz6s41UTX3CBbu8FW7dhUntuzDZqcKk4L4i6u5fiVcMSFRtL3PO4Q3vlmHPY7t9nWxuK7/dbi5wGRkSvmmGD3gMlRw+KbYMvbg5UkbcUj79aQ4xyY2gaBD3a5X4Y4qzm/amnYEK466UptUUKtDc3SLcfirbbn4c+UOp3by6Zu3Yn6aU9pAUtPm6O/tsD5KHKrISfFSty3AnTMOwbF/iNhGLW/oh7ebxxb/uaoqbK7lqhLl7PsL9884CKe3qb1+qxv64IPbeuGVlvFOgSz/2Bo8Mv0gMuWakKRLxrA+LXFpgbsGp/Yewja/hQ0FyS1a4+YCfYYsZ45geVGdL8LhWEEui06ogKY1q7r8aFw5Jjij+RGFoAtBQ/w3kjFsRBilXAXUcpy4TGM5eRxb/Dw+py4pGTUL9BmwnDyBbbmy4AO2syexw3FYVo2+fHnUdLXjq5iMLOr8aS59+0I8teQcHPOGPqkRXrvZYZhMrWLcZ9C1uMlxaE5bDhZOm4uv7PNCaBWYKF90m3aVHrXb9MKU2y5zmitCVCaPrN+CRa7kSV0lDL6yJpyyRvou/LAhW6uiOcjdi+/WpTmNWKZE1cagDhW8O2go0aj4720LCzb9PB1Pbchwfh1DBdx9740YVGz/DRusPggb2mEef8+djRe3Fug/YqqKu3s3dOq8rFpS8PmEhfgrVMa5LYqhPPrcMQhvNit812vOiv1+62NirNwMHw1t5tQsTzTr27VqM1YWcf4Mi2OF9t1udPUtWPraA1juxmPxsCaoXGxKjkR6NOt1O9aOfgjrXXysvrdpGfuMiIpWVoKG4FW9gUKPLjEWyXL5AltaOo76pHJWPH1CDArcFNAqsRk45svXtabjnwIjaSnGGFQs0D69JCajbOqh5uDXH3/D1LMOf6B9mMweGNnwfE/opKZX480OjpP3idFy/sRjf5yVlVMF0aaiZi92l4Kq9Vvh6Zs645liHs/f0gsTRz6CjY+2LTTTsi37AMb+6lpl0linBW6p7fg32/DP+s34rdAvm7F0yd/Y7ZQC9GhzZTM09eaooUQhKc7hH1DP4ZvxszDBaQQh0X+jET64rx0aFnkJ1Ip8X91ttqXgsy/n4xen2ysFaBXn3Qt/wSvbgtRRQxePK7sUvV+cf3TBq0MH4Pd3H8LUay+Cc59sG9K2r8DYre7cNTChes1auLJ+yY8uzRvj/oEDtQp5Xwys5Hw31Zq2A2/NL3qSyfA4VuiQUOkitL20hluPNtXji53AkojogrIUNASGjQijMxoLzK2hwqrVzPxeTTIYC5xkVaj5Zt9eTVXNyCnUXF6PaDduLhgM/13aVNO2Y8Tk7TjumDcMFXHvkM64IqE2ni8wp4Yt+xDe/GY1djn8fOFOsZ7QoVaLTnjt1uvwejGPl/u0x+DLkxGvK1hLy8aS6XPx2XHnilXRjOjcubFzx1zrWcxYVnRQMe/fhB8POfdtMdZogiHOPXvdowWWxFiT02empu/Ck58uwXqn/hM6JDe+Bl/1rYHCUzWoyNcO0K68Y1fYTm/E/77dqgXyov5FFeYT6/DIj/uQJtcEnK48et5wbZH7xfnHNXiuZ3N0qRKFQrtH5kG89s0a7HbnwzJUwfBH7sHil+8t8fH7M7fi437N0CqxQLNNyzlM+WYuphY3m3uYHCuIiPyhrAUNgWEj0tisTk1S7FeJDXqfzJFQIqsFzud2BYrRgGhZ8gnFiJhCb8SKPJcv2mqfhU7nUDFScWzFfLy0McuhGY2C6Nod8PXIvhhezeEOgJqHlbN/wUcFbhEZ9F5UvL1ly8XG36bj9l9PFXkFuZDYyzC0jeOdGi1QHNuKyU63LxzYTuP75UfglAH0yRjQua4L85IUz6jtFwVl7VmMYVP2wqk/sRKF1jf1x1vNYhy2maAiz+I8MZ93tP1g1Vw8/Ne5AjNQa89YzuCrb37HQp/WhAPDln0M4z75EWNd6svjG6o1A39MmYKHVmUUv33C4lhBROR7ZTFoCAwbEcaalYuCc/aJ4UarFrji6WvWjJzCr5uYgIt8uYfpElCtXIFqpyUXZ52GnSmZruCkGGoqvpn0JxY6ToKmmFCvZgWHGaNVZO1dikfnnSxUqdcH6Ruk5p7GtO+/RY9Ju+xzY5ROQeXWLXC94yhFqgUbV2zGRuf85EDFwZWbsdjp89XholbNcb3HaUOxB7TCu6MVOxbMwMMrnPvR2O803XsDbnbqmK4iN995aFOvqVn45aflWFbg+G85sAEfbfFhZ4KAUJGphcin35qAJzbK4Yz9ToUl/Qg+/eRr9J/7T4md6MPjWKEiO/UMdh077d7jTI5rwT9i2HBo41K8MGUBRrr4eGnREZQwXRNRxCqrQUNg2IgwtnNpOO40O7JWIa5cEfVc7hjpGVvqORx1GsZUe90qldHIBxPBXaBLroL6BYf0PJeKw26c3XUF25lobCfX4olZh5BeTKVbzTuG9ycuw6ZC/QQU+X+BoapWpJ46glnz5qD7U+MwaN5h14cKVcrh5k51neaM0DYadmdXwg1tGuKmYh43XmrBvuOOTalEPa4ehrSN9/h9G4pLaGoGfpo4Ex8fcQwSWjip0Bgf3t8WDRx+LSM73+eVaFU0Nyz4j1ptYVJ5VLXKdA4O7NmOMRMmoPmzUzBmjz/n1XGg7ZcHVv2Crk+PxyMrTqO0PvThcayw4e/5k9D0iTFo7Maj5SebXAz/kULFiV3r8fbsJRjt4uPdFceQJX+bqKwoy0FDKOasT2Er7zR2FJhvQRd/MTrW9nNzn/wT2PxPgdeNqYmuPks5Cio3roMWTm9DRc7RY9jq9XfXhh3z5+LdfUVUYFUzNv06B+/s9+f411ZsnjsJbZ75GK2KfHyEFk++j7r3vobKj3yOgZNWY1GKe3+PrnozDGrgPGMz9BUx5K7bMO3xwSU8BuChugV+T4lCl45NUNsfKStrP0Z+8ieWZjnuSzpUbHIdvuxbHTH2sor0HN+HjZBlOY4P3x5XxH5x/tFS2z+aPvouqgx7A/Ve/AFPLtiPQ94kJOtZzJr+Cx6dWNTjN0w4UOCzV3S4qHIc8p22WQnC+lhBROSesh40BIaNSGM7hdX7nYfyFO3sb2x3sX9HSVHPYdnuc3CqAusScH2HS5Eoi15RyuOWK2vDaTAZ1YpNuw4jXRa9Yj2B979djo1OV1xV5B1eicdmHS31aq23cjPOYMvhE8U8TmLrP2dxJMv5DoPr9GjdqRlaGnyVDhTE1GuO26r75/CRd2gZ7pm0E8ccO2xrAaftTf3xRhPRf0OEjTwPP4twZEHKyaL2i/OPv7X9Y8fJNJwr2OHEU2oW1q1YjXG/rSrisRSPTVqH3U53T0U/p/YY1S3ZtRNKuB8riIhcxKBxHsNGxDFj6aYDcBzRVVQ263buiMHFzlvgC1asXbenwCzFOlRr2wF3XeT968Y36oD76ztfYVct/2De+nPOwcoLeXuX4okFp3Ahb6iW0/jkm8VYHqQRT33GVAu3t6/oPGOzlxRDVdzSqZqfBh5QcWDJbAxfdObfbSEoxkp44L5e6F8eSEnPKdSZmwIja+cSvLo2U/vGO9DFoOtNV6NfgX4SRQv/YwURUWkYNP7DsBGB0jZtLjRvgC6+Hl69o4V/mr5I+bvXY/Jh56vvSkxtPH1bS+9eN6omnh3SCpc6DEMrKqTpWzfih6JmKPZYPpZN/RINH/8Ql4vHY+Mxckeh8TPDTmKzFujjOAW6T+hRr30LdPJhO3snahbmTZqO0fsd72AoMFRsirH3tUHtjAycYdgIDjUT035aimXZzhtAX74xXrmptksjlYX/sYKIqHgMGs4YNiJR7l6MW3SiQGdXHaq0ErNP14GnNzgS67bAHQ1LGKDSdhLjf93tPHyp9rqVW/bEN/1qetZEQknCwLsH4PFaBa5UWs/i+7lbcMzX9QdLDg6fSMHu4ynYk5JTYIjOMKTE4caODVDZ4ZuuWk7hmwk/YshH7jxmYfxB58qhvkIj3N7Mj43z8o5g1CcL8LtTz30dKjW9Dl+0j0EaL1MHje34Wry48JTz3SVFj8u6dcejtVzoHxYJxwoioiIwaBTGsBGRrNj06x/47nSBic+UKLTqNRh/3N8KzQrPlFY8JRrNuvTBwhF98cldV6FjsfVLFceXL8QHewq0p9dFo32/wZh1c1241UoiqgrufPBOfNUxGUan37PhxNo/8db28L/r4G9KhcYY0jTa4YuuIm/fBoz+fQumrnDnsR5vLToEp4vZujj06tjQ4/DqCuuxNbjn6y04aHV4YW1/atOpMS7385gHVBIzVs5ZiKnnnBOfElUNj9zqyt0JHiuIKPIwaBSNYSNSZe3BC99uxIECw+CKwHH5VX2w/O1h+LhnPTRw6kVZkAEXN2yDD55/CMvua43msTqYalyBt3tXQ7GtZ2wn8eFXi7CkwMg0ilYx7dRnKFaO7IVhl8Y5TSxXmBF1W3TG96/di887VkSM05+ownJmK578dgtcmjS7TFNQ/8rmWjh0+ADVfCxb/jf2uv3ZqTiyehMWZjvfZUhq2hwDnObA8DWtUrr6F9zz60k4TpGg6HSFZsumwFIzduC12fvh3GJTh/JNu+LlNnFOdxeKxGMFEUUQBo3iKapGLlOQGAeNlEu+ZkKHAXfh574XO8+v8C8VtvxMbNt9CGsPncL+cznIMKuIiolD9SpV0LJBbVxRNRamArUGNXs/nn5hIj485lxJ+I+CGu364Y//a466RYyApNrycezAXszdcgjrDqfgn4w85ComJJVLQqPaF6NLi/roXC22wBXK82zZR/Hm2xPw8q7Se23HdR6Mk8MbOozCZcXqKR+h8+wUH3UUNaDnfU9gVteE/1K7NQUfvvYRntpV/MHG/3+XpKuO1966D89e/F91zZa1A/c88QMmFZxVzSXR6P/QY/jhyrj/3q9qwYrJH6PrnKL/dp+9V0NVPPnc3RjVKKboKySWfXj4fxPxaaoXh7O4VpjzaV/0cOj1bt45H5e/ugwHAnaUNOH2J0bg69YO3fktRzDymS8w2i/tgLx8PUN1vKJV9J+r7TDbvnZcMf+zAt2f/xVLS/2alpVjhUaJQ4dOzdE+0eGPVeJxTY8OuCb5v71azfsHE2f8jV0OL6zmn8Ks33djf5GbpIhtaMvE2rW7sd3t+ShVpO9ciacWn9A+gcIKf042nNq3A/OPejA6nC0Nc2f8iZkpvt+vzZNfl0tEgcGgUTKGjRDgv7Ch0U5mPQbfju96Vi8mcLjPlnMMH7z3NZ7dVtKZTI96nfth1t1NcVnBtOIhW9YRvDvmO4z8O8ulE1tZDxtRjXpjy/PtUOffP06rGCz/EY0+3oo0ucZdsc36YNvTrVHj339Tq1geWowOIxZiUxF/vC/fq65iC0x5pS/6aBWzQnsUw4aHvH+9pBZ9sO7J1qjleHxR87Fq6ufoMvtkkZVWZ2XhWKHRVcVLbwzHSFf6tBRgS9+IAQ9Nx5wi508pYht6zIaTi79H3c93oaiIVvhz8oLlJN56aRxe2O/Lo955DBsUSAwapfNR9ZNClpqJ+d9PwPWTtmJPoemR3aUi89hWPPXmBDxXYtAQrNi9ZBq6vv0nFpzxdH4ISbUh/cgGDH91Ap53sfJAJlzXuZFzBdCWgTlLd3kcNITsbZsw/aTjAVWBsUYTDKnn/w4UtpRNeHB8wTkeKNhSNy3Gm5sKzO2jmNC217W406UOPTxWEFF4YtBwDcNGWaDmYs38KWj34jS8tykFGY6TpblEhTn9GH786Xu0HTEFY/fkuHgSV3Fy2yL0fmY8HliwH4edJsxzhQpr1inMmvED2o6cga8Ps5Onq5SERhjaKt6pvbvl1DZ8v82bqaU1lsP4YdVp51GI9Mno37ku3BlzwDMqUjb9imGzjiKDtcjQoabi2x9XYkOB77cuoR6eH9AArnXp4bGCiMKLxWJh0HARw0YZkn54M54d/REavTwdryzchc2pZhSfO1RYctKxecsGjBo/AY0f/gSDZ+zEHg8muFOz/sHXE75Goye+wr0zNuDPI5nIKSHwqNZcHN6/E5/+MBXtHvsIA6ftxD7WHdwg2sE3xzVxjl9vK3au2oQVTtM2e8KGTcu2YIPj6FDaYaRaq+bo5coEC14zY83M6Xhuc5bvmreQ18yHVuDFv87C+aaTDjWuvAZP13N96kceK4goHIigMWPGDAYNF7HPRgjwa5+NEumRXKUqWtWuhBoJ0SgXpYc1LxfnsrJw9NhxrDuchkw/7R1R5SqhRa1KuLRiApJjjDCqFmTl5OCfUynYdvA49hcYoYaIQp+iKNApOuj1CvQ6saxAtZiR7UXTNx4ryF3ss0H+xKDhPoaNEBC8sEFERBRZGDbIXxg0PMNmVEREREREJWDQ8BzDBhERERFRMRg0vMOwQURERERUBAYN7zFsEBEREREVwKDhGwwbREREREQOGDR8h2GDiIiIiEhi0PAthg0iIiIiIg2Dhu8xbBARERFRmceg4R8MG0RERERUpjFo+A/DBhERERGVWQwa/sWwQURERERlEoOG/zFsEBEREVGZw6ARGAwbRERERFSmMGgEDsMGEREREZUZDBqBxbBBRERERGUCg0bgMWwQERERUcRj0AgOhg0iIiIiimgMGsHDsEFEREREEYtBI7gYNoiIiIgoIjFoBJ+iauQyEREREVFEYNAIDbyzQUREREQRhUEjdDBsEBEREVHEYNAILQwbRERERBQRGDRCD8MGEREREYU9Bo3QxLBBRERERGFNBI3p06czaIQghg0iIiIiClsXgobNZpNrKJQwbBARERFRWGLQCH0MG0REREQUdhg0wgPDBhERERGFFQaN8MGwQURERERhg0EjvDBsEBEREVFYYNAIPwwbRERERBTyGDTCE8MGEREREYU0Bo3wxbBBRERERCGLQSO8MWwQERERUUhi0Ah/DBtEREREFHIYNCIDwwYRERERhRQGjcjBsEFEREREIYNBI7IwbBARERFRSGDQiDwMG0REREQUdAwakYlhg4iIiIiCikEjcjFsEBEREVHQMGhENoYNIiIiIgoKBo3Ix7BBRERERAHHoFE2MGwQERERUUAxaJQdDBtEREREFDAMGmULwwYRERERBQSDRtnDsEFEREREfsegUTYxbBARERGRXzFolF0MG0RERETkNwwaZRvDBhERERH5BYMGMWwQERERkc8xaJDAsEFEREREPsWgQRcwbBARERGRzzBokCOGDSIiIiLyCQYNKohhg4iIiIi8xqBBRWHYICIiIiKvMGhQcRg2iIiIiMhjDBpUEoYNIiIiIvIIgwaVhmGDiIiIiNzGoEGuYNggIiIiIrcwaJCrGDaIiIiIyGUMGuQOhg0iIiIicgmDBrmLYYOIiIiISsWgQZ5g2CAiIiKiEjFokKcYNoiIiIioWAwa5A2GDSIiIiIqEoMGeYthg4iIiIgKYdAgX2DYICIiIiInDBrkKwwbRERERPQvBg3yJYYNIiIiIrJj0CBfY9ggIiIiIgYN8guGDSIiIqIyjkGD/IVhg4iIiKgMY9Agf2LYICIiIiqjGDTI3xg2iIiIiMogBg0KBIYNIiIiojKGQYMChWGDiIiIqAxh0KBAYtggIiIiKiNE0Jg2bRqDBgUMwwYRERFRGXAhaKiqKtcQ+R/DBhEREVGEY9CgYGHYICIiIopgDBoUTAwbRERERBGKQYOCjWGDiIiIKAIxaFAoYNggIiIiijAMGhQqGDaIiIiIIgiDBoUShg0iIiKiCGE2mxk0KIQA/w/1Pc8ccDNj5gAAAABJRU5ErkJggg==\" width=\"737\" height=\"279\" /></p>\r\n<p style=\"text-align: center;\"><span style=\"font-size: 18pt; font-family: verdana, geneva, sans-serif;\"><strong>NỘI DUNG</strong></span></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 14pt; font-family: verdana, geneva, sans-serif;\"><strong>PHẦN 1: Giới thiệu chung DN Nguyễn Tr&igrave;nh</strong></span></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; Doanh nghiệp tư nh&acirc;n Sản xuất - Thương Mại Nguyễn Tr&igrave;nh được th&agrave;nh lập theo giấy chứng nhận đăng k&yacute; doanh nghiệp tư nh&acirc;n, Đăng k&yacute; lần đầu v&agrave;o ng&agrave;y 29 th&aacute;ng 12 năm 2005.</p>\r\n<p style=\"text-align: justify;\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/Capture.png\" alt=\"Capture\" /> Lĩnh vực: cung cấp cửa, b&ecirc; t&ocirc;ng xi măng thương phẩm; cống - cọc b&ecirc; t&ocirc;ng ly t&acirc;m c&aacute;c loại; cừ v&aacute;n - cọc b&ecirc; t&ocirc;ng c&aacute;c loại; gạch kh&ocirc;ng nung; b&ecirc; t&ocirc;ng nhựa n&oacute;ng Asphalt; sản xuất cửa th&eacute;p, cửa nh&ocirc;m c&aacute;c loại, tole; gia c&ocirc;ng sắt th&eacute;p,&hellip; v&agrave; thi c&ocirc;ng c&aacute;c c&ocirc;ng tr&igrave;nh x&acirc;y dựng (nh&agrave; nước, d&acirc;n dụng, cầu đường, hạ tầng kỹ thuật).</p>\r\n<p><span style=\"font-size: 14pt; font-family: verdana, geneva, sans-serif;\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/4hinh.png\" alt=\"4hinh\" width=\"734\" height=\"\" /> </span></p>\r\n<p style=\"text-align: justify;\">Nguyễn Tr&igrave;nh l&agrave; doanh nghiệp chuy&ecirc;n nghiệp hoạt động trong ng&agrave;nh sản xuất t&ocirc;n lợp chống n&oacute;ng, x&agrave; gồ lợp m&aacute;i, sản xuất v&agrave; kinh doanh cửa k&eacute;o đ&agrave;i loan, cửa nh&ocirc;m, cửa cuốn c&aacute;c loại;&hellip; sản xuất lắp đặt khung nh&agrave; xưởng, sản phẩm kết cấu th&eacute;p, x&acirc;y dựng c&ocirc;ng tr&igrave;nh d&acirc;n dụng,&hellip; Với định hướng trở th&agrave;nh nh&agrave; cung cấp c&aacute;c sản phẩm một c&aacute;ch chuy&ecirc;n nghiệp.</p>\r\n<p style=\"text-align: justify;\"><strong>PHẦN 2: Lĩnh vực sản xuất</strong></p>\r\n<p style=\"text-align: justify;\"><strong>2.1 Sản xuất cửa</strong></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; Nguyễn Tr&igrave;nh l&agrave; đơn vị chuy&ecirc;n sản xuất, thi c&ocirc;ng lắp đặt cửa nh&ocirc;m c&aacute;c loại cung cấp cho c&aacute;c c&ocirc;ng tr&igrave;nh, c&ocirc;ng ty, đơn vị thầu x&acirc;y dựng,&hellip; Với sứ mệnh mang đến sản phẩm cửa ch&iacute;nh h&atilde;ng chất lượng, gi&aacute; th&agrave;nh hợp l&yacute;, chiết khấu cao đến c&aacute;c đối t&aacute;c của m&igrave;nh.</p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/cuanhom1.png\" alt=\"cuanhom1\" width=\"694\" height=\"\" /></strong></p>\r\n<p>&nbsp; &nbsp; Một số h&igrave;nh ảnh tại nh&agrave; xưởng:</p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/nhaxuong.png\" alt=\"nhaxuong\" width=\"710\" height=\"576\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/nangluc.png\" alt=\"nangluc\" width=\"491\" height=\"\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/baohanh.png\" alt=\"baohanh\" width=\"491\" height=\"607\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/congtrinhtieubieu.png\" alt=\"congtrinhtieubieu\" width=\"480\" height=\"\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/showrom.png\" alt=\"showrom\" width=\"469\" height=\"\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/dailoan.png\" alt=\"dailoan\" width=\"471\" height=\"\" />2.2 Trạm trộn b&ecirc; t&ocirc;ng tươi thương phẩm</strong></p>\r\n<p><strong><img src=\"/images/posts/hosonangluc/DTK_7217_Original.jpg\" alt=\"DTK_7217_Original\" width=\"731\" height=\"\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/trambetong.png\" alt=\"trambetong\" width=\"566\" height=\"\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongtieubieu.png\" alt=\"hopdongtieubieu\" width=\"691\" height=\"572\" /> 2.3 Sản xuất cống b&ecirc; t&ocirc;ng ly t&acirc;m</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/betonglytam.png\" alt=\"betonglytam\" width=\"476\" height=\"573\" /> 2.4 Sản xuất cọc b&ecirc; t&ocirc;ng ly t&acirc;m</strong></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; Cọc b&ecirc; t&ocirc;ng ly t&acirc;m được DN Nguyễn Tr&igrave;nh sản xuất tr&ecirc;n d&acirc;y chuyền v&agrave; c&ocirc;ng nghệ v&ocirc; c&ugrave;ng ti&ecirc;n tiến, hiện đại, kết hợp nạp liệu tự động. Cọc được sản xuất theo ti&ecirc;u chuẩn TCVN 7888:2008. Phần b&ecirc; t&ocirc;ng của cột được đổ theo phương thức quay ly t&acirc;m v&agrave; được đưav&agrave;o l&ograve; hơi ở nhiệt độ 96&deg;C. Ch&iacute;nh v&igrave; vậy m&agrave; phần b&ecirc; t&ocirc;ng rất chắc v&agrave; đặc, kh&ocirc;ng bị nứt vỡ cũng như chịu được tải trọng cao, khả năng chống thấm tốt, chống ăn m&ograve;n cao.</p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/DTK_7340_Original.jpg\" alt=\"DTK_7340_Original\" width=\"594\" height=\"\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongbancoc.jpg\" alt=\"hopdongbancoc\" width=\"532\" height=\"\" /> 2.5 Sản xuất gạch kh&ocirc;ng nung</strong></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; Học hỏi kinh nghiệm sản xu&acirc;́t VLXD không nung ở các nước tiên ti&ecirc;́n như Đức, Liên Bang Nga, Thái Lan, Trung Qu&ocirc;́c... từ những năm 2008 - 2009.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/gach.jpg\" alt=\"gach\" /></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; Tích lũy các ngu&ocirc;̀n lực, ki&ecirc;́n thức logic chỉ một thời gian ngắn sau khi ti&ecirc;́n hành đ&acirc;̀u tư, DNTN Sản xu&acirc;́t - Thương mại Nguy&ecirc;̃n Trình tự hào trở thành nhà sản xu&acirc;́t gạch không nung xi măng c&ocirc;́t liệu với sản lượng và công nghệ hàng đ&acirc;̀u tại Việt Nam.</p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; M&ocirc;̃i năm Nguy&ecirc;̃n Trình có khả năng cung c&acirc;́p ra thị trường khoảng 110 triệu sản ph&acirc;̉m gạch QTC có m&acirc;̃u mã đa dạng đáp ứng yêu c&acirc;̀u của nhi&ecirc;̀u loại công trình, với ch&acirc;́t lượng cao và giá cả hợp lý.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongtieubieu.jpg\" alt=\"hopdongtieubieu\" /></p>\r\n<p style=\"text-align: justify;\"><strong>2.6 Sản xuất b&ecirc; t&ocirc;ng nhựa n&oacute;ng</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/nhuanong.jpg\" alt=\"nhuanong\" width=\"577\" height=\"494\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongcaitao.jpg\" alt=\"hopdongcaitao\" width=\"472\" height=\"646\" /> <br />2.7 Sản xuất điện</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/sanxnuatdien.jpg\" alt=\"sanxnuatdien\" width=\"426\" height=\"564\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongdien.jpg\" alt=\"hopdongdien\" width=\"420\" height=\"550\" /> </strong></p>\r\n<p style=\"text-align: justify;\">\"&gt;<strong>PHẦN 3: Thương mại</strong></p>\r\n<p style=\"text-align: justify;\"><strong>3.1 &Eacute;p cọc c&ocirc;ng tr&igrave;nh</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/epcoc.jpg\" alt=\"epcoc\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/hopdongepcoc.jpg\" alt=\"hopdongepcoc\" /> <br />3.2 Vận tải h&agrave;ng ho&aacute;</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/vantai.jpg\" alt=\"vantai\" width=\"496\" height=\"606\" /></strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/phuongtien.jpg\" alt=\"phuongtien\" width=\"405\" height=\"527\" /> <br />3.3 VLXD - Trang tr&iacute; nội thất</strong></p>\r\n<p>&nbsp; &nbsp; Nguyễn Tr&igrave;nh l&agrave; đơn vị chuy&ecirc;n cung cấp vật liệu x&acirc;y dựng &ndash; trang tr&iacute; nội thất; đ&egrave;n trang tr&iacute; v&agrave; thiết bị điện nước ch&iacute;nh h&atilde;ng, với mức gi&aacute; phải chăng v&agrave; ch&iacute;nh s&aacute;ch hỗ vận chuyển lắp đặt chuy&ecirc;n nghiệp. G&oacute;p phần thay đổi diện mạo cơ sở hạ tầng tại địa phương, th&uacute;c đẩy ph&aacute;t triển kinh tế &ndash; x&atilde; hội.</p>\r\n<p><strong>PHẦN 4: Năng lực c&aacute;n bộ chuy&ecirc;n m&ocirc;n kỹ thuật</strong></p>\r\n<p><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/hosonangluc/kysu%20(1).jpg\" alt=\"kysu (1)\" width=\"494\" height=\"394\" /> <br /></strong></p>', NULL, '2024-03-04 08:31:32', '2024-03-05 16:05:10', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE');
INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `summary_one`, `summary_two`, `content`, `content_one`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1979, '48xtbv', NULL, NULL, 'Thành viên của chúng tôi', 'thanh-vien-cua-chung-toi', '', NULL, NULL, '<p style=\"text-align: left;\"><span style=\"font-size: 14pt;\"><strong>Năng lực c&aacute;n bộ chuy&ecirc;n m&ocirc;n kỹ thuật</strong></span></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAGnCAYAAABrSimNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAHUbSURBVHhe7d0HWBRHAwbgb+/oHbGAKIooFiyx95qoib3X2FvEEjUxv930GGM3pplo7D323sWCGuyKvSOIiiAd7m7+PViqoKBrRP3e57nE27u9u112Z7+ZnZ2VhAxEREREpBrp0qVLIiAgQHlKRERERC8qd+7cKFOmDKRGLVqLHRvWKpOJiIiI6EWVrVIdp48ehtSiY1exYY8PtHU7KS8REeUwMZHQb5oD7fs9AMd8ykQiopzF4LcNXrmtcPbYESVg7doLk4a9lJeJiHIWER0B/fqZ0DbqDSmXizKViChn0R/bjGLWwKUzJ6FRphERERGRShiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAInrtJJiZmcLKPPFhaSIp04neDRoTebtXtn8rMy0PTPRW4HZM9JpZl26Gs/MnIuxv+THvC2xsnE95hegdYO6BmVPG44lx+/97PG7+rzpK88hEbwFuxkSvk+SArk3Lwd24J4o4nN2xCl22BCW+RvTWk+BWuyY6503YARB1+yi6zzqEM4bEV4neZAxYRK+RedGqGFzaHJLQ45bvBrRbdBnBQnmR6G1nWhDeH3rAThKIf3AOg6ZuxbYw7gD0dmDAInpttChXwgnBV25i78GtaPf7KVxnzZ3eIaaFCsEj7DYOnDuFkdP+weJg7gD09pBadOwqNuzaC5OGvZRJ9CzGzpjmWmPDtkwYEBOnh6pFgqSBuakWWuMXyJ8fK3++PvGVV0qjlZfLJHG5hF6HaF3GtUj7ImXQrbht4u+TCd1j7N7nj/Nxic+z5DUtY86jQb6CBVHcxljP0SHo9l1cjmTtPSMiOgL69TOhbdQbUi4XZSq92STkyl8Qpe3lAlUuRR8G3MaFJ9nc/iWtXJZokssS1ctjomzSH9uMYtbApTMn38KAJVmiVEk3uFsoz7NEIOTuDRwJjleeZ0aDkh92x55uRZHbeEw0hGLelNkYcDI28WUVaN0a4Mh3DVBeDjvQ3cG4//2BH++96oOuCVp4f4FVta3kJRQI910J15lnEa28mkRy9MJfX3bAx3m1iQHTSOhwYfsi1Ft4DY+z+DNfzzLmPOaF62LnhA9Q3dK4Ng0IOr4OtaefwE1mrKcwYOVEEmzyuKJOcRcUdbSEpVxNiogMx827ATh89REePyfpaJyrYMPXzdDYNqEwRej57aj7wyFcyEZty8yrOc6PqYrCxo+Iv4xPvBfir4jE14heh9QB6+07RajJi979umDdyG7ZeHTFd5VtlA94FgP8t69A1y33EGE8CGrs0b5Jebgnp403i9a1DMZ3/RA/dm2EjwubJIcm84Jl8Y08rWcRY81SYV4AY4a2QldjuBJxuPzvaewPNUBIJijZqD0WNcoLM+WtlAVmBTCqX11USwhXRho4V2yMn993egt3SnrbWBcohymjh+H2jAFYP6glpnZphG+7fIQZ/Tpg3VfDcGfOQCxp7Qm5WMmYNg+G9G2IhgnhykgDh1IN8GszZ5Yj9NZgWZ5dIhp7li7FJwdDEC/kGlzJahhUPLNSJGczcS6GT5rUwohmNdC6oJkSsCSYuZbEp/K0lgWUgGWaF/0Gd8G44paQdGHYsWoR6k9bhaZfr8LPlyOgl2zQ6OOu+KOGI1JFMsqUGWq3a4XP3eVDSUwwFv21EmNPhCJeskbDTi0xNGm9E+VA5oVrYd2Ethha1gm2moxqlxLMHVzRoX1X7OpdHHbK1BRalG3aEhNKGsuTx9iwZCWGHX6IaJijeqvWGFXUVHnf62KK3LnsUdAp8eFsnf390dzaFgWU+Qs4WspLRu8ibfHSZb+8dP0mNB7llUlvOgkaTTxuXr8Fn4s3Ex+XQ2Hllhf5TY2FgQEB549jzqErKa/Lj4MXbuDkI13iRzxXDM6fuo4HuXLDJjYO5nHBWHf5iSrn/jX27uj7vjtcjNHX8AR7dvnhUHjia2rT2ORBNWcN7j8MwxNTW+S10MhrT0AXFoxDNx7gxOkz2HPfAE3eAqhhGYpD5y5jweoNGHP4ASLl+fURwdh+4DQOPIjAletBCIYOt248xpPEj8/Uf7mMOZGUqxRGvJ8PcQ/vYN5fK/DF0bs4dNQfF8wdkU9jivzyut564THUO/H8FtDFQVw6mlBOSZa2ykT6z0kO6DewAwa6mSZUyETMQ2zbdRAzdvhh+b9XcTQgEloHJxSyliudsfcwe+Ee7AhJVzJaF8WgJoVg+jgQKxevhPf+Wzh6/Bz+lT+7gIkWLjZR2H02sYx5Hm3e4hhUuwAcEor2R9i0+TROZqc/aAYk+0r4Z3ZvzGxWE582qY4udgH4xe9RNvqJmqL94M+xr18dDGsif0a9XLiw4xzOZ/Xwkm1alKtZGx0KmiD6STiCY9kL7XUSAVfgJNedhwz85B3p5G5SDL/N7IY+uYxHdD38Vv+Cmmvu58iO1Tm5D5aRZOGACkWd4e5gCQt9NG7fuYujdyOyFQbUW0YJNrldUKVQLrmWaQJdZBjOX72D82GvrCSj14R9sHII20rY+HNLfGgmJxoRg+1/zUbz3WFyqZGKqSPadG6BDsFb0W1bMJ7Xs/VlPLsPlgny5LGHo3JnBBETjmuPY9NUhCULWxR1NE8IixB6hIY8RnjJlrjwRWUUSKgARmPdr9PQ/mCq0lAyg5t7QZTLawN7rR6PQ4Jx/GowkrvwalzxzaT+GFXQ2PIlEHlmI0pPOoa7r6oYl7/vW/n7/id/X/ytvagxZjdOMWO9Nm93J/eMZDlgSfBo0Abz6ueRd00g7tJeNFsejFof1kKvMnmRz1SHW0d3oef2AGjyVcJf3pXgmfCR9/Hbz+uw6GHiHpT6NRF3DV/9sAunPapgbIsK+LBILuQy0eHRgyDsP3IY3225gtupfsjT4WMufjUth7Ftq6J5USfkkX9DiDzvvsMH8e2Wa7iTjR3JPG8xDGpeDe1L54eHnQniI0Nx6rQfflh9Arm6fv7MgCXZFcKgTo3weU035JcL18QiSyYXSo/vXsKcldsw6d+QLAWtl19GCXmKV8V3XeqgczFbWEjJvwZCF40LJ30xYcl+bLifSdCSLFGuWlUMrFUcNY3hzFIDfUwkbt69i52+x/Dzvtu4n2lhaILabbvg+/cS11X8nWPoPvckbqd/v1wb79avPQbIhZ4kF+l3D29Al61ByjanRYHi5dCrTik08swLN3tLWMmHoYcPH+D46ZOYsek0TqS5mjD1dikQfX43mqwIROWG9fFFXU9UzGcJ07go3LxzA6u37MOM06Gv9KD2OjBg5Qya/HXh82NDVDHuu4YnmPfTNAw4ld0KjYTcRcpi4Adl0bi4M4rYm8NUH4vgB/dx+NQZzN15GseyOBbWMwOWtjCmTe2FIfkST/HFnVmPwpOO40Gqj7au0xX3B5ZMPIUnL89f05fgyoc98b2XZUL/GX2IH9p+vhabjYWhZI1ajRvhu+ZlUd3RFCnFjoA++jH2H9iH0atOI6R8e+wdWFoJaJH459dZ6HKlJP58wWNCEsnaBR0/qo7u5QvBK681bCTjPPI6uyWhXu0icJVL7D2LfsdH2x6qcjaFXszb3cn9pUiwzpUPlYsWQBX5UTl/PnT27ou1XaqibVl31CpZBO85KO80t4NXkcT3VfHIK4eOxOlGaV4rkgfFKjbDrjHN4F3BFUUcLOFgYwsP92Lo3bkrdvQpibwp+SAdCbYlGmHnxDYYUbkAijkmzlvEOG+XbvK8JZAn03nTsi9eH1u/7YZJHxRHJWdbOFpZIm8eFzT6oCm2TmiFlk7G04MZ0+Qugz++7Ilp9QvBNXW4MpK0cCxYCmOH9cPaj5xhqUzOuuwuowS3aq2wb0xT9PK0SxOujCQTS3hVrocVX3bF0EJP9+WQrN0w8ovBODzkA/SpUBAlnKzhIK8Lp1y5UbHsexjVrw+OjqyGspl2A9Hh9O1IFE74+xZEjVqV0D7f02tOk68M+tZyQ1XjNuBuhTvXHySGK3Nn9PX2xqkJrTGhQQlUK5AL+W3lZba1Q1F3D3Ru1Ra7x7yPWmmugk27XVZycUKzXn2wtWc1NJEL53zWlsjl6IQKZSvhu897YU5l60z/lkQvwxAegUd6JaFobNCyeV00zG1MW1kkV25qt+4Jv6/aYUL94qia3x55rC3gYGcPTw9P9GzbFvsm9cZEr9ewDcsBqt0nffB9qcRwJXQhWL54D7YkhCsHtO/fD1u6V0SNXKnDlZEErWUuNGjcCrunfI5/P/FKDFdy5TPg3+0YcyhS3u9f7pigyV0Wf33THwvbVkDDIk7Ib2MBO2sbuBf2QNe6xnAVig2LFqDTdoarnIQB6xnMvOpjejV7mEoCQsgPQxzO3QxWXs0iM3dM7FcZJUz1CHnwABcCwxFpUAooyQRFatdD/4S9MQNaV3zRtyYqWOjx+OED+AdFICrVvB516qGvaxaKIQsPfD2gHmrZJoUokdB6dSngEYJiBMzzl0X3UhYZF2iSPXr0bI7uLol9LoyFxqPbl7Bg+xH8cfgGbsjzJ7xNa4sPOrXBFx7Z7BCazWWUnCpgZu/y8DSeopAJfRTOnjiBX7Ydw4oLIUhs+JFg4lAU3w2og8qpy355Wbr264RvytkjcXZ5PUSF4dKdB7gVoZOfGd+jhet7jfFbM+dMO+w/OX0aG5R+JZKJK9pUy51uR5JQorqX/N2JvzH+3jksu2KMV1pUa9sBs2rlg31C52Dj9z/B1YBgXA2NQ+JiS7Bxr4Gxte0z/nvILLzex+/v54GFvOy35HmvyPMmHfMkk1zo2qoKvLhn06sQcQO7r8Un7ivyVu9Uqj42T/8f/L/ujoU938endYqjslPSBTPpSShctw2WtfNA/qTTdroYBAQG49KjaMQr27+pgzvGfNoOA5wz2wNeEXnft7c2k5dKLovuXMA30+ah3xHj6U8JBes2w+w6uZF40a+ALjwIW/b74uddZ7A/OC55fdg42MI4rFd8xH2sX7sc7/98AteUfTNZto8JlmjTqQm6JpTBAjH3L2LS/NXo/vsOzL8WlRio5HBYxMlUWYeUU7AYfgbJzAQi8DSGfjkVjl2/hNu4RfjhXPaawyWNXDvR38K3301FgaEzUW7EZBT/6RguKgN5Stp8qFncKuMCSa4michb+GHSdLgOmYmywyfDa8YJXFWOpsZ5a3lmMm8yCfmqVUdXZ2XsKkMMjm1ajBKfTEHpz6fDbfBvGHrscaY7prZgRXxSLrFGJ8+M0As7UH/sIvT9ezMGzZ6HKlN84Z+0LGbOGPBRCdgnPMuibC2jBmXqV0XjhIE5ZYZo7F86F9V++gefLtiAj7/9Ba23BycX1BaFqmBIxZSmIKvSdTGhsp0yKGEcTu9cjjIDf0LpL2ai6CfT0WpzAMIMBoTfu4iVF8IzrwnG3cDSoyFI2BLkQrl8lTJpb06ryYd2VVyQcAwROpw6ckbpE6HHsR0+2BxmQGSgP76Z+QsK95+Mkp/PQslBszH4ZLRSWJqgTJHMLleXa8tyjV93cS8aD/0RReV5S3lPQ6tdD1IOUAULoaZt4hojUpUIwZ8rDsEvOmXvMLYaFy3mic6N62PKwG44NOt/uDy+FYaUsEl7gDEviv+1LY58CRMFwm8cQfvPJqHwiFkoPXgSSvzkg6ORiZ+rsfXAmDYloZww+G8Yy5MNK/Hh6J9Q6Iul+Oakcqpd3p97NSqGhB4mMkPkDYz+6le0/G0Thv+1Eg3HLMacAL0SsuQli7oE789/RrtV/pCz6FOyfUwwdUNjL2OXBJkhDAvnrcD4HaewbN8BDJixFz5x8nySKbzqV0Nz64Q5KIdIs/1TOvpHmPvnOvx6KRSRQo+gG7dxPrsjbcsH2KOb1+Pb8+FKvxiB+2f8sDZQKaDkgJHL3jrjP4Q87/FN6/HlmTBlXgPunjiOtUFJ88o1SMd0hdhTTFGrTCEkHW91945hxPJLuK3kRBF5D7/P3YF14SkFZgoJrl7uKJ00bLsczrbtPC4HqsSnxmUJvXAYf19LKlw0yFWyGKpl44xBtpZRskO9knkTg4vMEHkZv+15gOSLhkQM9m89gWPJpzAsUbdcQSWomKB2tRJwU1aWLuhfDFt0HteSZtaHYcuy1RiwYCVqjV2BGZcikwvMp+nhe+gcLiQUiMZA44X2CZ1AEpkWKYu2CX2v5J8UfwcrDymnB2WGh6cweOoCfDBhKb72DURw0gvyeohN+t3ynFYWxpp0xkT8XUz/ay/2PlZmFhHYue88LilPJckKee2Si2ciVUVe3oOmP2zF4uuRGVbMJI05CpeqhKlj+2NeDYfk7di8pBeaJKUUuWz9a8F2rA9OKkz0uH1yF4buSOoUr0G+97zQ4D8d3yAeVy6cx+5bEWn7n+ZyR52CSa3/Bjw+dQx/yoEqiZAD16y9d5PXhWSRH9VSlQdPye4xQTKDjXlyoYfAkFTf/SQcQYkfktA1xc2e+31O8oytgPRhN7D9irL1vijDYxzxf5y2NUQOAuGp9mATTSZ/BkMoDl0ISTuvXMt6nOr6ZdPM5k0i2cMzb9LB2oAHV27iVMr+mUBEXMWu6yk1sBQaFM5rn3xbHOOy+N9Ntz7EE1y4pzRTy7R2uVA0O60n2VlGrSPcU/UV0wc/wIV0veoNIcG4lHy7DQ1y53VCbuMMcjgrW8BaOe1nwKNL13A8/Z9W/wBrdsjBKQs99fU3T2PVTWWdmeRGm+oF5ChrpEXV6qXgmfBFApH+Z7Ayda9aY2F69Rr+jdDC2a0I2jWoja96dcCOn4bgt0pKLfU59A9uwyddL3wRGYuUkS400GbzTC1R1gmEXDmCXmOnoNRXK/DZun+x7sJ9BMSkLUOMp6s7d2uI1gljOEtwK5gXeZQN3BB+C3uvpz8boMe5C7eRlDM0lnlR2jkre8SrZZonFwomj/clcCPgPqKUZ4kEAgIeQLnGSf7hVvBwfsaZheweE3T3cV5eKQkfr82Dj6rnR+Kw2BoUqlIatZTBig2xYbgZmrZcoNfr9W+9OZgh9AnupdkLXoCIRajS7J1t8k739LzZ3IE0ZrBOrgUKhEUqp6HSiMfD8KR+BGlZmqVujoqDfBx/SmRMUp8MI1NYZ+c2RdlaRhNYpup8LuLi0hV0MiH/xlTVaslMrv0l/MMSdsk98AUeR6SEwhciHmL54duITvgqLYpULoPqxlVlWggdKudKuArV2OK3+9AFBKZeHPl3VHm/ObZPH4Ubk3pjWb/GGNOoLOrl0+NGcEZ/m6eJKDmAvtSPJ1JDPG5eOotZK9ah/TezUbjfZFT4aRuW3kkZCkFj54m2pY1tyBLsrVKaowyRUUg/PJaRPiIyZdvWmMPRKtOYoornVlCNzExTDRQqEBWburxLJOQyMLEsMJJgYa4M/ZCR7B4TDA8wd/1p3DS2mEtmqNK6L65MH4Sjkz/HqYFecDUugtDBf68vNj1VINLrxID1LHp9pn2Tsk68xIH8ZeZVGE89JVcUJViZK53V09DAxjzlVjmphUenDl7msHuqwEssOFM2pLg0NbHny8YyygXTk9iUXyNZWOCpM2EaeZpFykQRK8+T8K94yGWgQpJDZ2YdcbNK4JbvGRxQSlWTPCXRsZQprLzKorlT4towRFzGMr/Upxq1qNCyG7b2rooGzhbQxj7Crl27MXT236g8dDra7w9JPpX4TMYLLpR/Ev33jJ3BM7jMVheJcycOovfPh5A8coNcwSuYN3Es9+j4lBYrSQ4gGWUnTerpctkV/ZInENJKdwW0/Cyv3fNbjUV0jHLxjJEEG8vU5V0ijVyLTWm4l0NYTMwz9tHslusC94+tx4ezj+O08aIiyQS5nV1QoaAdbDSSvJrCcXDbarRZfjNLg7PSf4cB621neII7j5Oa7iU4u+VHgfQFm4krKhfKKGAZcOXuIyRnGm0uvFc4XfOUxgnl3ZI6wcuZNOwRLifcqPEVMDyCf2DKaQiTfC4on65Tp9YlP8pYJ/0aA+4HPUSIcQZDKC7fTwqL8npwL4Ai6RdYskHzth9hsJd9lu6HJh5fwLJzSquTxg5Nq5VA8+rFkT/h6w0I9DuNralrlCaF0eeDArAzvi5isGPJPDT5ay9+PXwVpx/rYGnK83qU00nIX7UVfH9oj14uGW+v+kdhCE5VBMTLFVXj/nAr8HFyUNE4uKDSU2PMyJ9dxBkFld1XxD/GlftZqnJkQkCfKslINlaJ3QWSWaCiR26l20DmdEEPcDW5pq1B0cL54ag8S6SBZ2FnOCYXOxG4GhidXE69PAl5vOpgRudyKG0Wi7PHjuCnDfsx6Z9d+OKPpagzfBrqLzyH6y+zquiVSNok6K0VA9/LKVfWmRatgglVHVIVKmao1LQBPs6TUTEj8PDsJRxWhmKQq51o9FFt1LFOKqW0KFyjHnoXSprXgODzV3A0fdcKtYgo7Dp5K/FG2zLJsiiGtHCHY/LPcUTHVhVRLumspiES+07fUTrBx2P/yRsITShw5fVQpCq+qZc7VZDSwq1qI0xuVQPTxgzFqcHlnw5gT4nCpoOXEJyYsOBSvRlmVFU65MuBbt3B62lPYWpt4ZxUzRVxuPMgIqUQluxRs7hyalGmNTFR+nQR5RzmbjWwoG85FM1TEnPGdsX48o7pxr4zgVfdMqiaXCREwP92Yhty5IXL8IlKTDyS1hUD2peDe6piR+vkhS8bF0Jif26ByCuXsTt5VPaMCYMhsYJjJJnAOqkzuJEhCiGpdkCTgiXRTq5IJrErVgODy1o89yAowq9iy+WUyplt2Rr43HgfxYTnxj5aZTC6vnPy/mpI6LurYtrR5MfQHvXwkbM5NPoAzJ2/BWOW7cT4Vfswfe8F+D5UtZmPVMSA9dYTuHzoBPYlF2y50GWwN06O6Yi5/dti9ddDsbujOxwy2RLEo1P4cd/D5IBmUbgWtkwZhJ2fd8GGL4fg+CfKiMUyEXMPv2+5jOeUiS9B4M7BA5h/T2nFkkzxXtMeODupN9aO6IZ9P3njr2r2SniUC+jrRzEz+cZkAsFHffDbbaX/hMYOLft+gjMTOuMveT2snDAEJ4eUR1ETCZJcUMeHPEJAcvrJ3JPTZ7BR6TSisbBGbqWA1wWew9JL6ZKmPgx3k0ao1tigeZM6+LCAPVzyuaFrt/YYWyLlhtuW732II991wfCkyx6JXjsJhUt5opyVcZuUKylOnpgw8lNcm9IHawa3xm/yfrRq4lD4dPVQWnME4gJOY7F/YtgQYWcxdc+DxBZxSQO3am1w7KfeWP5JK8z9tBdOTmqPrvmUq291j7Bg/amn75CQjj4sHA+SEpa2EIYPaY+5HUujUMKHhODo9fDk0+6SaX6MGTMIO4Z3wIr/DcTpsfVQJVV3gkyJMCxZ74dLycPRuGDE6E/hN+5jrP6iH07/0AbtlG4BxorTvzsPYWtM4lO1SaZF8OP3Q3D4q37Yb3x82Q97xvXEP4ObYUwt12cMWk2vA0vvd4DhoR++WHUNwcpgdpLWCiXLlEHP+uXRspg9zEIuYpV/Zn0G4rB/xSqMPRuOxPLFeKd8Z9SrWAofFc8NB+USQxH3CKsXrMFPt15xO3XMDYz/ZQd2hyaFLBPkcyuCZpWLo6aLpTKEg3EwvnMY/qsPTqf+OXF38O2czVj3IHFQUUljAY+SXugur4fWJXPDLuFKIQNCr+zHwLW3s3Z/xbjrWOqrjImVROhx5shp+KVfFbrbWOwTpHSG1SBf2fex8aeRuD2jP/7+0Bl3jp7DaeOYNjLJxBqehd3glXTZFdFrJ3Bp+wq0W30Fd5WwYdz/8ri6o0XNiugj70etSuSCrTKIrv7JDXw7dx+OJO8c8Ti0ehW+OBmWWGGTQ5aDSxG0rVsJPat5oKRNUrh6gp3LVmLM+efvgYagS9h6S6k0ScZbUJVFtzpFUSKhlqXH/u2H4BORlMAkaG3yoH6VsmjznisKmAncO30ae8KS28AyFXFhJ3ouv4agpPH5TG1QxqsEWpYvhGLWyhiDIh7XfDejz8YgeUlVZLiHP/85iQsJZxLkypdjXlT2LIQaxkfxQqjtVRTNa1bDV979cWRoebgn/BjKCVh6vxP0OL99GRr/egS7AmOUoCSXB4Y43L5wFH0nrcGKh8plwBmJvYfpP/2B1itO4cijlFHDjYz3/rt89iiGfj8XH+9LNSbVKxR1/RBaTliCCQdv405M6t8tEB/xELt3bsSHE1cmtHSlF3f3X3QaNw+Dtl3C2TA5aCXPbJw3GNu2rMX7k/bgcJY76utx5PC5VGODGdfJXaw6FJxBh3U9jv+zDN02XsblyKS+ZAKG2FDs2/oPOvyyBn0XncKxRzGI1+sQ/iQST/QsLSkHEVE4sHYh3huzHON2X8bJkNjk8iRR4j64f/9OtB6/ED9cSVcixAXhl6m/4cOFx7ArIApKfSKB0EXh0rnjGDnpd7Tacu/pK4QzYriPKb9twPzrEckXJGlsbOCsXPanD/BFx8lbsPBqeEpfUuNvjHqEvTvWotmMjfjzQkzKacZMxcNv8yLUnrILSy+Hpoy8bmS8H2vgVfw2/2/Une2Hiyp3kZDsCqJRUUvEp15ZGZEDpluVBhheKtV5V3qt3o2bPVMqWjjmcYK7rQbhjx7hatjTlxw/m1xjdc6LYo5mcvCKwp3AB7iTcn3yf8/UGsUKOMHFAogMD8OVgDAkD4P1PMarcfLkQgEbE+gin+B6cASi/qtFMbGEW1575DbRIeD+I9xPdXUkPY03e86pJFjZOaCQoyWstQZEhT/BjYdRqYYseBYJlnaOKJLLAub6GAQEP36J/UAD+9y54WGXWbkmwcYpL7xyW0IT+wRX7obg4UsEIXM7J3g528JGrlI+lL/v4qOUoSlUZVoQX37VC2Pc5fJW/whLfluC4YeDkdiXVCaXYc5Fa2DhFx+gfsIdLvQ4uHgG6m9+nPg6/ed4s+d3mlzbehCME9eDcCXb4cpID52ZPUp7FESl/FZyxe41BwOdARZOxhshu6K4DZDUHz9LhA4Pg4Nx6vo9nLv/H4YrI100bt8LwonbDxmu6A0mEPXkMfxv3cO/cply4UFWw5WRQPSTEJy/eQ8n7oS85H5gQNjDZ5VrAhGP7uPopZs4cvPlwpVRXLwG+QoUQNWi+ZBPDpavJFzJTAuVRBu3xL6ZIuoO1h1NFa6M5DIs6NpVHHmUtMQC+pRmeXrNGLAoW6RclbBoYhfM6doYU717YXunQq/xajcJBRq0x74RLTGpS1P8PbYXvivO5nEieoUkK3Qa0A/r+n2I77u1wdaJTdHkFd3SxxATn1zx01gXw5CWReGWusDV2qDGh/XRXbnSSOhCcPRyyj0d6PViwKJsMcnliIJJl0JLGrjmdcjSmFGvhgb55e9PGphQ0trBPcPhJoiI1GKDIrmTBhuVoLVzROFXNOK8PuA05p9T7jqhsUbdtj1wee5oXJ02FGemjcCduSOxr1tJFDBebCR0uHFoN36+9nTvT3o9GLAoW+Jvncffp0MQYRCIC7uHeT7pxnr6T+lx+qgfdtyPhV4uXIKv+2HReY4JQ0SvkHiIdfsu4nKUPqFj/pmDJ7D1Vd0DUITgj9kLMHjPTdyNNV7QIwc6c2sUcsmLki654GxpvIJRIDY0ACtXLsEHc8+nvTUXvVbs5E4vRNLKO7Ze/8r6HmSPBOMg6PGpL2+ktwo7uVPOo4FWY0gzWvyrJFk4oHzR/PDKZ4fcVqbQCj2iIiNwK+Aejlx7iBA2XOUI7OROL03kmHBlJBiuiOg/9t+FKyMRE4oT5y5g0W5fTN/ogymbDuOXvWew+TLDVU7FgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpVJ8kMk/MvJNeF/REQ5Tlw0EB4CmFkCtrmUiUREOcyjgIT/CSEgOTg6itDHj9G8Q5eEiUREOU3Iwwc4tGcnSpQph2IlvZSpREQ5y8aVSxP+nxCwvL29hZ+fH3x9fRMmEhHlNEFBQXBxcYGxrKpQoYIylYgoZ+nfvz/8/f3h4+PDPlhEREREamPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsejH6WERFxUKvPCUiIqIUDFhvvRjcOLIZGzdtx6n7BmXa0yKuHsTmjRuxac85PEr3NkPQZnxWPS+s7Yug8bhtuCenqtAFbZErd2csj1LeRESUwxjCLuHA5k3Ycz4EmZd+aUXdPoaNC3/BtB8nYfL037Booy9uhmd1bqIUDFhvO0Mw1o9ugxYtu2LakThlYlqx539Fl7r10bxlZ4zbGJCuINLjyt/fYs4FVzR83wHHJrVHk0Hzsf7YNQinvMirVd5GRJRDGMIuYvP0AajvVQ71mrVCv9/PIF55LTOGYB9M61oebkWroUWPQfhs1Gj8b8RAdG9RA0ULlkLrr7cjQKe8mSgLGLDecfpbK9Cv1TBsCtTA4+M/sW5KY+RJs1XE4+rVW0CZLpi6chfWj6+EwL/6oOcfN+HRrgOqmytvIyJ6nQz3ceTviejXvBLcXEuj+Yg/cCAgFkJ5+VkMD7ZhRMOP8PnSM4hzb4Ihk+Zi+T9rsWrhbEzoUxcF4i5j3Zcd8cmCwCy3hBExYL3DDMHb8HmrPlh8zQCXZjOwbm4nFH6qRcoUpT/+Eb+MbgJnk1yoM3EbThxaj1UbfbFvSgPYKO/KCfQ3fkXrIgVRsFBFfL47VplKRO+E+LNYOOE7/LnpBB5YlUaLEXPw2yel5RLseR5jy+hPMOdsNHI3nIz9fpsw63990bF1K7TrNhhf/bkXp/b+iDZNh2F0RxceNCnLuK28q8J98X37Lph1KhqOtb/EmiUD4ZVha5QWhep1Q++mXrBOeG4O1yrN0a5puRx3elB/7you3LmLgAf2cCv6/GKViN4iWlc0GPwD5m0+gVt3TmHd1AGo65ZYaj2L/uo8/LTsNgx2H+DL34ehfAa1RoeqI7Fm45eokZNqlJTjMWC9i2LP49eubfGVTyisyg/D8tWjUc1WeU2hOzMT7WtURY2203HqGf0OEt9XDbX7L0HA89rOdfew/+dP0aZWKbjldYS9gxPyF62A97tNwLIzYcqbFIZb+KOdJ9zdi6PX8lBlYjoxG+FdugjcPVtg1qVYXN3rgxt6Cba126NVQW7aRO8Uk5Jo/8VI9GryHpyz3HVBjxtr18I3WoJ9o17o4s5OpaQeHoXeNfpbWNGvFYZtCoS2WA/MWzcZDdN2ukpgUqIqioSewJENczDvYIwyNb1Y+C74Bet8z0Bbohqcn7U1Ge5gec+aaDh0FtYdk7/buShKFHWFxePz2Lv4G3xcqz5G7kp1pY/QISzoJm7evIWg8EwGgzBEIPiW/J7rJ7BmXHO0+OFf6O2rY+S3PeDGLZuInisCR4+cRbwwwXu168BOmRp57xwO79mO7XuO4HwgL5WmF8PD0LvEEIxtn7dCn8XXYMjfErPX/Yb2bpnU2Mwqo8fHFWGuv4k1C7YjXJmcRtQ+LFp9DXq7Bvi4szueVffTnZ6LSStvQhTqjAXnAnDjzHEc/fcMrt+/iQMzO8LTwQF2Fsqbs0t/Dwc3+EFbrR9+3rYRYypbKS8QET2D7jau3o6G0OaBR9FcMNzaiHFNiyO/W1nUfP9DfPh+DZQp6IyijT7DsguRykxEWcOA9a4QkTjyfVN0nnUK0bnq4du1i9Cv5LPa0bUo8XF31LE2IGj9Aqx78PT5v7Bti7H+rkDuj7qjrcuzNyXd7VsI0GvgVL8z2numCkAmLqg1dDnOXt+J8bVyvdgGaVoe44/fx6Xdv2Ng1Rf8DCJ69xgeIyRUAJIdHLENQxp3wBQ/K9TtOQLjvpyALwa0RoXcsbi+czq6fdAZf1ziOA2UdTwWvStEDK76nUOoQQO70o3Q2Ov5vTU1bh3R88NcQOhOLFx5J+3lyYZgbFi8GQ+kAmjVo6lcOD2bqWdxeJgIPDqwFluNI5WmY2LyMn0fJEiS8k8ioqwS8YiPlwOWeIIDX4/AP86jsfuCHzb8OQXfTPwKP/72D46d3owRFa1gCNyMseNWIJjjNFAWMWC9KzSOaP39TLQrpEXYgQlo2e0vXHzuSAZOaNGzFfJrIuGzeCkupcpFhsB/sGRnKDRFO6Bng+dfqaMt3hfj+5aE6fW/0cGrFN7/eAS+/+Mf+Pg/AAdUIKLXQjKHhYVcO9MH4NjJvBj2y1jUzJX2sKjJ9wG+ndJbriAa8Gj7Cmx+lDid6HkYsN4ZGtiU7ItFG6ejqYvAnbWD0KL/CtzMpP94EpsPeqFjUS1i/ZZg0Ymk5nE9ri9fiv2RpijXpQeqmCmTn0WTF01nH8C+Pz9DC88YHF8xA2MHtEUdr/zIW6QOek/bh8Dn/BYiIlVp8yBvrsTmb5MSjfCRZ8Yt6RZVGqC6gwYi+hLOXsr4jhhE6TFgvVM0sCgzCMvWfYf6uXW4uqgPWny6CYHPavI2r4qeXd+Dme4ili84gITrCXUXsGSZL2Ita6Jbt5IwSXhjFmicUKX3T1hz9BYeBvnjwOrf8LV3UxQKO4K/P2+G5l/5Jn5+VsXHIPZ5978gIsqMtgA8PewSDoRSLic4ZXZENHGEo738oohEeERWxoYnYsB6J9lU/gKr14xFDYdonP31Y7Qau/epGzynMEGpbt1R28qAW2v+xtYwIM5vMVac1sP+g27oWOjF+k6ZORVH7bYDMP7ndTi2ZwKqWETh5B+/YUfyFdFJ/aoEDHp9hren0N26hXsGFnZE9KIsUbVmRVjKZY14EIxM74eve4RHofKLkj2cHNnhk7KGAesd5Vh7Iv5ZMRwVbcJxbHJ7tJvkm/FQDDJjZ/cejRyA4I1YuO42fBatwmVDHjTt3vrZY1+lZriP4wfOZfgdFiVqobL8QYbHAbj7RCnhtA5wsNPKMUvg3u1bGQQsPa5v340LvKiHiF6YBi6tOuF9ew10l7Zi49mMT/9F+OzAITlgaRzLo3KprPSJIGLAeodpkLfhZGxY1B+lLUKwf2IbdJp9BhkOqafJi1a9WsFFCsOOWf3x7erbgFtr9PxIDl1ZEgGfCU3xwQcfosMkHwSn6WtlwKMDa7DrrgHa3IVQ2CFpk7TDe+WLwQTx8F82G+vSXXkYefZ3fD7jCGLYgEVEL0Hj0hljBpeDhe40ZvQfg6330tba4m6txWefLcAtgymKfdwfH6W76wVRZhiw3mka5G8xGxv/6oZi2iBs/awFesy/hIzqcLaNeqG9hxZRJ7Zj330JxTv2RJ0sj+dpCbfSpZBHcw/bxjRA8VL10K7PIAwb5o2eLaqgTPNfcFFvi6qDBuH95MFGTVC+lzc+cNJAf3Mxulasgha9BmPY0IHoIc9TotoQ7Hasj9quLzO8AxG9LQx3lmFok0Zo1Cjp8RH6L7gEYweDoI3/Q7Pk6Y3QdPRGZS4jC1Qd+zd+bOKCaL9paF6yOGq36Y1Bnw5Fv471Ubpce8y9EAeHGmPw58Q64DDGlGXe3t6iatWqgt5S+ltiel0zAY2T6LY2WpmYXqy4OK+9KGQqCcncU3yy6aEyPbV4cWpiBWEqQUhmVcS353XK9KzSi+Ajv4uhTcuIvBYaYezyIG9+ApKJsPeoL/rNOSwe6pW3JpPn8ZkqulZ0FubGc4UJ80hCY+kiKnb8Tuy8GyTmNrEUkmlF8eWZeGUeehsFBgYm/P39/PyUKURp6S58K6qYJpUTz36YffCLMlcqsbfEth97iFqFbYU2qbyRNMLSpYJoM2aFOB+uvI/oGfr16ydq1aqV8G/JGLDkQgu+vr7y9kSUucgNvVC09QKE15+JczuGoPCLtn/GPMLN63fwMFqCjXNhFHW1f86ViAZEBPjjwo1HiDNzgnvJEnC1ZcvVuyQoKAguLi4wllUVKlRQphK9CnEIvX0VN4OjYeJYEEXc88KK53ooi/r37w9/f3/4+PjwFCFlVRh2/rMdD2CPht07vtzNlC2cULjUe6hUsRxKPDdcGWlg4+qFKrXqoFYVL4YrInqFzODgVgrvVaqI0h4MV/TiuOlQluj8/8TMf4KAgh0woHVebjhERETPwOMkZSj2+N/4Ztp8rPxnDRbNGolWzcdjf6QTGo/+HxryKhoiIqJnYsCiDOhwdt1UfPNZb3Rs2w7dP52CLbcdUGfUYszrVwQ8QUdERPRsDFiUAROUHjQf/yz6DTOmTsPsP1dhv/8l7PmuMfJxiyEiInouHi4pQxb5K6HZxwPw6YjhGNynHWp72HJjISIiyiIeM4mIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUJrVt21YcOXIEe/bsUSYREeUsQUFBqFevHpYuXYoKFSooU4mIcpb+/fvj/v37uHjxIiT5uUicTEREREQvSwgBqX379sLX1xd79+5VJhMR5SzGFqxatWph5cqVbMEiohzL2IJlLK/Onz8PydvbW/j5+cEYsoiIciJjgeXi4gJjWcWARUQ5lTFg+fv7w8fHh53ciYiIiNTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYL31IrH32zZo1OB9fNSmD8b8eQTBBuUlIiIieiUYsN56AsLUHgWKFID5nW2YOqAxOsy4BL3y6muni0VUZBRidC+b+gyIi4lCVEyc/C8iIqLXiwHrDaALuYQDaxfgl+mTMenHqfj5rxXY7ncHkcrrz2aDBv+bj3l/LsC6HV/jA7NInD5+FrHKq6+XHjdmNoSDjQOqfHkCOmVq9hlwf8MAlLazgY19GQzcGMyQRfSOMoRdx6G18/HzlEn4YfJM/LFsO84EZbXEi0Xgya1Y8tt0TP7xJ8z6azX2X3qccyqk9Gbx9vYWVatWFZTzxAfsFlN6VBOuFpKQjE1RqR+SVth7fiRGLjsvwpX3Z0ofIs5u+Fl80byYsNLmFs3+uC50ykuvl05cn1JbmMJUlBl7XMQrU7Mr/soformzVkhm1sLaVBJa5xZi7pUX/TTKiQIDAxO2ez8/P2UKUTq6e2L39+2El4PJU+WlZO4q6g5fJa7GKu99il6EHP1F9K7iLMykdPNqbIRH4/+J1VeilfcSZa5fv36iVq1aCf9mC1YOFf7vNLSo8iFGLjyGsPz10GvcDMxfuR4b16/Gol++xdBWZWF2YxumfFwXLX7yQ5QyX4YM17Fi3HBMu/Qevt16FKv6uUOrvPTGizyG77p9ji1xVTBy3QWc/2cEKsVuxmfdf8DxrDXxEdGbzhCMzUPeR7Oxa3DZtBw6jpqBBas3YP3qBZj2WUsUNwvE/hnd0Hr8wQzLytD949G40WDM94tBsZbDMfmvFVi3bjUWzh6P7tXscWfHZHSq1wlzL754Ozu9g9iClfPoA1eLHoVNhSRZCa8+S8TFSOWFNHQiYMtwUdFWIyTLKuKb089osdHfEwt7lBfVRu4QMcqkNHTXxS+t3EWBAm6iwme7lIn/hZdtwdKJm0u8RaMP+4nfT6W04z058avo27iRGLT0Zg5pqaOXxRYseqaYE+KH2g7CzONjsfR6+pJEL4LX9xbuWgiNUyex8okyOcmTnWJQMbm81bqIZnPOiaeKW12g2DykrLCSNMK+3lRxgYUKPQNbsHK0COz95n9YcksPu7rfYOUvXVDcSnkpDS3yfzQZCyfUR7EqNVHC6hm9BDQu6Pb3CRyZ3BDmyqQ09Pdw9cId3A14AHu3osrEN4EWhbrMwfatf6B/ORtlGmBb/hPM3bYdP3cu9Pa01BFR5szL44tVW7BlxWx0djdRJibRIE/jDmjoooXhyWWcv5G6FUqPG3//gAVXdbBtMBazB3jhqeJW64wmk2ZjgKcWT3ymY+r2COUFomdjwMphDA/WYs6yG9Bpi6D7xE9Qykx5IUMmKPX5LlzaNw3tiiZFJwNu/dEOnu7uKN5rOUKVqWnFYKN3aRRx90SLWZcQe3UvfG7oIdnWRvtWBZX3ZJ0hcCkG1KqKWoNW4oFBh3t7Z2DAhxXgns8Rjk754VGhEXp/twnXntfP1PAAh38fhlZVi6NAHkc45fdAhUa98d2ma5l2ytc/OC6HzB5oVKko8jvJ35db/r73GqDL2CU4Haa8KRXVfisR5SiafNXxfkUH5Vl65jBPKEstYW0tJUxJoL+FtasPIRJ2aPBxJxTOrEZmVQPdO5SCiVwZ3bhidxYvMKJ3HQNWDhN1YBsOhBmgdfsIbWtk2HT1HAK6sCDcvHkTt4LCM7n6xYCI4Fvye67jxJpxaN7iB/yrt0f1kd+ih1v2NwkREwj/Y8dw3D8Q15b1QO0PR2D+scewLegJD2cNHpzdhfnj26B+z6W4k9nlfYb7WNO/Fj7w/hU+DyzgUsQDzpoHOLtrPsa3qY+eS++kuzLQgOA9X6LRezXR85tF2HclBg5yYPQsZI+Yawew/PvuqNf8R5yKU96uUOW3EtEbRee/FwflHdqy/If4sFCqFBXli8On4yBMSqFajczCmZEJSlavhDxaA0KOH8bZdOUKUUYYsHIUHa6duYAnBgnmXhVQ7pmtV2rQ497BDfDTVkO/n7dh45jKTzePZ4Ph2nwMGOmLst/uwY2gGzjz71H8e/42ru0Zhxp2etxdMwm/n8iok6geNxcOwDCf9zDpwC3cv34ax4/+i/O3r2HPuBqw09/Fmkm/I82s+otyEJqMfSEF0fybTbgYeBcX5O876uePOzd3Y2RFc4QdmoGZ2zKua774byWiN4ceISfn45Me03DWsQG+njMcZVKdQdTduoqbUQKStRuK5H92hwIT9yIoKB8x9Xeu4joDFmUBA1aOokfgvQcwyH8Wx3z5YKlMfXVMUX78cdy/tBu/D6yKXC+5Neju+EPbexmWjKwH1+RwqEGe2qMwqk0+SLpLOHw4UJmemgERD13wyYqFGFrTWa4rKjR5UHvUKLTJJ0F36TAOB6ZqUtKWwqdzfsPUpbuwZlwTFEmVDDVONdG+sQdMDI9w5fL9DFvxXvy3ElGO9vgfDK1dFVWrVELZoi5wrdQXa6z6YdXhTfi8krXypkSGkBCECXnPt3WAw3M6bEr29rAxjv8Q9xiPnrB5m56PAStHEYiLj0sYfMXUPMPu6KqTpFT9EV6SZFoN3fpWyqAVzByexdygFQIPg+8r01KTYFajG3qVzWCZzT1RzE0LIR4i+H7aQs3ive4Y1to9JZAp4gJ2Yem2awkDl+rk9ZmRF/+tRJSj6UJx5+JFXLx0GVdvhyBWGBB2fC6G9x2OP/1C03Q1EHL5EGcscE1MnipH0tNYmMPMWFwKHTIpVojSYMDKUSRYW1nK/xWIjopMCFpvEo2LF8q6ZLRJSTCXCyfjcsXHZXTaTQPnkqWRL8NZzWFhbqw2xiMuk9vpxAWfx96Vv+PHMQPR6YNyKFysKWaciH7m+nvx30pEOVqe3lj7IAxhYU8QFReB++d2Yk7/0ojw+R0DGrfD7PMp+7VkYQkLY2iKi0VM4qRMGaKiEWMsVIxlkkXiNKJnYcDKUUxQsJCr/EcRCL1zB6FvWCu0sZnd7oXGRdDA1t4220Mq6AJ24vuOFVCwYBk06DgQo6csxr7b5ijf9WvM8q4IU+V9GXnx30pEbw4L5Cn1AQb+sgXzexaC9GgvJk3ehHDlVa2zM/LIAcsQ+giP4pWJmTA8fIjHcsDS2OSDswMPnfR83EpyFC0KVa4AV61A/BlfHHnm8OwKXRgeh2f3TlnxiIl9TmnyIiQNXvSEo6TJ5pyRBzGuSUuMW30DLh2+w7ID/ngQHo6gy8ewee5otPS0ffZveYnfSkRvGkc0bPcBnLUGPDx+BOeVU3xa1xIolkuu0sZdx6Urz26xjrl8GbfkolZbpARKPKv2RqRgwMphzKu1RhM3rVxb2orFa4PSDU3wtND1g1HavQL6LrupTJGzg9KvShj00Gf0AbpbuHXP8MadgkwtZvefmH8uBhZ1JmLt36PRqXZxOCV34TIg9PGTN3r5iCjrYgMOYt7ESVgfkHmJKdnYwkouGkWscqrPyKwa6lWTK2O6i9i/53aGF8QkioHvniN4YjBB4dr1UJSt35QFDFg5jVU9DB5UC7biETZ+PQ6b0nXsTiPGDzMn/4PA0MeQHPIoE7VwcLCD1liQ3LuNWxnMrr++HbsvvNn9i8KDghBmkGBb2AMu6Qs7/U3s2OOf0MmdiN52kdg2ph36ffMlvvnjNDLuf25A0MnTuKuXoHUthEJJPdo1edCie3M4a+LgO+9X+GZy1sAQsBxzVt+BwawMOnerhlc+gg69FRiwchwtSg6ehYn1HKG/Oh89mnhjwem0V74YGUKOY073TvjheAwc3/8fRjZKufzY7r3yKCYXIPH+yzB73b20tbLIs/j98xk4klyFezPZurrCUWNAyMGN2PMo1doxhOLolIH48VBiJ/fIiAi2ZBG91azRsG9XeJrE4cS0vvhic8BTlavI8/MwYsoBxMASVZo3hVuqSpljy7EYVc8Bev/Z6D1wES6mGzpPd28XJnT+DBseaeHe7SsMLfe86w2JEjFg5UTmZTF89Tp80yg/ok7+jl6V3FG8Vmv09B6GEcMGomfr2ijuUQNDVl2H+XvemD9vIDxTFRgm5XvB+wMnaPQ3sbhrRVRp0QuDhw3FwB4tUKVENQzZ7Yj6tV3f6Pv0WdTrhk6eZnII/RPtK9RBh/6fYugn3dCkQnHUnXgXHeaMRmUzHS7M7oDqdbrg51RXDhHR28Wq9gTMHVMDjlEnMaulF0rWaYPeg4Zh+KcD8HHTSiheuT/W3DbAodYYTPUukbbs05bAoHl/oq+XKa4s7IEKxSuhWfeBGDZsEPq0rYuSXh/h+4NPkLvel1g8tTmceNSkrPL29hZVq1ZNuPMz5TD6YHFs/v9Eu6qFhJ2JZGyISXxIpsK+SE3RZeJqcSFceW86+mAfMbVrReFsnjKfpLEULhU7iu923hVBc5sIS/lzKn55RqS/93x26a5PEbVNIUzLjBXHM/wwvbgxrY4wg4koMfKIMs1IJ65PqS1MYSrKjD2e8e/Q3xDT6pgJmJQQI4/EKhMTRV9YIobUcxPWGmUZJY2wdqsvPl1+ScToH4pdExoKDwczYWZXSozYHZMwz4v/VnqdAgMDE/7Gfn5+yhSi9MLFhVXjRfvKBYWNNnV5qRXWrhVFm9HLxLlMyksj/eOTYuEXrUR5ZwuhMY7TkjCvibBzry16/LBF3EgsQoieqV+/fqJWrVoJ/5aMAUsutODr6ytvT5RT6SMCce1GEML1ZnBwLgx3Z+ssNT8aIgLgf+EGHsWZwcm9JEq4Zn84hJwuJvgartx5DINtQRQrmg9WrGG+dYKCguDi4gJjWVWhQgVlKlHGdGEBuHY7CE9iTWCbrxCKFHTIRr+pGDy4fhV3H+tgkacwirk5PHcQUqIk/fv3h7+/P3x8fMCARUQ5HgMWEb0JUgcs1vWJiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSmeTg4CBCQ0PRr18/ZRIRUc4SFBSEjRs3omLFiqhQoYIylYgoZ5k7d27C/4UQkDQajTAYDKhZs2bCRCKinCYkJAT+/v7IkycPPD09lalERDnLoUOHEv6fELC8vb2Fn58ffH19EyYSEeU0xhYsFxcXGMsqtmARUU7Vv3//hMqgj48P+2ARERERqY0Bi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyt6dgKWLRVRUFOL0yvN3kg6xUZGIitHBoEx5UYa4GHl9xiDuZT8o29RbBuiN20QsXsUmoYuNQqS8fnT/+fpRGB7j+PJZmDF9Bn7dfAlxymQiIvpvvCEBS4eQSwewdsEvmD55En6c+jP+WrEdfncildefI+IwxlfPDRsbOxTpsAA33tGQpb8xEw0dbOBQ5Uuc0CkTX4Dh/gYMKG0nr097lBm4EcH/YYh40WUwBG3GZ9Xzwtq+CBqP24Z78jYQuqAtcuXujOVRypvUor+BmQ0dYONQBV++zIp+YQYErh2Ojt2HYfiI4RjUuQe+P5rFfYXoDRJz4wg2b9qIjZuP4GaMMvGZYhF4ciuW/DYdk3/8CbP+Wo39lx5ns5KlxmfQO8Hb21tUrVpV5EzxImD3FNGjmquwkCQh/9w0D0lrLzw/GimWnQ9X3p8BfaBY16eoMJVMhLW1hZA0DqL2DydEtPLyu0R3fYqobQphWmasOB6vTMyu+Cvij+bOQiuZyevTVP4bOIsWc6/If6n/xostg05c/KGaMLd7T7RsXV44aG1EuQHzxN8DSgizAgPEjhjlbWrRXRdTapsKmJYRY194Rb+4yH9/FPVzaYTGsaroN6K1KGIuCdPCncTi6zrlHW+ewMDAhH3ez89PmULvvIhDYvR7cpluPB6Y1RczbuuVFzKiFyFHfxG9qzgLMyndcURjIzwa/0+svvK8o4Ian0Fvu379+olatWol/DsHt2CF499pLVDlw5FYeCwM+ev1wrgZ87Fy/UasX70Iv3w7FK3KmuHGtin4uG4L/OSXUTOEDpfn9sWAv4NQvPcC/HtlJ75vaA3fr7rhf7tCXv4U0zsnEse+64bPt8Shysh1uHD+H4yoFIvNn3XHD8dzcgtJPK5evQWU6YKpK3dh/fhKCPyrD3r+cRMe7TqgurnytqwwBGDT173Q+sNBWHIv521BuutL0Lf9OBy2aYLJW7bhj6krsXvpYJQLW4UBrUdgS1AGvzmHLxPR0yJx5PvBmHE6JiHhPE/o/vFo3Ggw5vvFoFjL4Zj81wqsW7caC2ePR/dq9rizYzI61euEuRczb3FW4zPoHZMzW7D0InB1D1HYVBKSlZfos+SiiFReSUMXILYMryhsNZKwrPKNOJ2+seDRVjG22fuiyw/7RXBS5SbmqlgxvIV4v9uv4tx/3LigD94rfvthjlh19J54HW0JL9uCpbu5RHg3+lD0+/2USG4zfHJC/Nq3sWg0aKm4+R8s1Iu2YN3cu1D8temciEh4HiPuHt0gVm06Je5n9zfHHxdjyxhbp2qLKZm1CL22FiyduLH1ZzHpp/nCJzDtb4u+tEnMmTRJ/Lk/UN670snKMr1mbMGi1CKPjBUVLCVhWqicKO2oeXYL1pOdYlAxY2u7i2g259zTxxJdoNg8pKywkjTCvt5UcSGjXUCNz6B3QuoWrJwZsMJ3CW8PEyFp7EW9qedFrDI5Q/HnxU/ve4q6w1eJK2qf6lFZ+D8fi7warXDtt1U+xP/3VDlF+Jq99mXI0QErLX3ME/Ew6L4IiXjOb2DAojdJpK8YX9FSSCYeov/6zWKEp8kzApZOXJ/VQNhIkrBr+LO4kdnmHblfDC9uDFAFRJ/N6bucqPEZ9K7I4acIDXiwdg6W3dBBW6Q7Jn5SCmbKKxkyKYXPd13CvmntUDT9qR5DKM6u/BZ9m1VF8QJ54OiQC85FyqF+h88wZ+9txCpvS8MQiKUDaqFqrUFY+cAA3b29mDHgQ1RwzwdHRyfk96iARr2/w6ZrGc4ti8OdvbMxpFU1+Tud5HnywK10fXQdPxXjpm7AQ6sK6Ne/PrJzVio1Q+BSDKhVFbUGrcQDgw739s7AgA8rwD2fIxyd8sOjQiP0/m4TMv15yeT1fPh3DGulrJuszKt/gOMLJ6BHo0oomt+4bLnl9fEeGnQZiyWnw5Q3pfLS6zI79Li5YjAaVq+GWp3n4JxOhzMz26NG1RpoO/0UMm+0V95XrTb6LwlQpj3NcH85BsrrvWrN3lhwXf40/Rn83LYG5MpJ4qN6c/zgm/G1eoYHh/H7sFaoWrwA8jxvuWP3YWLDaqjWYBx2Z7ha9Lj2Zw/UrFoLfRfeTnea24DQc+sw9dN2qF3SBXbW9sjtnA9OdjZw8qyLnj/tRkCqFfEyy0T0ekTh2KRBmHIiHm4fT8G3je2V6ZnQ38La1YcQCTs0+LgTCmuV6elZ1UD3DqVgor+HjSt2y+9PRY3PoHdTzmvBCheruzjJyU8rigzZ9+zWq2eJPit+b+chLCQISTIXTkXKiIqVKogSrnbCxDhNm0tUG7lVBKav9CS1PhhrREcWiy5FzIRk6igKl6koqlQsJVxtTYQESZgW7CSWPFVjihXnf20hXI2nNjUWIq9neVG5cllRJJf8GXLtW5Onrhi38+VODya14JjVnyGOLO4iipjJv8WxsChTsYqoWMpV2JpIApKpKNhpiUj/81Jaf0aLTcv7CE9LjTDL5S7KVnr+vPr7u8XEBvmFqXHdmdoJ15Ly+qgir8/8NkIrT9M41BaTTqb7a73UusxYxi1YehG0Zagoay0JjVN9Mel44onA2CNfiJImECYeQ8TezPqexvgk1IAly7pi6tXM/zL623NEEyc7YWdnI8y1xvVkIixsjc+Vh0NxMXSX0i6ZqgVr9Kbloo+npdCY5RLuZSs9f7mjV4sujhoh2XUQKzI8Lx4vTk+sIExhKqr9cDHdtvRYrPnYWd53JGHmVExUbdRKdOjUTjSpWkjYaIy/2Uq8N/pQ8umNbC3Ta8YWLDKKPjpBVLKShNa1i1hhLLxjDz67BevJEtHWXt62TauLSVeeXfLGbOkj8mvl8qLkF+JI6qJMjc+gd0bOPkUYf0pMeE8+OMkHg+bzHysTsytCHBhZRphLkrAq0VXM8b2f6kAUKa5uHCfq59PKISi3aDb3etqDVNLB0cRNlCvrIoq0miz23k3ZU/TBB8T4GvZCIweRMmOPp7l6Th/wl2juIB8cbSuJz7bcTQmH0VfFqv6lhZWFp+iz5t7TfWCyISlgmLiVE2VdiohWk/eKlJ+nF8EHxosa9vJvyOD0VNK8GltX4ersKTrMPCgCU4WUzOfVifOTaghLOTQWafGN2Hwt1ZFf/1Ds+6KisJQ0wrnneqWPk+Il1mVmMgpYoYe/FrWNocT6PTF8R3DK+tWdF99VNZfDdH7Rc90TZWJakdv6Czc5XNg3nSvuZeUPk51ThBpb4erqLDw7zBQHU1b0s5f7pQKWXMCfXC5mr/xXBKUp3CPFuRmNhZNG/ts7dRGr0p+94ClCehNEHxMTK1sl9INqu+hu4n7+nIAVf/YrUVEuLySHjmJlhvtTCp3/d6Kq8b02bcSSVPuIGp9B746cfYpQH4h7DwyAxhH58lkqE7PHELAEk34/hzjL6hi3ah68q+ZFSquuFTyafYVVv3VDQekhtv04EwczOhWjuwN/bW8sWzIS9VxTTlJq8tTGqFFtkE/S4dLhwwhMdY4mav8W7A8DnNuOx5cfuaac2rTwQLvJE9DS5ioWfvnzS41BlUR3xx/a3suwZGQ9pPw8DfLUHoVRbfJB0l3C4cOByvS0DBEP4fLJCiwcWhPOJsrEZ86rRalP5+C3qUuxa804NClipUyXaZxQs31jeJgY8OjKZdzPaDCYF1iXWRV7/ld83O5rHIwohM5/rMVPDfOkDO6mLYGPu9eBtSEI6xesg3GzSisM2xavx12RGx91bwsXtfcGQwQeunyCFQuHombKilZluTNj/l5HDG5fEfnSnFe3glefPmhor4HhyQWcvarCBkj0n4rBvz8OxpR/Y5C76beY0tk1S4M4GkJCECZHc42tAxwyO7WnkOztYWM81RD3GI+epOyUanwGvZtyXsAScYiPM1ZWTWH+gh2VHu/cDJ9w+bBSrxd6l0pzpFFo4NSkD9p6mEB3cxs2+mXQz0QyRbVufVEpVZZIYu5ZDG5aAfEwGPeT9yEDIkOfIEZokbdgQVgoU5NZuqFgHg101/xxWYVuLZJpNXTrW0k+dKZnDs9ibtAKgYfB95VpaUlmNdCtV9kM+oE9Y16L99B9WGu4p+SERHEB2LV0G64Zj9m6+IxHDM/2uswKAcOtFejfahg238+FhpPXYm6XwqmCtJEGbh174sNcQOjOhVh5J+0XGII3YPHmB5AKtEKPpo7KVBVJZqjRrRfKZrAdv/hyvyCzvMibS97dRSSehLPgpzdLjN9kDPrpOKIdG+GraT0y7weVjoiPQ8LhxMQE6Yuu9DQW5jCTwxGETj4GJU4zUuMz6N2U8wKWZA0rS2MVIBpRkcatOrvicMX/CqKFCQqXKwenzJbQrAzeK2kGSX8bFy9m0B1R4wKvsi4ZriDJ3ALmxp8o70Ept0LRwKGIO/Jq9bh1+hQepjuGGe6fxOm7emic8snvUSa+BI2LF8pm2OQiwVzeyY3j4MXHZdxSoXEuidL5XmxexAXj/N6V+P3HMRjY6QOUK1wMTWeckNe38npGsr0un88QtB2fNe+DRdctUHHkCiwbWi6DsClzaoGerfJDE+mDxUsvpRpt2YDAf5ZgZ6gGRTv0RANrZbKaNM4oWTqfqsv9fHo89t+FxTMmYsSA7ujYpjmaNHof9d//FGuMw9dnadQgohwk9iR+GvQTjkfbo+746ejnkfUCVLKwhIUx8MTF4nkDvRuiouUKsvwPyRwWqWrIanwGvZsyKvtfL5OCKOQq/ywRijt3QtNdJZUVAuFh4QmHETt7ezksZMYcdnZWkIQeEWFPnv4ejS0c7LKXhMzr9UPf8pYI2zwWXcetwLFboYiKCsH1QwvxWefx2BlhAs8OXVHrRS8hTMXYXJ3Nn5dMY2sP2+zOqwvAzu87okLBgijToCMGjp6Cxftuw7x8V3w9yxsVTZX3ZeQF1uXz6B/44aC/HIwtvdCqYzUYG2cyZoMPenVEUW0s/JYsSjk9q7+O5Uv3I9K0HLr0qPLsK1VflLzc9tle0S/O8MAHk9t4oXCZRug2/BvMXrINRy/cwv3QaOg02hy4sxM9TyxO/eSNycciYVNjFGYNLvHcVqTUtM7OyCMfBAyhj/AoXpmYCcPDh3gsHzg0Nvng7JCyt6jxGfRuynlbgLYQKldwhVbE44zvEWTlNnG6sMcIT26akGBhaZEQrGKinjXKrx7RUbEJr5tbWmawIiRoMk9nGTOvhHGrl+GLmgIHJnVC1cKOsLZ2gketHphxOBwFm/+ERV/Wevr04YuQNM8Ij8+R7XkjcXBcE7Qctxo3XDrgu2UH4P8gHOFBl3Fs81yMbukJ22d+4Ausy+cwKdoFo7oVh3mUL77u4I01AZlHcfOqPdH1PTPoLi7HggOJdVDdhSVY5hsLy5rd0K1kdors7FB/ueUiHJGRUU9v13Jg/LNna4xeexn64l0wfcdFPAgLxs2LZ+B37DB8dvyIprlZ4NMbJvYI5s0/jgh5g485NxutSxZDsWKpHl6dMf+mXPjHH8X3dYsr0/piVXji7FrXEigm175E3HVcuvLsvocxly/jlvxR2iIlUCJVhVGNz6B3Uw4scc1RrXUTuGkNeLh1MdZmdGuPNEKxfnBpuFfoi2XGHU2u3xQpUhBaSY9bly9l3qSru47LN+QAps2Lwu7PGUsly2Jx7ZgPzgXr4FisBho0bITGzdqg64CxmLPxJE6t/RQVbZS3vkliduPP+ecQY1EHE9f+jdGdaqO4U0oznCH0MZ5knmRfCcnSHW1/XYsZzV1guLoAfTt8gyNKofoUk1Lo1r02rAy3sObvrQhDHPwWr8BpvT0+6NYRhf67RqYskCAZQ5kQmVQOonHj+r1UpzoT6a+swLydITCYlsXwxfMwrKFn2g65+id48kKn3IleI8kU9vkKoEABV+SzkRATE5PuEQd9wmZtQHycMi1WB33SYcOsGupVs4Wku4j9e24/td+kiIHvniN4YjBB4dr1UDT1vqPGZ9A7KUdWaa3qDcagWrYQjzbi63GbntkJOMZvJib/E4jQxxIc8hi3aA3y1a8P41XnoXtWY1NwxjPHnV2N9Wd10DjWwvtVVThnJzPcmgvvXlOww8obO88ewu4d27Ft4xos/u1beDctiTe2xTg8CEFhBki2heHhkr7U0OPmjj3wf3bF7tUwL4kBC1diTDU7PDnyLTr0+juxs/1TjJ3de6CRAxC8cSHW3fbBolWXYcjTFN1bO2dzJ9BCkzCDHvrMS9oXJ9nB1lqCiH2IoEdPb7uGB1uwzifiqfClvx+Eh3IokyyLo0zxp094Rh3fj+OZXtX0ipeJ6EWZ1cQ3h2/izp07GT+urUFfd7lMMq2OiUduJU67+jc6JdWZNXnQontzOGvi4DvvV/hmckrEELAcc1bfgcGsDDp3q5a2y4Aan0HvpJx5yNeWxOBZE1HPUY+r83ugifcCnA5Nf3AwIOT4HHTv9AOOxzji/f+NRCOlo7JJqd4Y3DQ38OAffDHgV5xK17KhC9iCUf2m47TOFKV6D0Yz+cCrBhEZijDj5SZvW0OBrStcHTUwhBzExj2PUvVXMyD06BQM/PFQYif3yIiEpvz/lH1NTFzzN/oUN0HAP4PR9otdyCCXQJO3FXq1coEUtgOz+n+L1bcBt9Y98VF2//aavMiTSwNJfxlHjzxMWRfG2rMa4cTUC+95WUCK98Wi344izaYbcRZzPxmD7VHGCxHS0rrmR155oog6hYO+aUfVj7u1Hv8bNg+Zjs7wqpeJ6DVybDkWo+o5QO8/G70HLkL6a5p093ZhQufPsOGRFu7dvsLQck93GVDjM+jdk2PbVMzLDsfqdd+gUf4onPy9Fyq5F0ct+YDoPWwEhg3sida1i8OjxhCsum6O97znY95Az5RL9DWu6Db7V/SWa/J31w1BNc/yaPLxJ/h02GD0aVcXJb1aYMaJKDjV+xp/TaiZ8dVnL0BbvDO8WxQETv2ABmWqo0GjRmiU8GiMxk1aoG33wfhq3kEEvGmX71rUQ7dOnjDTX8Wf7SugTof++HToJ+jWpAKK152Iux3mYHRlM+guzEaH6nXQ5efzyoz/DY1LS/y8dhZa5I/FmZld5e8/m8GpYVs06tUeHtoonNi+D/el4ujYs072//YaZzRqWhVW4iHWDamHZn2GYHDfNqhe1AOdFgamCp8vSJMP7b07oZA2Bn6TGuG9ep0w4NNhGNSzJaqUqIqhZ97HLxPrPlU71rq3Rac69tDormBO22po0nckxo37At6d68OrbDss1HZB79pWGfe9e9XLRPQ6aUtg0Lw/0dfLFFcW9kCF4pXQrPtADBs2CH3aGo8HH+H7g0+Qu96XWDy1ecZXnqvxGfTuyZE3e05FH3xMzP9fO1G1UOItbuSfnPCQTO1FkZpdxMTVF0RmA+bqg4+I3wY1EiVymSbcqiZhXkkrrF2riI4T14orGY3Km+o2J5ndqFd/Y5qoYwZhUmJkmtshRF7bIX7+rJEobCol/86nHpKJyN9yrnjOHRcylfGtYlLTixvT6ggzmIgSI48o0xK9zLwi+oJYMqSecLPWKOtSEhprN1H/0+XiUoxePNw1QTT0cBBmZnai1IjdifO8xLrMzLOW4cnhr0RN40j65p7Ce2uIMjWV+FNiYgXjtiAJsyrfivMvOmh57CWx1LuGyG+e9HeWhGnu8qLbXxcSR2V/6eUOF6fnfSJqFbQSGmWblzSWokCdT8XKqzHi0dyPhHkGI7nr7+0UX7UsIRyMtzxStjfJNJco13maOBgcK85+VVGYmhQVww5ksKKft0yvGUdypww971Y5qegfnxQLv2glyjtbJO9XxvLYzr226PHDFnEjC3eFUuMz6O2WeiR3yRiw5EILvr6+8raSk+kREXgNN4LCoTdzgHNhdzhbZ7GaoI9E0I3rCAjVwzK3GzwK58pgkM2XE3d6Cho3GIVDudph2tzv0KW6O3KZp/w+Q9xj3PD5Fd5dx2PHo6IYse8sptZ8A8/SxwTj2pU7eGywRcFiRZHP6k2qqkViQ6+iaL0gHPVnnsOOIYVfqgnXEHEPl68FIsYsL9w9C8Je9U6tMQi+djVhu7XKXxTFXKyz9Htj7l/EmctBiNY6oEDxUvBwyvp29uqX6cUEBQXBxcUFxrKqQoUKylSiFxGDB9ev4u5jHSzyFEYxN4dsDf2QSI3PoLdR//794e/vDx8fH7xBASsni8PRUeVR68creO+bU/AdVyrdiOJJIrGkTV50W2eC9ssCsaKjWicnKUvC1qFnyXZYFN0c8y+tQfe8b1I4zC49Ag8uwrLTufBRjxYo+SZevZoKAxYRvQlSB6y3+QjzH9LA3MwUknxQu33iODIbWUIfsAlb/o2FMHGHpyevMflv6eD/50z8EwQU7DAArd/qcCWL2YRRbfrgsyHt0e/Xq/KWSURE/yUGLFWYoHSnbqhhHAZg3QBUrdMN/5v8OxavWocNG9Zh1aJf8cOIjqheuTuW3ZXg2upz9ONVJq9YLI7//Q2mzV+Jf9YswqyRrdB8/H5EOjXG6P81hK3yrreWJhfyOGohSdbInTuTzu1ERPTK8BShagy4v38Khgz5EevOhSDe2P0xDQlau6Jo2P9bTP+qA0rw7OCrpfsXY8vXwPfnku5tIcHUpQ5Gzl+BbxpnfH/At43+0SWcuGsFr3IFVbtS9nXhKUIiehOwD9YrFYOgc77wPXkJt4PDEK3XwNzGCa7FyqJajfIomNWO+fSSYnDv313Y43cNwVFa2Bcsh3qNa8LDluv/TcSARURvAgYsInqjMGAR0ZuAndyJiIiIXiEGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDKpd+/e4vjx4zh06JAyiYgoZwkKCoKnpyf27duHChUqKFOJiHKW/v3749q1azh27Bgk+blInExEREREL0sIAalRo0bCx8cH27dvVyYTEeUsxhasDh06YMaMGWzBIqIcy9iCFRERgTt37kDy9vYWfn5+8PX1VV4mIspZjAHLxcUFxrKKAYuIcipjwPL394ex4Yqd3ImIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGrLeE/sZsNHHOBaf8xVGrx2wcDVNeICIiov8cA9ZbQrIsivqdO+OD/I9wZNEofL3qgfIKERER/dcYsN5E4bdx1u9f/Puv8eGHMzfDAOf30a1Xc9QtngsajSOcnS2VN79FQv/FilkzMH369MTHjJ+x7lyU8iIREVHOIXl7ews/Pz/4+voqk0h9BoSc34/D1yMglClZoXHyQv0aRWClPE9gCMDyrtXw8Yq70CsfpnVujb+O/An9YFf086mAEYvn46vmnmnne9MZ7mF1r1rosugG4pNXogTzUoOx0WcGGuZiXeFtFhQUBBcXFxjLqgoVKihTiSJx7dA+XAgxKM8lmOSviMYVXbLQevCC88YF49zB/Th2/jYeROphZpcP7mWro251TzhqlffQO6t///7w9/eHj48PYAxYVatWFfQqxYoDw4oKEyTkqyw/TGtPEdd1ykckiBcXf2ki8mrk1yVLUbRuPeFpJcnv1QinD6YJnzNHxMHj10SoXnn7WyNc+H5dSzgYlxuSsPJsITrXzSe0knE9aEW+D2eJszHKW+mtFBgYmLBPyAFLmUIkROThUaKcubEMTCo3JWHbfrmIVF5/lmzPqwsS+6f3EFVczIWUPI/ykDTCyq2++HTJ+Sx9N729+vXrJ2rVqpXwb1b73yChB8aj6xdb8UCbHw3Gb4DPnt3w2fQlGrpqEbJ7LAb+GY4SFYrA/q36q8bg/O8fo+3XhxAqzFCg8VfYdGAtlm7bjyVDqiOv1oD72z9H675LcUOnzEJEb7/Yk5g6fDbOxBozTjZld179TSzrXQeNRyzAscDYhFSVhjAg6vZezOrdF7P89cpEetfxFOF/Qo9bW2bhr8OPkNQYnTBt2y9Y6vckYZrWtT769agBJ7lqlERb6CMM61cTjgnP4nB+zSxsvCKQp1oX9KjnCpOE6fInBR7AgsWHEQx3fDSoI8r9Z+cG43BqyTTslyqhfoNaKOtsoUxXkf4yNv78D4xdrczd6qNb56rIkxwgdbh3YBGWHg5CvOSASp37o6Hbf9NGH3dqCabtl1CpfgPUKuuMV7DklApPEVJaOlyY2hA1vtiHsJRCVSbBtv0yBK3s+IwuEtmdVw//6fL7P9+LUOP7JRM4lW+Lfl0bwiuvBiFXDmPdwiXYdwso+9kW7P+pHuwTZ6R3EE8R5ggxYktfVyHHgYQmZtOKX4oz8cpLz6F/clMc37lOrFj0t1iwbL3YezZQRCuv/afij4pRXiaJv7/sOHEii7//hemfiJvHd4p1KxaJvxcsE+v3nhWBr2fBxdFRXomnfE3LinGvfMGJpwgpNd21X8WHuTQJ24Sxu4S1tVY5bff8U4TZnjdktejqrLwfGpG74XRxNl25o390QEyfMI9dFYinCN9UhmAfzOpTE2553VGlYSt07NYTPTq3RP2ybshfujUmrLuKGOW9SfRX56J7zaqQQzSq1R+N7bF63D84B4ObVYKHsyMcnfKjaMXG6PvjNtyKU2ZKxxByEksn9kTjSsXg6uQAe0dnFCn/Abr1HYVFF3VymeOAOn26omxSk9ozGRByajm+7dcc1Uu6Ia+jAxxzF4BnpUboNuZPHA7KoHndEAyfWX1Q0y0v3Ks0RKuO3dCzR2e0rF8WbvlLo/WEdbiafsHlWufVud1RU17uqlWrof7o7YjV38fBOYPRrJIHnB0d4ZS/KCo27osft91ChotuCMHJpRPRs3ElFHN1goO9I5yLlMcH3fpi1KKLcj1YA4c6fdA1awtORGow3MGSkV9iR0LndA2cPpyEH1o6IFXjf+ayPa8BD9Yvwqb7SlOXaWkM+MEbpdM1WWty1cawr3qhtLkygciILVivS/ZasHQ3l4tenpZPd65M9ZBMnEWj6SfT1MDiT00Q5U2V161bi9mrBoqSlqk7dioPyUx49P5HBKXrIK+7sVR097TI/Hu1bqLlDF/xKCsd6/Uh4tCkj0QBswy+P+EhCVPXJmLmqVTVQ91NsbyXp7A0dmjPcB75IZkI50bTxck0Vc94cWpCeWGa8B5JWLeeLVYNLJnh50hmHqL3P0EizSLoboil3T2FRabfqxVuLWcI3ywtOL0stmBRIr0IWvWxKKBN3A81DvXFdP9wsbabk7G1QJ72rBasF5k3WqzvmU95HcKk5EhxJFaerAsRF/etEQv++FX8Pn+F2HYi4PWcRaAchy1YbxrDbfw9ZBAWXI5O2MsT+gCUaYqeg4ZgQKe6cLdOrH8JXRB2ju6NScdiE54/JWYvJvb7AxdjTJGrUAmUKuYMa23ivBBxuL74O/x+PnVP8RCsGTMciy/HyN8rwcKjOUb/vBCL//wevSvlSryU2fAA1+5EwfS5W5IBtxf3Q/ux23A3LmEpIJnao0BxL5Qo5AizhJ8hEB+wFaP6/YTTCT9DnufvIRi04DKiExccJk5l0LTnIAwZ0Al13a0Ta55Ch6Cdo9F70jFksuTyok9Evz8uIsY0FwqVKIViztZIWfTrWPzd70i96CFrxmD44suIMRa7Fh5oPvpnLFz8J77vXQmJI0LINdtrdxD1/AUnIrU83obx/1uOAGNDt2SDal/MgHeJLLYgv8i8+gBcvBwi7+1GEkyLloTbhd/xcTl3eNVvix79B2JAr474sGJhFK7+CRad57h8lApbsF6XrLdgGVuhKpgmtfpohEP9qeJ88rl+vQjZNUSUTPV6ni6rxGPl1dQtWMaHJnddMWFXgDBWwuRqmAjcPFCUSJpXMhcNfwlMacmJ3ih65VP6HmjdxIBtEcoL8rfemC7qWSTOJzm0EYtDlBcyE7FDfOKuVX6HJKzLDRSrriTVFWPFrY3DRSV7jdDYlhAdpvqI+8YfEX9KTKhgmtx6ZqxxTk1ZcKEP2SWGlEz1ep4uYlXSgqdpwTI+NCJ33QliV0DikgtdoNg8sIQwVVqoJPOG4pfApCWPFht7JdVatcJtwDaRvOT6G2J6PaVFT3IQbZ674KQGtmCREE/E3mEllX1WElaVJorjCc1G0VlowXrBeWMPihGeif1ME8rehr1Fh8IpZU7ahyRMCnYRy++yVftdxhasN4oBAXv345zOuA/LNI74aGA/lEo+16+BY71h6F3FVOlHYEDIvm04klFTjmSOqp/9hgnv54dZwgQtnBv1RpviSi1OGPDo/gOltiYzRCIiKul78yC/a0oHA01eVyRdNCgiA3D7/rMvTY45sBIbbyvvMSmGfrOnoV3RpGt1zODWbBIWzJ2JZUeOY8WIWsgrb5mGgL3Yf06XUHolLOdHA9EvZcHlVVEPw3pXgVxoJjCE7MO2DBfcuOhV8dlvE/B+/sQlh9YZjXq3QcqiP8L9B0lLbkBkRFTy9+bJ74qU1Z0XrikLjoDb9/HsJSciNUT5TsLw3y4mDDQsmZfBkBkjUSmLl+++8LwiFjFKi7uxXAjdOQ+rblujVKuh+GbGz5jxzRA0K26b2Jovlxi6Oysx/qeDT/WFpXcTA1aOF48b1+8kj9oOrTtKeaW7AFnrilIlcif/MfUPr+Pqw+SYlEJbGDXqFJFjVSqSA+xslX/LdPpU58nMvFDa0yQxuOn8sXmlH8ITXtDh5ppV8AlXIoh1QRR2ftbwCHrcPXMewUoS0TjVxPuV05duZijVfjA6eNkoz+Ulv3Edd1IWHO6lvNJdPq2Fa6kSyJ2y4Lh+9aHyJC1t4RqoUyTtb5Qc7JCy6DqkLLoZvEp7wiRxweG/eSX8EhccuptrsMonPDF8aaxRsLBz2vVJROqLO43pw2fidMI5e1MU/2QGxta0Vl58jpeZVzKDeWL/hUSSFSqM3owja2di3KeD8Om4WVh/aAX6FVPKSbm8uLF1A05kcsEQvVsYsN4A0dGpWmXkHdzaKtUOn0CCjbWlsoPLRDQiI5KCSSqSPRyzcy8Hk1LoP7oLChubiEQUjn1bF0WKlUfF0oVRptdqpS+DOUr2GYzmDomzZEzgcZiSUGQaRyc4ZWXLi45O1adKgpW1VcoyKiQba1imLDiiIyOUf6cl2Ttm4zYWJijVfzS6FDa2CgpEHfsWdYsUQ/mKpVG4TC+sTlxwmJfsg8HPXnAiUsGDFV9hyrFIpWKTB85R2/DdqFEYlfAYj6Wnlf6pstjzKzDROH3011hxXvdS80KbB3lzpZQ6kmVdDBhaLVXFTP5Ip4YY0LFUyriEd67iamadQemdwoCV40mws1M6cxuJCIQ9Sd86ZUDok/CUU3uSNWzt0kcRIwmajCZnSgPntr9j57L+KGfsSC9i8fDqKZw4H4AIvfHCQxfUGroI67+vi5R2p4xZWaac2hNyCIrMIP+lJ9nZQem/LxOICEsclDU1Q+gThKcsOKxt7ZR/pyNpUtZhFmic2+L3ncvQv5xx3QvEPryKUyfOIyBCb7zsEC61hmLR+u9R93kLTkQvyYDoRyGIStrP9fewb+5k/Pjjj8pjCladSTqlLxB3YS2mGKdPnomNl+NeYl5jwCqI4kXtkw+Ukk1e5LNLf9jUIG8ep+TyRRjiEZ/qRAC9uxiwcjwTFCtVDOZJe6/OeKB/rDxR6C7jxJnHyeFDm68oPFW5+bEBwbsnYeiopTgXbYcyrYfgi/+NwujxX2PK3DU4dPkqfGa0h4fSrSlzJijk6ZEclgxBJ3D0evqeSwYErf8KI2btwW2l9mdSrBSKpSw4rp46gbRLrsPlE2fwOGXBUdQzl/Lk5RiCd2PS0FFYei4admVaY8gX/5NrtePx9ZS5WHPoMq76zED75y84Eb3RLFC9btXkskuE3cDVwPRlVzyuXb+TXP5qHPMhn6XyhN5pDFg5nga5GzZFTZukPTwc22dOxr7kO8DH4cby7/DX6XjluVybqv8hqqU0GL04nR9mDPsOW66Gw2BaCQPmzMCPk37A91+Px2d926B6ocxvRpGeVb2mqO+QuLmJeD/8OnY+LqZqRo+7tRqjPv9O/r6G8CrTFQuu6aHJ3RBNa9ooNUOB8O0zMXlf0iXT8jw3luO7v07LxVsiTd76+FCdBYffjGH4bstVhBtMUWnAHMz4cRJ++P5rjP+sL9pUL/SM23AQkbrkMq31ZGzYsgVbMnxswFcN7ZVyQpLLmnFYb5y+eRW+qGHxEvMaK1Dyd7f8GE2U+3OJuCOY8+Ua3E7VQhV17g/8sPS6XGoYSbCtWgdVWPciIw7T8LpkZ6DRJ2LPpylDCsg7sTDPV0bUb95KNKlZTDiYpAzcKVlXEV+fVIYikKUZpsG0qvjeX6e8otBdEZOqmyrzm4qy406I5J8Rf0yMLp30miQsXUqJyjVqiBrGR82aonb9hqJFl8Him0VHRVC6j31apDg85r2UgTsljbDzqCPa9OgturWpI4rZpdyuwrTUSHFQGbXvyZ5PU4aRkB+SeT5Rpn5z0apJTVHMwSTlcmnJWlT5+qQy/IRR2mEaTKt+L55e9EmievK6SX3Lm3hxbHTp5HklSxdRqrKy3DVqipq164uGLbqIwd8sEkefv+CkAg7TQJnLyjANmcnKvPHi7E91hVw/TCwrJBPhWPJ90aFXH9GjTW1RxFaTXA5JpkXFoJ1PlPnoXZR6mAYGrNcmm/cijDgupjR0FibJIevph2ThITr8eUH+5BQvFbCETtxY3keUskkJOBk+JFPh1m6+uPa8rBFzTvzeprAwe8YyaBxqiIkHQ5UZjCLE8SkNhXOqEPnUQ7IQHh3+FBfS3AfsZQKW/NqN5aJPKZtMxrtJeshh0K2dmP/cBaeXxYBFmXvVAUumuylW9CkprJ9V/mqdRK2JB5LHIKR3E8fBehNZV8JnGw9j/bddUb1gyijkRpKpIzw/GIifdx7E0j4lU8ZsekmG4KPYfvQxTC1SfVlGRDxur/0KU/c/59IZcy/0X3kUe38dgiZl8sJcSvlcyTQXSn40DPP2bcGXNVPfi94alT7biMPrv0XX6gVTRp43kkzh6PkBBv68EweX9kFJ9RYcR7cfxWNTC+XUQWYE4m+vxVdT9yvPieitpC2EDn8cxsGF/0PrivlhlepqIeMdKdxrdsVXaw5j+5e1weuKKYlkbMGSa4Xw9fVVJlHOF4Pgy+dxJTBCzh+5UbBYCbjZqzwaU8wRjK/5Ab47EQWYFMXH89ZhZmcvOCZdi2yIQaDvdHzcbBz2JPQyN0Wtny7C5/Miia8/lwExD27i6t0QxJo4wLVIEThbPz/vxwRfxvkrgYiQg1fugsVQws1e5XGoYnBkfE188N0JRMEERT+eh3UzO8MrZcERE+iL6R83w7g9iRcWmNb6CXE+nye+TK9EUFAQXFxcYCyrKlSooEwlej1iQ+Sy69ZDxGht4eLugfy2SeUDvev69+8Pf39/+Pj4sJP7m8kCeT0rombduqhZyUv9cCWLO7UOa5TLlyX7amjdPlW4MtJYwKVKI1QvmPTdErTa7PwODSzyFEHp8pVQsUzRLIUrIzOTGNw5ewy+xy/ikbweVF/yuFNYt+YMEgawl+xRrXX7VOHKSP7dLlXQqHrB5O+WsrXcRPSmM89VGF7GsqtscYYryhQDFmVIY2ONpPFMDY+3YdYP23Er9f0f4oJwaPbXWHBBuXbGtCiq1XBJ+PcrY7iDuV1ro83ALzBqeHd88MFo+Kg9YrLGJmUgV8NjbJv1A7anXXAEHZqNrxdcSLxqSDJF0Wo1El4hIiJKwoBFGTIp2QV93ndK3EAMD7Hv64/g4ZQHhYuXQqniReCS2w21R2zAXeM9EiUzuHf5CkMrv+Jrk3X3cON2yqCAuoAbuKV2wDIpiS593ldGmjfg4b6v8ZGHE/IULo5SpYqjiEtuuNUegQ13jfdIlGDm3gVfDa2cMCsREVESBizKmLYoBizbil/61kIBK+Mo6AL6qIe4ddkf/pdvICg8PiFgmOeriI7frMfeP9oh/6vemszKoW3vxihio5UzXV5U7NMdDVQfkEqLogOWYesvfVGrgFXCyPdCH4WHty7D3/8ybgSFKzeMzYeKHb/B+r1/oN0rX3AiInrTsJM7PZch/BZOHv0X564F4GFYNPSSGawc86FQyYqoUbk4nP7rQfUMcYgTZjB71V2fDOG4dfIo/j13DQEPwxCtl2Bm5Yh8hUqiYo3KKP6fL/i7i53ciehNkLqTOwMWEeV4DFhE9CbgVYRERERErxADFhEREZHKGLCIiIiIVMaARURERKQyBiwiIiIilTFgEREREamMAYuIiIhIZQxYRERERCpjwCIiIiJSGQMWERERkcoYsIiIiIhUxoBFREREpDIGLCIiIiKVMWARERERqYwBi4iIiEhlDFhEREREKmPAIiIiIlIZAxYRERGRyhiwiIiIiFTGgEVERESkMgYsIiIiIpUxYBERERGpjAGLiIiISGUMWEREREQqY8AiIiIiUhkDFhEREZHKJG9vb7F582b07NlTmURElLNERERg6tSp6N+/P1xcXJSpREQ5y8aNG5E7d25s374d0qhRo8TatWuVl4iIiIjoRdWpUwd//PEHJCFTphERERGRCtgHi4iIiEhVwP8B1R6g0gRAO2AAAAAASUVORK5CYII=\" /></p>', NULL, '2024-03-04 08:40:55', '2024-03-05 16:05:21', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1980, '29geuv', NULL, NULL, 'Sơ đồ tổ chức', 'so-do-to-chuc', '', NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong>DNTN SẢN XUẤT - THƯƠNG MẠI NGUYỄN TR&Igrave;NH</strong></span></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/sodo.png\" alt=\"sodo\" width=\"758\" height=\"\" /></p>', NULL, '2024-03-04 09:18:30', '2024-03-05 16:04:52', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1981, '31qzjf', NULL, NULL, 'Cửa nhôm', 'cua-nhom', '', NULL, NULL, '<p>&nbsp; &nbsp; &nbsp;Nguyễn Tr&igrave;nh l&agrave; đơn vị chuy&ecirc;n sản xuất, thi c&ocirc;ng lắp đặt cửa nh&ocirc;m c&aacute;c loại cung cấp cho c&aacute;c c&ocirc;ng tr&igrave;nh, c&ocirc;ng ty, đơn vị thầu x&acirc;y dựng,&hellip; Với sứ mệnh mang đến sản phẩm cửa ch&iacute;nh h&atilde;ng chất lượng, gi&aacute; th&agrave;nh hợp l&yacute;, chiết khấu cao đến c&aacute;c đối t&aacute;c của m&igrave;nh.</p>\r\n<table style=\"border-collapse: collapse; width: 90.2396%; margin-left: auto; margin-right: auto; height: 164px;\" border=\"1\">\r\n<tbody>\r\n<tr style=\"height: 164px;\">\r\n<td style=\"width: 33.3333%; height: 164px;\"><img src=\"/images/posts/31qzjf/DTK_55325.jpg\" alt=\"DTK_55325\" width=\"256\" height=\"\" /></td>\r\n<td style=\"width: 33.3333%; height: 164px;\"><img src=\"/images/posts/31qzjf/DTK_55395.jpg\" alt=\"DTK_55395\" width=\"254\" height=\"\" /></td>\r\n<td style=\"width: 23.574%; height: 164px;\"><img src=\"/images/posts/31qzjf/DTK_55905-HDR.jpg\" alt=\"DTK_55905-HDR\" width=\"168\" height=\"\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;Ch&uacute;ng t&ocirc;i c&ograve;n hỗ trợ chăm s&oacute;c kh&aacute;ch h&agrave;ng sau lắp đặt với ch&iacute;nh s&aacute;ch bảo h&agrave;nh d&agrave;i hạn kh&ocirc;ng ph&aacute;t sinh th&ecirc;m chi ph&iacute; k&egrave;m phiếu bảo h&agrave;nh nhằm tạo niềm tin, sự an t&acirc;m khi sử dụng sản phẩm cho người ti&ecirc;u d&ugrave;ng.</p>\r\n<p>Gh&eacute; thăm website cửa nh&ocirc;m tại đường dẫn:<strong><a title=\"Cửa nh&ocirc;m Nguyễn Tr&igrave;nh\" href=\"https://cua.nguyentrinh.com\" target=\"_blank\" rel=\"noopener\"> https://cua.nguyentrinh.com</a></strong></p>\r\n<p style=\"text-align: left;\">Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết về c&aacute;c sản phẩm cửa nh&ocirc;m</p>\r\n<p style=\"text-align: left;\">Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng: <strong>(+84)903.336.470</strong> hoặc thư điện tử:<strong> nguyentrinh@gmail.com</strong></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/31qzjf/cuanhom1.png\" alt=\"cuanhom1\" width=\"591\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/31qzjf/nangluc.png\" alt=\"nangluc\" width=\"470\" height=\"\" /><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/31qzjf/baohanh.png\" alt=\"baohanh\" /></p>', NULL, '2024-03-04 15:27:49', '2024-03-07 14:21:59', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1983, '68hwsk', NULL, NULL, 'Chứng nhận, chứng chỉ, giấy phép', 'chung-nhan-chung-chi', '', NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong>CHỨNG NHẬN, CHỨNG CHỈ, GIẤY PH&Eacute;P</strong></span></p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 14pt;\"><strong><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi.jpg\" alt=\"chungchi\" width=\"522\" height=\"750\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi2.jpg\" alt=\"chungchi2\" width=\"513\" height=\"745\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi3.jpg\" alt=\"chungchi3\" width=\"518\" height=\"734\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi4.jpg\" alt=\"chungchi4\" width=\"455\" height=\"644\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi5.jpg\" alt=\"chungchi5\" width=\"632\" height=\"850\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungchi55.jpg\" alt=\"chungchi55\" width=\"642\" height=\"842\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/chungnahan.jpg\" alt=\"chungnahan\" width=\"499\" height=\"688\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/iso.jpg\" alt=\"iso\" width=\"666\" height=\"925\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/iso2.jpg\" alt=\"iso2\" width=\"661\" height=\"953\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/68hwsk/qd.jpg\" alt=\"qd\" width=\"637\" height=\"910\" /> </strong></span></p>', NULL, '2024-03-04 15:54:57', '2024-03-05 15:49:34', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1984, '59ilum', '/images/posts/59ilum/hoatdong.jpg', 'hoat-dong-doanh-nghiep', '[HOẠT ĐỘNG] VÒNG 2 CUỘC THI \"CHIẾN BINH CHỐT ĐƠN\"', 'chien-binh-chot-don', 'Vòng hai cuộc thi “Chiến binh chốt đơn\" năm 2023 diễn ra từ ngày 31/07/2023 đến ngày 30/09/2023 tại Nguyễn Trình. Tại đây, 03 đội được đào tạo kiến thức về sản phẩm cửa nhôm XinGfa và kỹ năng tiếp cận khách hàng thực tế của Nguyễn Trình.', NULL, NULL, '<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\" style=\"text-align: justify;\">V&Ograve;NG 2 CUỘC THI \"CHIẾN BINH CHỐT ĐƠN\" <strong>DO TRƯỜNG ĐẠI HỌC TR&Agrave; VINH</strong> V&Agrave; <strong>DNTN SX-TM NGUYỄN TR&Igrave;NH</strong> PHỐI HỢP TỔ CHỨC.</div>\r\n<div dir=\"auto\" style=\"text-align: justify;\">V&ograve;ng hai cuộc thi &ldquo;Chiến binh chốt đơn\" năm 2023 diễn ra từ ng&agrave;y 31/07/2023 đến ng&agrave;y 30/09/2023 tại Nguyễn Tr&igrave;nh. Tại đ&acirc;y, 03 đội được đ&agrave;o tạo kiến thức về sản phẩm cửa nh&ocirc;m XinGfa v&agrave; kỹ năng tiếp cận kh&aacute;ch h&agrave;ng thực tế của Nguyễn Tr&igrave;nh.</div>\r\n<div dir=\"auto\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" title=\"Cuộc thi Chiến binh chốt đơn\" src=\"/images/posts/59ilum/chienbinhchotdon.jpg\" alt=\"Cuộc thi Chiến binh chốt đơn\" width=\"558\" height=\"\" /></div>\r\n<div dir=\"auto\" style=\"text-align: center;\">H&igrave;nh ảnh cuộc thi</div>\r\n<div dir=\"auto\" style=\"text-align: left;\"><span style=\"text-align: justify;\">Ng&agrave;y 10/08/2023, c&aacute;c đội thi được đi tham quan Triễn l&atilde;m Quốc tế Vietbuild 2023 với hơn 2000 gian h&agrave;ng c&ocirc;ng nghệ x&acirc;y dựng, VLXD v&agrave; nhiều sản phẩm mới từ nhiều quốc gia, với mục đ&iacute;ch t&igrave;m hiểu v&agrave; cập nhật xu hướng mới của ng&agrave;nh x&acirc;y dựng. Chuyến đi sẽ gi&uacute;p c&aacute;c em củng cố th&ecirc;m kiến thức để thực hiện tốt cuộc thi.</span></div>\r\n</div>\r\n<div class=\"ddict_btn\" style=\"top: 14px; left: 1064.74px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>\r\n<div class=\"ddict_btn\" style=\"top: 21px; left: 817.67px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>', NULL, '2023-08-11 16:18:27', '2024-03-06 17:12:41', 1, '', '', '', 'PUBLISH', 'hoat-dong', 'vi', 'POST');
INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `summary_one`, `summary_two`, `content`, `content_one`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1985, '51disc', '/images/posts/51disc/hoatdong.jpg', 'hoat-dong-doanh-nghiep', '[HOẠT ĐỘNG] VÒNG LOẠI CUỘC THI \"CHIẾN BINH CHỐT ĐƠN\"', 'vong-loai-chien-binh-chot-don', 'Vòng loại cuộc thi “Chiến binh chốt đơn\" năm 2023 đã diễn ra vào ngày 24-7 tại Trường Đại học Trà Vinh. Tại đây, 10 đội đã hoàn thành tốt bài thi qua việc trình bày các kế hoạch kinh doanh đầy sáng tạo và chuyên nghiệp.', NULL, NULL, '<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">&nbsp; &nbsp; &nbsp;V&ograve;ng loại cuộc thi &ldquo;Chiến binh chốt đơn\" năm 2023 đ&atilde; diễn ra v&agrave;o ng&agrave;y 24-7 tại Trường Đại học Tr&agrave; Vinh. Tại đ&acirc;y, 10 đội đ&atilde; ho&agrave;n th&agrave;nh tốt b&agrave;i thi qua việc tr&igrave;nh b&agrave;y c&aacute;c kế hoạch kinh doanh đầy s&aacute;ng tạo v&agrave; chuy&ecirc;n nghiệp. <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/51disc/cuocthichotdon1.jpg\" alt=\"cuocthichotdon1\" width=\"686\" height=\"\" /></div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\" style=\"text-align: justify;\">&nbsp; &nbsp; 3 đội đ&atilde; xuất sắc bước v&agrave;o v&ograve;ng trong v&agrave; bắt đầu cho thời gian thực tập tại DNTN SX-TM Nguyễn Tr&igrave;nh - đơn vị đồng h&agrave;nh v&agrave; t&agrave;i trợ ch&iacute;nh cuộc thi. V&ograve;ng chung kết v&agrave; Trao Giải của cuộc thi dự kiến diễn ra v&agrave;o ng&agrave;y 09/10/2023 với cơ cấu giải thưởng như sau:</div>\r\n<div dir=\"auto\" style=\"text-align: justify;\">&nbsp; &nbsp; &bull; Giải nhất: 20 triệu đồng, đội c&oacute; số lượng hợp đồng hợp lệ nhiều nhất.</div>\r\n<div dir=\"auto\" style=\"text-align: justify;\">&nbsp; &nbsp; &bull; Giải nh&igrave;: 7 triệu đồng, đội c&oacute; số lượng hợp đồng hợp lệ nhiều thứ hai.</div>\r\n<div dir=\"auto\" style=\"text-align: justify;\">&nbsp; &nbsp; &bull; Giải ba: 3 triệu đồng, đội c&oacute; số lượng hợp đồng hợp lệ nhiều thứ ba.</div>\r\n<div dir=\"auto\" style=\"text-align: justify;\">&nbsp; &nbsp; &bull; Giải c&aacute; nh&acirc;n xuất sắc: 10 triệu đồng, c&aacute; nh&acirc;n c&oacute; số lượng hợp đồng hợp lệ nhiều nhất.</div>\r\n</div>', NULL, '2023-07-23 16:28:14', '2024-03-06 17:12:46', 1, '', '', '', 'PUBLISH', 'hoat-dong', 'vi', 'POST'),
(1986, '22psvy', '/images/posts/22psvy/quyetdinh.jpg', 'cong-bo-thong-tin;quyet-dinh', '[QUYẾT ĐỊNH] Phê duyệt kết quả thẩm định báo cáo đánh giá tác động môi trường của dự án “Trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại I”', 'qd-trung-tam-sat-hach', 'Quyết định của Ủy ban Nhân dân tỉnh Trà Vinh về việc phê duyệt kết quả thẩm định báo cáo đánh giá tác động môi trườngcủa dự án “Trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại I” ngày  9 tháng 1o năm 2023.', NULL, NULL, '<p>Ph&ecirc; duyệt kết quả thẩm định b&aacute;o c&aacute;o đ&aacute;nh gi&aacute; t&aacute;c động m&ocirc;i trườngcủa dự &aacute;n &ldquo;Trung t&acirc;m đ&agrave;o tạo v&agrave; s&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I&rdquo;Ph&ecirc; duyệt kết quả thẩm định b&aacute;o c&aacute;o đ&aacute;nh gi&aacute; t&aacute;c động m&ocirc;i trườngcủa dự &aacute;n &ldquo;Trung t&acirc;m đ&agrave;o tạo v&agrave; s&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I.</p>\r\n<p><object data=\"/images/posts/22psvy/QD-1517_Phe_duyet_de_an_truong_lai.pdf\" type=\"application/pdf\" width=\"100%\" height=\"1000\">\r\n  <p>Tải file <a href=\"/images/posts/22psvy/QD-1517_Phe_duyet_de_an_truong_lai.pdf\">tại đây</a></p></object></p>\r\n<p><em><strong>Tải xuống quyết định tại đ&acirc;y: </strong><span style=\"text-decoration: underline;\"><a title=\"QD-1517_Phe_duyet_de_an_truong_lai\" href=\"/images/posts/22psvy/QD-1517_Phe_duyet_de_an_truong_lai.pdf\">QD-1517_Phe_duyet_de_an_truong_lai</a></span></em></p>', NULL, '2023-10-09 08:04:34', '2024-03-06 17:12:24', 1, '', '', '', 'PUBLISH', 'quyet-dinh', 'vi', 'POST'),
(1987, '24oqaw', '/images/posts/24oqaw/quyetdinh.jpg', 'cong-bo-thong-tin;quyet-dinh', '[QUYẾT ĐỊNH] Chấp thuận chủ trương đầu tư đồng thời chấp thuận nhà đầu tư', 'qd-chu-truong-dau-tu', 'Quyết định của Ủy ban Nhân dân tỉnh Trà Vinh về việc chấp thuận chủ trương đầu tư đồng thời chấp thuận nhà đầu tư - ngày 19 tháng 7 năm 2023.', NULL, NULL, '<p>Quyết định về việc chấp thuận chủ trương đầu tư đồng thời chấp thuận nh&agrave; đầu tư của Ủy ban Nh&acirc;n d&acirc;n tỉnh Tr&agrave; Vinh.</p>\r\n<p>T&ecirc;n dự &aacute;n: Trung t&acirc;m đ&agrave;o tạo v&agrave; s&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I.</p>\r\n<p>Nh&agrave; đầu tư: Doanh nghiệp tư nh&acirc;n Sản xuất - Thương mại Nguyễn Tr&igrave;nh.</p>\r\n<p>Địa điểm thực hiện dự &aacute;n: Ấp Giồng Tr&ocirc;m, x&atilde; Mỹ Ch&aacute;nh, huyện Ch&acirc;u Th&agrave;nh, tỉnh Tr&agrave; Vinh.</p>\r\n<p><object data=\"/images/posts/24oqaw/QD%20CH%E1%BA%A4P%20THU%E1%BA%ACN%20CH%E1%BB%A6%20TR%C6%AF%C6%A0NG%20%C4%90%E1%BA%A6U%20T%C6%AF.pdf\" type=\"application/pdf\" width=\"100%\" height=\"1000\">\r\n  <p>Tải file <a href=\"/images/posts/24oqaw/QD%20CH%E1%BA%A4P%20THU%E1%BA%ACN%20CH%E1%BB%A6%20TR%C6%AF%C6%A0NG%20%C4%90%E1%BA%A6U%20T%C6%AF.pdf\">tại đây</a></p></object></p>\r\n<p><strong>Xem chi tết tại đ&acirc;y: </strong><span style=\"text-decoration: underline;\"><a title=\"QD CHẤP THUẬN CHỦ TRƯƠNG ĐẦU TƯ\" href=\"/images/posts/24oqaw/QD%20CH%E1%BA%A4P%20THU%E1%BA%ACN%20CH%E1%BB%A6%20TR%C6%AF%C6%A0NG%20%C4%90%E1%BA%A6U%20T%C6%AF.pdf\">QD CHẤP THUẬN CHỦ TRƯƠNG ĐẦU TƯ ĐỒNG THỜI CHẤP THUẬN NH&Agrave; ĐẦU TƯ</a> </span></p>', NULL, '2023-07-19 08:14:58', '2024-03-06 17:12:32', 1, '', '', '', 'PUBLISH', 'quyet-dinh', 'vi', 'POST'),
(1989, '12yhop', '/images/posts/12yhop/congbo.jpg', 'cong-bo-thong-tin', '[CÔNG BỐ] Đồ án quy hoạch xây dựng chi tiết xây dựng rút gọn trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại 1', 'do-an-quy-hoach-xay-dung-ttxh', 'Đồ án quy hoạch xây dựng chi tiết xây dựng rút gọn trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại 1.\r\nĐịa điểm xây dựng: huyện Châu Thành, tỉnh Trà Vinh.', NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong>BẢN VẼ QUY HOẠCH SỬ DỤNG ĐẤT, TL:1/500</strong></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong><img src=\"/images/posts/12yhop/da0800a7c9bc1ee247ad.jpg\" alt=\"da0800a7c9bc1ee247ad\" width=\"652\" height=\"904\" /> </strong></span></p>', NULL, '2024-03-05 10:35:44', '2024-03-06 17:12:51', 1, '', '', '', 'PUBLISH', 'cong-bo', 'vi', 'POST'),
(1990, '49zcpn', '/images/posts/49zcpn/tuyendung1.jpg', 'tuyen-dung', '[TUYỂN DỤNG] Tuyển dụng nhân lực năm 2024', 'tuyen-dung-test', 'Yêu cầu:Tốt nghiệp Đại học hệ chính quy chuyên ngành: ...Sử dụng thành thạo các phần mềm vi tính văn phòng.Kỹ năng giao tiếp tốt, tinh thần trách nhiệm cao, trung thực.Ưu tiên ứng viên có kinh nghiệm trong lĩnh vực ...* Địa điểm làm việc: xã Mỹ Chánh, huyện Châu Thành, Trà Vinh.', NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong>[TEST]</strong></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14pt;\"><strong>TUYỂN DỤNG</strong></span></p>\r\n<p><em><strong>* Y&ecirc;u cầu:</strong></em></p>\r\n<ul>\r\n<li>Tốt nghiệp Đại học hệ ch&iacute;nh quy chuy&ecirc;n ng&agrave;nh: ...</li>\r\n<li>Sử dụng th&agrave;nh thạo c&aacute;c phần mềm vi t&iacute;nh văn ph&ograve;ng.</li>\r\n<li>Kỹ năng giao tiếp tốt, tinh thần tr&aacute;ch nhiệm cao, trung thực.</li>\r\n</ul>\r\n<p>Ưu ti&ecirc;n ứng vi&ecirc;n c&oacute; kinh nghiệm trong lĩnh vực ...</p>\r\n<p><em><strong>* Địa điểm l&agrave;m việc:</strong></em> x&atilde; Mỹ Ch&aacute;nh, huyện Ch&acirc;u Th&agrave;nh, Tr&agrave; Vinh.</p>\r\n<p><strong><em>* Hồ sơ dự tuyển gồm:</em></strong></p>\r\n<ol>\r\n<li>Đơn xin việc viết tay.</li>\r\n<li>Sơ yếu l&yacute; lịch c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương (c&oacute; d&aacute;n ảnh<br />chụp trong v&ograve;ng 6 th&aacute;ng )</li>\r\n<li>Bản sao chứng thực bằng tốt nghiệp Đại học hoặc giấy chứng nhận tốt<br />nghiệp Đại học tạm thời (đối với trường hợp mới tốt nghiệp), bảng điểm kết<br />quả học tập; Giấy khai sinh; Bản sao Giấy CMND, hộ khẩu v&agrave; c&aacute;c văn bằng;<br />chứng chỉ kh&aacute;c c&oacute; li&ecirc;n quan.</li>\r\n<li>Giấy chứng nhận sức khỏe.</li>\r\n<li>Bản sao c&aacute;c Quyết định Giấy tờ c&oacute; li&ecirc;n quan đến qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c<br />trước đ&oacute; (nếu c&oacute;).</li>\r\n</ol>\r\n<p><em><strong>* Thời hạn nhận hồ sơ:</strong></em> đến hết ng&agrave;y 1/1/2024.</p>\r\n<p><em><strong>* Địa điểm nhận hồ sơ:</strong></em> Cửa h&agrave;ng DN Nguyễn Tr&igrave;nh, Đường Nguyễn Đ&aacute;ng, Phường 9, Tr&agrave; Vinh.</p>', NULL, '2024-03-05 10:49:01', '2024-03-06 17:10:42', 1, '', '', '', 'PUBLISH', 'tuyen-dung', 'vi', 'POST'),
(1991, '19spou', '/images/posts/19spou/tuyendung1.jpg', 'tuyen-dung', '[TUYỂN DỤNG] Giáo viên dạy lý thuyết, Giáo viên dạy thực hành lái xe', 'tuyen-dung-giao-vien-day-ly-thuyet-thuc-hanh', 'Thời hạn tuyển dụng: Đến hết tháng 8/2023\r\nMô tả công việc: Pháp luật GTĐB, Kỹ thuật lái xe, nghiệp vụ vận tải, đạo đức người lái xe, cấu tạo và sửa chữa thông thường\r\n- Số lượng: 08 người\r\n\r\n- Trình độ kỹ năng nghề: Sư phạm dạy nghề\r\n- Lương thử việc: 4.500.000 đồng\r\n- Lương chính thức: 6.000.000 đồng\r\n- Chế độ phúc lợi (BHXH, ăn, ở, thưởng,...): Theo quy định nhà nước và quy định Trung tâm Đào tạo và Sát hạch lái xe cơ giới đường bộ loại I.', NULL, NULL, '<p style=\"text-align: center;\"><span style=\"font-size: 18pt;\"><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></span></p>\r\n<p style=\"text-align: center;\">***</p>\r\n<p><strong>- T&ecirc;n đơn vị tuyển dụng:</strong> Trung t&acirc;m Đ&agrave;o tạo v&agrave; S&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I trực thuộc DNTN Sản xuất - Thương mại Nguyễn Tr&igrave;nh</p>\r\n<p><strong>- Ng&agrave;nh nghề kinh doanh:</strong> Đ&agrave;o tạo v&agrave; s&aacute;t hạch l&aacute;i xe c&aacute;c loại.</p>\r\n<p><strong>- Người đại diện:</strong> &Ocirc;ng Trương Ho&agrave;ng Sang. Địa chỉ: Đường V&otilde; Văn Kiệt, kh&oacute;m 4, phường 1, th&agrave;nh phố Tr&agrave; Vinh, tỉnh Tr&agrave; Vinh</p>\r\n<p><strong>- Số điện thoại:</strong> 090 127 0182.</p>\r\n<p><strong>- Thời hạn tuyển dụng:</strong> Đến hết th&aacute;ng 8/2023.</p>\r\n<p><strong>NHU CẦU TUYỂN DỤNG</strong></p>\r\n<p><strong>1. Vị tr&iacute;: Gi&aacute;o vi&ecirc;n dạy l&yacute; thuyết</strong></p>\r\n<p>- M&ocirc; tả c&ocirc;ng việc: Ph&aacute;p luật GTĐB, Kỹ thuật l&aacute;i xe, nghiệp vụ vận tải, đạo đức người l&aacute;i xe, cấu tạo v&agrave; sửa chữa th&ocirc;ng thường</p>\r\n<p>- Số lượng: 08 người</p>\r\n<p>- Tr&igrave;nh độ kỹ năng nghề: Sư phạm dạy nghề</p>\r\n<p>- Lương thử việc: 4.500.000 đồng</p>\r\n<p>- Lương ch&iacute;nh thức: 6.000.000 đồng</p>\r\n<p>- Chế độ ph&uacute;c lợi (BHXH, ăn, ở, thưởng,...): Theo quy định nh&agrave; nước v&agrave; quy định Trung t&acirc;m Đ&agrave;o tạo v&agrave; S&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I</p>\r\n<p><strong>2. Vị tr&iacute;: Gi&aacute;o vi&ecirc;n dạy thực h&agrave;nh</strong></p>\r\n<p>- M&ocirc; tả c&ocirc;ng việc: thực h&agrave;nh hạng B1, B2, C, F; thực h&agrave;nh n&acirc;ng hạng B2 l&ecirc;n D v&agrave; E; thực h&agrave;nh n&acirc;ng hạng C l&ecirc;n D v&agrave; E</p>\r\n<p>- Số lượng: 100 người</p>\r\n<p>- Tr&igrave;nh độ kỹ năng nghề: Sư phạm nghề</p>\r\n<p>- Lương thử việc: 4.500.000 đồng</p>\r\n<p>- Lương ch&iacute;nh thức: 6.000.000 đồng</p>\r\n<p>- Chế độ ph&uacute;c lợi (BHXH, ăn, ở, thưởng,...): Theo quy định nh&agrave; nước v&agrave; quy định Trung t&acirc;m Đ&agrave;o tạo v&agrave; S&aacute;t hạch l&aacute;i xe cơ giới đường bộ loại I.</p>\r\n<p><strong>3. Số lượng tuyển dụng: 108 gi&aacute;o vi&ecirc;n</strong></p>\r\n<table style=\"border-collapse: collapse; width: 58.6787%; height: 301px; margin-left: auto; margin-right: auto;\" border=\"1\">\r\n<tbody>\r\n<tr style=\"height: 17px;\">\r\n<td style=\"width: 7.50161%; height: 17px; text-align: center;\">\r\n<p><strong>TT</strong></p>\r\n</td>\r\n<td style=\"width: 44.6709%; height: 17px; text-align: center;\"><strong>Tr&igrave;nh độ ng&agrave;nh,nghề đ&agrave;o tạo&nbsp;</strong></td>\r\n<td style=\"width: 6.51122%; height: 17px; text-align: center;\"><strong>Số lượng</strong></td>\r\n</tr>\r\n<tr style=\"height: 24px;\">\r\n<td style=\"width: 7.50161%; height: 24px; text-align: center;\"><strong>I</strong></td>\r\n<td style=\"width: 44.6709%; height: 24px;\"><strong>GV Dạy L&yacute; Thuyết&nbsp;</strong></td>\r\n<td style=\"width: 6.51122%; height: 24px; text-align: center;\"><strong>08</strong></td>\r\n</tr>\r\n<tr style=\"height: 22px;\">\r\n<td style=\"width: 7.50161%; height: 22px; text-align: center;\">1.1</td>\r\n<td style=\"width: 44.6709%; height: 22px;\">Ph&aacute;p luật GTĐB</td>\r\n<td style=\"width: 6.51122%; height: 22px; text-align: center;\">04</td>\r\n</tr>\r\n<tr style=\"height: 21px;\">\r\n<td style=\"width: 7.50161%; height: 21px; text-align: center;\">1.2</td>\r\n<td style=\"width: 44.6709%; height: 21px;\">Kỹ thuật l&aacute;i xe</td>\r\n<td style=\"width: 6.51122%; height: 21px; text-align: center;\">01</td>\r\n</tr>\r\n<tr style=\"height: 23px;\">\r\n<td style=\"width: 7.50161%; height: 23px; text-align: center;\">1.3</td>\r\n<td style=\"width: 44.6709%; height: 23px;\">Nghiệp vụ vận tải</td>\r\n<td style=\"width: 6.51122%; height: 23px; text-align: center;\">01</td>\r\n</tr>\r\n<tr style=\"height: 23px;\">\r\n<td style=\"width: 7.50161%; height: 23px; text-align: center;\">1.4</td>\r\n<td style=\"width: 44.6709%; height: 23px;\">Đạo đức người l&aacute;i xe</td>\r\n<td style=\"width: 6.51122%; height: 23px; text-align: center;\">01</td>\r\n</tr>\r\n<tr style=\"height: 20px;\">\r\n<td style=\"width: 7.50161%; height: 20px; text-align: center;\">1.5</td>\r\n<td style=\"width: 44.6709%; height: 20px;\">Cấu tạo v&agrave; sửa chữa th&ocirc;ng thường</td>\r\n<td style=\"width: 6.51122%; height: 20px; text-align: center;\">01</td>\r\n</tr>\r\n<tr style=\"height: 28px;\">\r\n<td style=\"width: 7.50161%; height: 28px; text-align: center;\"><strong>II</strong></td>\r\n<td style=\"width: 44.6709%; height: 28px;\"><strong>GV Dạy Thực H&agrave;nh 100</strong></td>\r\n<td style=\"width: 6.51122%; height: 28px; text-align: center;\"><strong>100</strong></td>\r\n</tr>\r\n<tr style=\"height: 23px;\">\r\n<td style=\"width: 7.50161%; height: 23px; text-align: center;\">2.1&nbsp;</td>\r\n<td style=\"width: 44.6709%; height: 23px;\">Thực h&agrave;nh hạng B1, B2 55</td>\r\n<td style=\"width: 6.51122%; height: 23px; text-align: center;\">55</td>\r\n</tr>\r\n<tr style=\"height: 25px;\">\r\n<td style=\"width: 7.50161%; height: 25px; text-align: center;\">2.2&nbsp;</td>\r\n<td style=\"width: 44.6709%; height: 25px;\">Thực h&agrave;nh hạng C 25</td>\r\n<td style=\"width: 6.51122%; height: 25px; text-align: center;\">25</td>\r\n</tr>\r\n<tr style=\"height: 24px;\">\r\n<td style=\"width: 7.50161%; height: 24px; text-align: center;\">2.3&nbsp;</td>\r\n<td style=\"width: 44.6709%; height: 24px;\">Thực h&agrave;nh n&acirc;ng hạng B2 l&ecirc;n D v&agrave; E 09</td>\r\n<td style=\"width: 6.51122%; height: 24px; text-align: center;\">09</td>\r\n</tr>\r\n<tr style=\"height: 26px;\">\r\n<td style=\"width: 7.50161%; height: 26px; text-align: center;\">2.4&nbsp;</td>\r\n<td style=\"width: 44.6709%; height: 26px;\">Thực h&agrave;nh n&acirc;ng hạng C l&ecirc;n D v&agrave; E 09</td>\r\n<td style=\"width: 6.51122%; height: 26px; text-align: center;\">09</td>\r\n</tr>\r\n<tr style=\"height: 25px;\">\r\n<td style=\"width: 7.50161%; height: 25px; text-align: center;\">2.5&nbsp;</td>\r\n<td style=\"width: 44.6709%; height: 25px;\">Thực h&agrave;nh hạng F 02</td>\r\n<td style=\"width: 6.51122%; height: 25px; text-align: center;\">02</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><strong>4. Ti&ecirc;u chuẩn tuyển dụng</strong></p>\r\n<p>a) C&oacute; tr&igrave;nh độ trung cấp chuy&ecirc;n m&ocirc;n trở l&ecirc;n (*)</p>\r\n<p>b) C&oacute; giấy ph&eacute;p l&aacute;i xe hạng tương ứng hoặc cao hơn hạng xe đ&agrave;o tạo, nhưng kh&ocirc;ng thấp hơn hạng B2 (*)</p>\r\n<p>c) Gi&aacute;o vi&ecirc;n dạy c&aacute;c hạng B1, B2 phải c&oacute; giấy ph&eacute;p l&aacute;i xe đủ thời gian từ 03 năm trở l&ecirc;n, kể từ ng&agrave;y tr&uacute;ng tuyển; gi&aacute;o vi&ecirc;n dạy c&aacute;c hạng C, D, E v&agrave; F phải c&oacute; giấy ph&eacute;p l&aacute;i xe đủ thời gian từ 05 năm trở l&ecirc;n kể từ ng&agrave;y tr&uacute;ng tuyển (*)</p>\r\n<p>d) Đ&atilde; ho&agrave;n th&agrave;nh chương tr&igrave;nh Bồi dưỡng Nghiệp vụ Sư phạm v&agrave; được cấp Chứng chỉ sư phạm.</p>\r\n<p>e) Đ&atilde; ho&agrave;n th&agrave;nh kh&oacute;a tập huấn gi&aacute; vi&ecirc;n dạy thực h&agrave;nh l&aacute;i xe &ocirc;t&ocirc; v&agrave; được cấp Chứng nhận.</p>\r\n<p><strong>(*) Ti&ecirc;u chuẩn bắt buộc phải c&oacute;.</strong></p>\r\n<p><strong>Ghi ch&uacute;: Nếu ứng vi&ecirc;n chưa tham chương tr&igrave;nh Bồi dưỡng Nghiệp vụ Sư phạm v&agrave; kh&oacute;a tập huấn gi&aacute; vi&ecirc;n dạy thực h&agrave;nh l&aacute;i xe &ocirc;t&ocirc;. Doanh nghiệp sẽ c&oacute; ch&iacute;nh s&aacute;ch hỗ trợ cho ứng vi&ecirc;n tham gia đ&agrave;o đạo.</strong></p>\r\n<p style=\"text-align: center;\"><strong>Xem chi tiết v&agrave; tải xuống th&ocirc;ng tin tuyển dụng tại đ&acirc;y: <a title=\"TB TUYEN DUNG GIAO VIEN\" href=\"/images/posts/19spou/TB%20TUYEN%20DUNG%20GIAO%20VIEN.pdf\">TB TUYEN DUNG GIAO VIEN</a></strong></p>', NULL, '2023-08-31 10:54:46', '2024-03-06 17:12:20', 1, '', '', '', 'PUBLISH', 'tuyen-dung', 'vi', 'POST'),
(1992, '42ndie', NULL, NULL, 'Gạch không nung', 'gach-khong-nung', 'Học hỏi kinh nghiệm sản xuất VLXD không nung ở các nước tiên tiến như Đức, Liên Bang Nga, Thái Lan, Trung Quốc... từ những năm 2008 - 2009. Tích lũy các nguồn lực, kiến thức logic chỉ một thời gian ngắn sau khi tiến hành đầu tư, DNTN Sản xuất - Thương mại Nguyễn Trình tự hào trở thành nhà sản xuất gạch không nung xi măng cốt liệu với sản lượng và công nghệ hàng đầu tại Việt Nam.', NULL, NULL, '<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;Học hỏi kinh nghiệm sản xu&acirc;́t VLXD không nung ở các nước tiên ti&ecirc;́n như Đức, Liên Bang Nga, Thái Lan, Trung Qu&ocirc;́c... từ những năm 2008 - 2009. Tích lũy các ngu&ocirc;̀n lực, ki&ecirc;́n thức logic chỉ một thời gian ngắn sau khi ti&ecirc;́n hành đ&acirc;̀u tư, DNTN Sản xu&acirc;́t - Thương mại Nguy&ecirc;̃n Trình tự hào trở thành nhà sản xu&acirc;́t gạch không nung xi măng c&ocirc;́t liệu với sản lượng và công nghệ hàng đ&acirc;̀u tại Việt Nam.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/42ndie/gach.jpg\" alt=\"gach\" width=\"747\" height=\"\" /></p>\r\n<p>&nbsp; &nbsp; &nbsp;M&ocirc;̃i năm Nguy&ecirc;̃n Trình có khả năng cung c&acirc;́p ra thị trường khoảng 110 triệu sản ph&acirc;̉m gạch QTC có m&acirc;̃u mã đa dạng đáp ứng yêu c&acirc;̀u của nhi&ecirc;̀u loại công trình, với ch&acirc;́t lượng cao và giá cả hợp lý.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/42ndie/hopdongtieubieu.jpg\" alt=\"hopdongtieubieu\" /></p>\r\n<p style=\"text-align: left;\">Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết về sản phẩm gạch kh&ocirc;ng nung</p>\r\n<p style=\"text-align: left;\">Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng: <strong>(+84)903.336.470</strong> hoặc thư điện tử:<strong> nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 13:48:04', '2024-03-05 16:03:12', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1993, '66hfov', NULL, NULL, 'Vật liệu xây dựng - Trang trí nội thất', 'vat-lieu-xay-dung-trang-tri-noi-that', 'Nguyễn Trình là đơn vị chuyên cung cấp vật liệu xây dựng – trang trí nội thất; đèn trang trí và thiết bị điện nước chính hãng, với mức giá phải chăng và chính sách hỗ vận chuyển lắp đặt chuyên nghiệp. Góp phần thay đổi diện mạo cơ sở hạ tầng tại địa phương, thúc đẩy phát triển kinh tế – xã hội.', NULL, NULL, '<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;Nguyễn Tr&igrave;nh l&agrave; đơn vị chuy&ecirc;n cung cấp vật liệu x&acirc;y dựng &ndash; trang tr&iacute; nội thất; đ&egrave;n trang tr&iacute; v&agrave; thiết bị điện nước ch&iacute;nh h&atilde;ng, với mức gi&aacute; phải chăng v&agrave; ch&iacute;nh s&aacute;ch hỗ vận chuyển lắp đặt chuy&ecirc;n nghiệp. G&oacute;p phần thay đổi diện mạo cơ sở hạ tầng tại địa phương, th&uacute;c đẩy ph&aacute;t triển kinh tế &ndash; x&atilde; hội.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/66hfov/vlxd.jpg\" alt=\"vlxd\" /></p>\r\n<p>Mua sắm c&aacute;c mặt h&agrave;ng&nbsp;tại địa chỉ: Đường Nguyễn Đ&aacute;ng, Kh&oacute;m 10, Phường 9, TP. Tr&agrave; Vinh.</p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m chi tiết về c&aacute;c sản phẩm vật liệu x&acirc;y dựng &ndash; trang tr&iacute; nội thất qua:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng: <strong>(+84)903.336.470</strong> hoặc thư điện tử: <strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 14:18:42', '2024-03-07 13:45:30', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1994, '38cdhu', NULL, NULL, 'Vận tải hàng hóa', 'van-tai-hang-hoa', '', NULL, NULL, '<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;C&aacute;c dịch vụ vận tải đường bộ hiện nay của c&ocirc;ng ty l&agrave; dịch vụ vận chuyển xe, m&aacute;y chuy&ecirc;n d&ugrave;ng; dịch vụ vận chuyển container; dịch vụ vận chuyển h&agrave;ng ủy th&aacute;c, dịch vụ vận chuyển h&agrave;ng lẻ, kết hợp.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/38cdhu/IMG_7182.jpg\" alt=\"IMG_7182\" /></p>\r\n<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;Trong đ&oacute;, c&ocirc;ng ty c&oacute; thế mạnh đặc biệt trong vận chuyển xi măng, tro bay từ c&aacute;c tỉnh miền t&acirc;y l&ecirc;n miền đ&ocirc;ng v&agrave; ngược lại; đồng thời vận chuyển linh kiện, phụ t&ugrave;ng v&agrave; c&aacute;c loại h&agrave;ng h&oacute;a. Hiện nay, c&ocirc;ng ty đang thực hiện vận chuyển cho hơn 30 kh&aacute;ch h&agrave;ng thường xuy&ecirc;n v&agrave; gần 40 kh&aacute;ch h&agrave;ng chiến lược với c&aacute;c loại h&agrave;ng h&oacute;a chủ yếu như h&agrave;ng container; xi măng; tro bay v&agrave; nguy&ecirc;n vật liệu.</p>\r\n<p>&nbsp;</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/38cdhu/vthh.jpg\" alt=\"vthh\" width=\"603\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/38cdhu/phuongtien.jpg\" alt=\"phuongtien\" width=\"411\" height=\"499\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:&nbsp;<strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 14:28:27', '2024-03-06 14:14:04', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1996, '45exaw', NULL, NULL, 'Bê tông tươi', 'be-tong-tuoi', '', NULL, NULL, '<p>&nbsp; &nbsp; &nbsp;Hiện nay Doanh nghiệp Nguyễn Tr&igrave;nh c&oacute; 04 trạm b&ecirc; t&ocirc;ng:</p>\r\n<p>- 02 trạm ở x&atilde; Long To&agrave;n , thị x&atilde; Duy&ecirc;n Hải năng xuất 90m3/giờ.&nbsp;</p>\r\n<p>- 01 trạm ở Kh&oacute;m 2, Phường 9, TP Tr&agrave; Vinh năng xuất 60m3/giờ.</p>\r\n<p>- 03 trạm ở Khu c&ocirc;ng nghiệp Long Đức, TP Tr&agrave; Vinh năng xuất 150m3/giờ.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/45exaw/trambetong.png\" alt=\"trambetong\" width=\"552\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/45exaw/DTK_7217_Original.jpg\" alt=\"DTK_7217_Original\" width=\"711\" height=\"\" /></p>\r\n<p style=\"text-align: center;\">Trạm b&ecirc; t&ocirc;ng Doanh nghiệp Nguyễn Tr&igrave;nh tại Long Đức, TP Tr&agrave; Vinh&nbsp;</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/45exaw/xebretong.jpg\" alt=\"xebretong\" width=\"838\" height=\"\" /></p>\r\n<p style=\"text-align: center;\">Xe bơm b&ecirc; t&ocirc;ng của doanh nghiệp Nguyễn Tr&igrave;nh&nbsp;</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/45exaw/hopdongtieubieu.png\" alt=\"hopdongtieubieu\" width=\"606\" height=\"\" /></p>\r\n<p style=\"text-align: center;\">C&aacute;c hợp đồng ti&ecirc;u biểu ch&uacute;ng t&ocirc;i đ&atilde; ho&agrave;n th&agrave;nh</p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết về c&aacute;c dịch vụ b&ecirc; t&ocirc;ng!</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:&nbsp;<strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 14:47:25', '2024-03-06 14:14:27', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1997, '58dvmz', NULL, NULL, 'Cống bê tông ly tâm', 'cong-be-tong', '', NULL, NULL, '<p>&nbsp; &nbsp; &nbsp;DNTN SX-TM Nguyễn Tr&igrave;nh đ&atilde; đầu tư c&ocirc;ng nghệ quay ly t&acirc;m hiện đại kết hợp nạp liệu v&agrave; h&agrave;n khung th&eacute;p tự động đ&atilde; tạo n&ecirc;n c&aacute;c loại cống th&agrave;nh phẩm chất lượng cao với những t&iacute;nh năng vượt trội: Bề mặt cống nhẵn phẳng, độ n&eacute;n chặt của b&ecirc; t&ocirc;ng cao, khả năng chịu &aacute;p lực cao, chịu m&agrave;i m&ograve;ntốt, k&iacute;ch thước h&igrave;nh học ch&iacute;nh x&aacute;c, lắp đặt joint k&iacute;n kh&iacute;t, kh&ocirc;ng r&ograve; rỉ, thời gian sử dụng l&acirc;u d&agrave;i.</p>\r\n<p style=\"text-align: right;\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/58dvmz/IMG_7164.jpg\" alt=\"IMG_7164\" width=\"551\" height=\"413\" /></p>\r\n<p style=\"text-align: right;\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/58dvmz/congbetong.jpg\" alt=\"congbetong\" width=\"549\" height=\"506\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/58dvmz/congbetong2.jpg\" alt=\"congbetong2\" /> <img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/58dvmz/congbetong3.jpg\" alt=\"congbetong3\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:&nbsp;<strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 15:12:08', '2024-03-06 14:13:51', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1998, '30erca', NULL, NULL, 'Cọc bê tông ly tâm', 'coc-be-tong', '', NULL, NULL, '<p style=\"text-align: justify;\">&nbsp; &nbsp; &nbsp;Cọc b&ecirc; t&ocirc;ng ly t&acirc;m được DN Nguyễn Tr&igrave;nh sản xuất tr&ecirc;n d&acirc;y chuyền v&agrave; c&ocirc;ng nghệ v&ocirc; c&ugrave;ng ti&ecirc;n tiến, hiện đại, kết<br />hợp nạp liệu tự động. Cọc được sản xuất theo ti&ecirc;u chuẩn TCVN 7888:2008. Phần b&ecirc; t&ocirc;ng của cột được đổ theo phương thức quay ly t&acirc;m v&agrave; được đưa v&agrave;o l&ograve; hơi ở nhiệt độ 96&deg;C. Ch&iacute;nh v&igrave; vậy m&agrave; phần b&ecirc; t&ocirc;ng rất chắc v&agrave; đặc, kh&ocirc;ng bị nứt vỡ cũng như chịu được tải trọng cao, khả năng chống thấm tốt, chống ăn m&ograve;n cao.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/30erca/DTK_7324_Original.jpg\" alt=\"DTK_7324_Original\" width=\"465\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/30erca/DTK_7340_Original.jpg\" alt=\"DTK_7340_Original\" width=\"464\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/30erca/DTK_7360_Original.jpg\" alt=\"DTK_7360_Original\" width=\"460\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/30erca/DTK_7373_Original.jpg\" alt=\"DTK_7373_Original\" width=\"458\" height=\"\" /><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/30erca/tieubieu.jpg\" alt=\"tieubieu\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:&nbsp;<strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 15:16:55', '2024-03-06 14:14:12', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1999, '52osyp', NULL, NULL, 'New Post Title here...', 'new-post-title-here-2', NULL, NULL, NULL, NULL, NULL, '2024-03-05 15:21:22', '2024-03-05 15:21:22', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'SLIDE'),
(2000, '14iqzr', NULL, NULL, 'Bê tông nhựa nóng', 'be-tong-nhua-nong', '', NULL, NULL, '<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/14iqzr/nhuanong.jpg\" alt=\"nhuanong\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/14iqzr/hopdongcaitao.jpg\" alt=\"hopdongcaitao\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/14iqzr/lu.jpg\" alt=\"lu\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:<strong>&nbsp;nguyentrinh@gmail.com</strong></p>\r\n<p>&nbsp;</p>', NULL, '2024-03-05 15:28:11', '2024-03-05 16:02:59', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(2001, '95rqvg', NULL, NULL, 'Sản xuất điện', 'san-xuat-dien', '', NULL, NULL, '<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/95rqvg/sanxnuatdien.jpg\" alt=\"sanxnuatdien\" width=\"592\" height=\"\" /></p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/95rqvg/hopdongdien.jpg\" alt=\"hopdongdien\" width=\"596\" height=\"\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:<strong>&nbsp;nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 15:34:34', '2024-03-05 16:02:45', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(2002, '31jhsz', NULL, NULL, 'Ép cọc công trình', 'ep-coc', '', NULL, NULL, '<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/31jhsz/epcoc.jpg\" alt=\"epcoc\" /></p>\r\n<p>Li&ecirc;n hệ với ch&uacute;ng t&ocirc;i để biết th&ecirc;m th&ocirc;ng tin chi tiết:</p>\r\n<p>Số điện thoại chăm s&oacute;c kh&aacute;ch h&agrave;ng:&nbsp;<strong>(+84)903.336.470</strong>&nbsp;hoặc thư điện tử:&nbsp;<strong>nguyentrinh@gmail.com</strong></p>', NULL, '2024-03-05 15:40:54', '2024-03-05 16:02:25', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(2003, '56dmhz', '/images/posts/56dmhz/vanchuyen.png', NULL, 'VẬN TẢI HÀNG HÓA', 'new-post-title-here', 'Các dịch vụ vận tải hiện nay của công ty là dịch vụ vận chuyển xe, máy chuyên dùng; dịch vụ vận chuyển container,...', '/post/van-tai-hang-hoa', NULL, NULL, NULL, '2024-03-06 08:47:28', '2024-03-06 16:17:01', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(2004, '60mejl', '/images/posts/60mejl/sxdien.png', NULL, 'SẢN XUẤT ĐIỆN', 'new-post-title-here-8', 'Sản xuất điện biến đổi từ ánh sáng mặt trời thành điện năng nhờ những tấm pin mặt trời.', '/post/san-xuat-dien', NULL, NULL, NULL, '2024-03-06 09:38:00', '2024-03-06 16:17:09', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(2006, '66xigy', '/images/posts/66xigy/hoatdong.jpg', 'hoat-dong-doanh-nghiep', '[HOẠT ĐỘNG ] TRƯỜNG KINH TẾ, LUẬT, TRƯỜNG ĐẠI HỌC TRÀ VINH THAM QUAN DNTN SX-TM NGUYỄN TRÌNH ', 'don-tiep-doan', 'Ngày 10/07/2023, DNTN SX-TM Nguyễn Trình đã đón tiếp đoàn sinh viên từ Trường Kinh tế, Luật, Trường Đại học Trà Vinh đến tham quan cơ sở làm việc.', NULL, NULL, '<p>&nbsp; &nbsp; &nbsp;Ng&agrave;y 10/07/2023, DNTN SX-TM Nguyễn Tr&igrave;nh đ&atilde; đ&oacute;n tiếp đo&agrave;n sinh vi&ecirc;n từ Trường Kinh tế, Luật, Trường Đại học Tr&agrave; Vinh đến tham quan cơ sở l&agrave;m việc. Hiện tại DNTN SX-TM Nguyễn Tr&igrave;nh v&agrave; nh&agrave; trường kết hợp tổ chức cuộc thi \"Chiến Binh chốt đơn\" nhằm tạo ra cơ hội để sinh vi&ecirc;n c&oacute; thể n&acirc;ng cao khả năng s&aacute;ng tạo v&agrave; học hỏi kinh nghiệm thực tế trong việc nghi&ecirc;n cứu thị trường v&agrave; tiếp cận kh&aacute;ch h&agrave;ng.</p>\r\n<table style=\"border-collapse: collapse; width: 96.412%; height: 1103px;\" border=\"1\">\r\n<tbody>\r\n<tr style=\"height: 278px;\">\r\n<td style=\"width: 50%; height: 278px;\"><img src=\"/images/posts/66xigy/doan1.jpg\" alt=\"doan1\" width=\"429\" height=\"285\" /></td>\r\n<td style=\"width: 50%; height: 278px;\"><img src=\"/images/posts/66xigy/doan10.jpg\" alt=\"doan10\" width=\"424\" height=\"282\" /></td>\r\n</tr>\r\n<tr style=\"height: 286px;\">\r\n<td style=\"width: 50%; height: 286px;\"><img src=\"/images/posts/66xigy/doan2.jpg\" alt=\"doan2\" width=\"429\" height=\"285\" /></td>\r\n<td style=\"width: 50%; height: 286px;\"><img src=\"/images/posts/66xigy/doan3.jpg\" alt=\"doan3\" width=\"423\" height=\"282\" /></td>\r\n</tr>\r\n<tr style=\"height: 280px;\">\r\n<td style=\"width: 50%; height: 280px;\"><img src=\"/images/posts/66xigy/doan4.jpg\" alt=\"doan4\" width=\"426\" height=\"283\" /></td>\r\n<td style=\"width: 50%; height: 280px;\"><img src=\"/images/posts/66xigy/doan5.jpg\" alt=\"doan5\" width=\"421\" height=\"280\" /></td>\r\n</tr>\r\n<tr style=\"height: 259px;\">\r\n<td style=\"width: 50%; height: 259px;\"><img src=\"/images/posts/66xigy/doan6.jpg\" alt=\"doan6\" width=\"427\" height=\"284\" /></td>\r\n<td style=\"width: 50%; height: 259px;\"><img src=\"/images/posts/66xigy/doan8.jpg\" alt=\"doan8\" width=\"425\" height=\"282\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/66xigy/doan9.jpg\" alt=\"doan9\" width=\"478\" height=\"318\" /></p>\r\n<p>Xem th&ocirc;ng tin chi tiết b&agrave;i biết tại:</p>\r\n<p><iframe style=\"border: none; overflow: hidden;\" src=\"https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fpermalink.php%3Fstory_fbid%3Dpfbid0nMyGqS4Hn1a9jymJrhwqRwqCBSQTU8CmMWxWrv5a28sz9ijQFQrLsiNVPAFwqPFGl%26id%3D100094631493232&amp;show_text=true&amp;width=500\" width=\"500\" height=\"933\" frameborder=\"0\" scrolling=\"no\" allowfullscreen=\"allowfullscreen\"></iframe></p>', NULL, '2023-07-10 10:49:14', '2024-03-06 17:12:37', 1, '', '', '', 'PUBLISH', 'hoat-dong', 'vi', 'POST'),
(2009, '22xzks', NULL, NULL, 'Đào tạo sát hạch lái xe', 'dao-tao-sat-hach-lai-xe', '', NULL, NULL, '<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/images/posts/22xzks/baotri.jpg\" alt=\"baotri\" width=\"771\" height=\"\" /></p>', NULL, '2024-03-07 07:57:21', '2024-03-07 14:18:28', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `post_documents`
--

DROP TABLE IF EXISTS `post_documents`;
CREATE TABLE IF NOT EXISTS `post_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `file_extension` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `file_size` float DEFAULT NULL,
  `summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `post_documents`
--

INSERT INTO `post_documents` (`id`, `pid`, `name`, `url`, `file_name`, `file_extension`, `file_size`, `summary`, `date_created`, `user_created`) VALUES
(2, 4, 'xxxx', '4e00364886ba63c506cb9ea6888ffa8b.pdf', '[Nguyen Trinh] Quasoft Quotation (1).pdf', 'pdf', 586302, '', '2023-07-27 09:46:40', 1),
(3, 4, 'ddd', '49a2cf59b2fafed4a952d97561cb159d.xlsx', '_tinChi.xlsx', 'xlsx', 12009, '', '2023-07-27 13:46:06', 1),
(9, 4, 'test', '1e1848cc61ce6f23004dc03bcdfb7a33.xlsx', 'Book1.xlsx', 'xlsx', 71423, '', '2023-08-08 14:47:02', 1),
(23, 1939, 'z', 'dedc53d5cf13d6317fb41856b398dfdf.png', 'Screenshot 2023-10-12 at 7-48-03 PM.png', 'png', 0, 'z', '2024-01-17 16:44:17', 1),
(24, 1939, 'x', '7e9244d5fd393e63efc654b1c5e850b5.png', 'cua-di-2-canh-lam-sang-thumb.png', 'png', 55643, 'x', '2024-01-17 16:45:10', 1),
(25, 1939, 'xxx sgsdgs gsdfg ', 'e708dd3df9ea7d3aea67a7f8b4b3f720.png', 'Screenshot 2023-11-24 090111.png', 'png', 172554, ' gfdsgsfd sdg s', '2024-01-17 23:13:40', 1),
(26, 1939, 'gfds g gsg ', 'd8ef67bb4bf511833d4f292f20735c74.docx', '09.XN.NPT.TNCN.docx', 'docx', 21745, 'sfdfgd fd g', '2024-01-17 23:36:25', 1),
(27, 1939, '9', '917c3d9d6397f24609199967673b16ff.docx', '20.DK.TCT.docx', 'docx', 20300, '9', '2024-01-18 08:28:21', 1),
(30, 1963, 'hiển thị', '88b901dcde9176d182bb1200e7f1f65e.docx', '09.XN.NPT.TNCN.docx', 'docx', 21745, 'summary', '2024-02-03 17:38:40', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `post_images`
--

DROP TABLE IF EXISTS `post_images`;
CREATE TABLE IF NOT EXISTS `post_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `img_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `post_images`
--

INSERT INTO `post_images` (`id`, `pid`, `name`, `url`, `img_name`, `img_extension`, `img_size`, `img_wh`, `summary`, `date_created`, `user_created`) VALUES
(60, 4, '', 'ed3157a0407910d797205eb21ff9a536.png', 'fubusta_lines_qr_code_192720766.png', 'png', 318, NULL, '', '2023-07-27 09:46:55', 1),
(65, 4, '', '6c2b00941d0b18faa721d2c510164c68.jpg', 'tuyendung.jpg', 'jpg', 83283, NULL, '', '2023-08-08 14:46:49', 1),
(72, 1939, '8eb63e3c6d38ba66e329.jpg', 'b828a61c01a6ff029d9d289fa462dc68.jpg', NULL, 'jpg', 116459, NULL, '1', '2024-01-17 22:11:24', 1),
(74, 1939, 'post2.jpg', '73309892cc6ad5b701a7d3766d29e7a6.jpg', NULL, 'jpg', 389200, NULL, 'u', '2024-01-17 22:33:03', 1),
(75, 1939, 'post1.jpg', 'ab8c19d5dc848f789f80a8c239268615.jpg', NULL, 'jpg', 373978, NULL, 'b', '2024-01-17 22:36:18', 1),
(78, 1939, 'Screenshot 2023-11-24 090111.png', 'ba3e4ed5a5345fd87b32714a1637f51a.png', NULL, 'png', 172554, NULL, 'y', '2024-01-17 22:50:37', 1),
(80, 1963, 'post2-thumb.jpg', '881259fecb3abebc268a5ba6dd65d051.jpg', NULL, 'jpg', 62954, NULL, 'fdsaf', '2024-02-03 17:40:31', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `post_types`
--

DROP TABLE IF EXISTS `post_types`;
CREATE TABLE IF NOT EXISTS `post_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `enable_images` tinyint(1) DEFAULT NULL,
  `enable_documents` tinyint(1) DEFAULT NULL,
  `enable_cover` tinyint(1) DEFAULT NULL,
  `enable_seo` tinyint(1) DEFAULT NULL,
  `enable_summary` tinyint(1) DEFAULT NULL,
  `enable_summary_one` tinyint(1) DEFAULT NULL,
  `enable_summary_two` tinyint(1) DEFAULT NULL,
  `enable_content` tinyint(1) DEFAULT NULL,
  `enable_content_one` tinyint(1) DEFAULT NULL,
  `enable_categories` tinyint(1) DEFAULT NULL,
  `enable_languages` tinyint(1) DEFAULT NULL,
  `enable_tags` tinyint(1) DEFAULT NULL,
  `layout` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `enable_single_view` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `post_types`
--

INSERT INTO `post_types` (`id`, `code`, `name`, `enable`, `enable_images`, `enable_documents`, `enable_cover`, `enable_seo`, `enable_summary`, `enable_summary_one`, `enable_summary_two`, `enable_content`, `enable_content_one`, `enable_categories`, `enable_languages`, `enable_tags`, `layout`, `enable_single_view`) VALUES
(1, 'POST', 'Bài viết', 1, 0, 0, 1, 1, 1, NULL, NULL, 1, NULL, 1, 1, 1, NULL, 1),
(2, 'PRODUCT', 'Sản phẩm', 0, 1, 0, 1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'SLIDE', 'Slides', 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL),
(4, 'PAGE', 'Trang tĩnh', 1, 0, 0, 0, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, '', 1),
(5, 'SERVICE', 'Dịch vụ', 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, '', 0),
(6, 'DOCUMENT', 'Tài liệu', 0, 0, 1, 0, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'GIATRI', 'Giá trị cốt lõi', 0, 0, 0, 1, 1, 1, NULL, NULL, 0, NULL, 0, 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `site_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `site_logo` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_logo_small` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_copyright` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `site_source` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `top_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `top_email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `top_hotline` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_copyright_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `site_source_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `top_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `text_homepage` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `map` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `showcase_text` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `showcase_text_en` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `showcase_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `showcase_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `showcase_summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `showcase_summary_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_summary_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_page_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_page_name_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_page_seo_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_page_seo_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_fist_content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_fist_content_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `branches_fist_image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `branches_show_default` tinyint(1) DEFAULT NULL,
  `service_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `service_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `service_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `service_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `service_summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `service_summary_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `service_image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `show_service_image` tinyint(1) DEFAULT NULL,
  `about_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about_summary1` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_summary1_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_summary2` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_summary2_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_fact` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_fact_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about_image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about2_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about2_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about2_summary` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about2_summary_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about2_image` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about3_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about3_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `about3_content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `about3_content_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `contact_text` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_text_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `contact_content_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `show_index_block` tinyint(1) DEFAULT NULL,
  `site_index_block_1` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `site_index_block_2` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `site_index_block_1_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `site_index_block_2_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `site_index_bg_map` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_index_bg_blog` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `site_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `number_post_trending` tinyint DEFAULT NULL,
  `number_post_catalog_home` tinyint DEFAULT NULL,
  `number_post_per_page` tinyint DEFAULT NULL,
  `number_post_like_in_news` tinyint DEFAULT NULL,
  `show_cover_after_summary` tinyint DEFAULT NULL,
  `sustainability_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sustainability_title_en` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sustainability_content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `sustainability_content_en` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `sustainability_seo_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sustainability_seo_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_logo`, `site_logo_small`, `site_copyright`, `site_source`, `top_text`, `top_email`, `top_hotline`, `site_copyright_en`, `site_source_en`, `top_text_en`, `text_homepage`, `map`, `showcase_text`, `showcase_text_en`, `showcase_title`, `showcase_title_en`, `showcase_summary`, `showcase_summary_en`, `branches_text`, `branches_text_en`, `branches_title`, `branches_title_en`, `branches_summary`, `branches_summary_en`, `branches_page_name`, `branches_page_name_en`, `branches_page_seo_title`, `branches_page_seo_description`, `branches_fist_content`, `branches_fist_content_en`, `branches_fist_image`, `branches_show_default`, `service_text`, `service_text_en`, `service_title`, `service_title_en`, `service_summary`, `service_summary_en`, `service_image`, `show_service_image`, `about_text`, `about_text_en`, `about_title`, `about_title_en`, `about_summary1`, `about_summary1_en`, `about_summary2`, `about_summary2_en`, `about_fact`, `about_fact_en`, `about_image`, `about2_title`, `about2_title_en`, `about2_summary`, `about2_summary_en`, `about2_image`, `about3_text`, `about3_text_en`, `about3_content`, `about3_content_en`, `contact_text`, `contact_text_en`, `contact_title`, `contact_title_en`, `contact_content`, `contact_content_en`, `show_index_block`, `site_index_block_1`, `site_index_block_2`, `site_index_block_1_en`, `site_index_block_2_en`, `site_index_bg_map`, `site_index_bg_blog`, `site_title`, `site_description`, `number_post_trending`, `number_post_catalog_home`, `number_post_per_page`, `number_post_like_in_news`, `show_cover_after_summary`, `sustainability_title`, `sustainability_title_en`, `sustainability_content`, `sustainability_content_en`, `sustainability_seo_title`, `sustainability_seo_description`) VALUES
(1, 'Apeiron Bioenergy', 'http://localhost:9999/images/posts/_default/logo%20(1).png', 'http://localhost:9999/images/posts/_default/favicon.png', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Giờ làm việc từ thứ Hai đến thứ Bảy : 6.00 am - 17.00 pm ', 'hung.nguyen@apeironbioenergy.com', '+84977240268', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Opening Hours: Mon - Tues : 6.00 am - 10.00 pm, Sunday Closed ', 'Trang chủ', 'Kho Bình Dương|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5723.825837906647!2d106.77691103005164!3d10.890222031753956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3174d75fb25e520d%3A0x869bfd7c0b43eca4!2sC%C3%B4ng%20ty%20TNHH%20APEIRON%20BIOENERGY%20(Vi%E1%BB%87t%20Nam)!5e0!3m2!1sen!2s!4v1681005437821!5m2!1sen!2s||Kho Cần Thơ|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3927.693039920593!2d105.687917!3d10.1241926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a0851a2a478199%3A0x18bd88ce74f3f82!2sKho%20C%E1%BA%A7n%20Th%C6%A1-%20C%C3%B4ng%20ty%20Apeiron%20Bioenergy%20(%20Viet%20Nam)!5e0!3m2!1sen!2s!4v1681006199837!5m2!1sen!2s||Kho Hà Nội|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3727.7535732850815!2d105.8643875!3d20.8819806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135b3ab78134ba1%3A0xb3a30b90ccd5f0e3!2sKho%20H%C3%A0%20N%E1%BB%99i-%20CTY%20TNHH%20APEIRON%20BIOENERGY%20(VI%E1%BB%86T%20NAM)!5e0!3m2!1sen!2s!4v1681007386542!5m2!1sen!2s', 'Nhà máy của chúng tôi', 'Showcase', 'Hình ảnh nhà máy của Apeiron Bioenergy tại Việt Nam', 'Image of Apeiron Bioenergy\'s factory in Vietnam', 'Công ty chúng tôi đầu tư các nhà máy với quy trình xử lý nghiêm ngặt, theo chuẩn của quốc tế và thân thiện với môi trường', 'Our company has a factory with a strict processing procedure that meets international standards and is environmentally friendly.', 'Văn phòng và Chi nhánh', 'Offices and Branches', 'Một viễn cảnh toàn cầu', 'A Global Perspective', 'Chúng tôi có trụ sở tại Singapore và hoạt động hai nhà máy lọc dầu cùng chín kho thu gom ở khắp châu Á. Sự mở rộng chiều dọc và tích hợp vào thị trường năng lượng sinh học đã giúp chúng tôi kiểm soát toàn bộ chuỗi cung ứng và cung cấp những giải pháp tốt hơn cho khách hàng.', 'Headquartered in Singapore, we operate two refineries and nine collection warehouses across Asia. Our vertical and horizontal expansion and integration into bioenergy markets has enabled us to gain better control over the entire supply chain, thereby providing more desirable solutions for our clients.', 'Chi Nhánh Toàn Cầu', 'Global Presence', '', '', '<h2>Trụ sở ch&iacute;nh</h2>\r\n<span style=\"font-size: 18pt;\">Singapore<br /><br /></span>\r\n<h2>Văn ph&ograve;ng chi nh&aacute;nh</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li class=\"list-item\"><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n</ol>', '<h2>Head Office</h2>\r\n<span style=\"font-size: 14pt;\">Singapore<br /><br /></span>\r\n<h2>Branch Offices</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n<li><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Cambodia</span></li>\r\n</ol>', 'https://apeironbioenergy.vn/images/posts/_services/map.png', 1, 'Sản phẩm của chúng tôi', 'Products', 'Nguồn nguyên liệu bền vững', 'The Source of Sustainable Feedstocks', 'Được tích hợp hoàn toàn vào toàn bộ chuỗi cung ứng, chúng tôi trực tiếp tìm  và thu gom chất thải trong các dự án thượng nguồn và có thể linh hoạt sử dụng chúng trong các dự án hạ nguồn của chúng tôi.\r\n\r\nCác sản phẩm của chúng tôi bao gồm dầu ăn đã qua sử dụng, nước thải của nhà máy sản  dầu cọ, metyl este từ dầu ăn đã qua sử dụng, glycerin thô và các sản phẩm khác.', 'Fully integrated into the entire supply chain, we directly source and collect wastes in upstream projects and have the flexibility to use them in our downstream projects.\r\n\r\nOur products include used cooking oil, palm oil mill effluent, used cooking oil methyl ester, crude glycerin, and other products.', 'https://apeironbioenergy.vn/images/posts/_services/2155d467c6451c1b4554.jpg', 0, 'Về chúng tôi', 'About Us', 'Công ty hàng đầu thế giới về năng lượng sinh học', 'Leading Global Player in Bioenergy', 'Apeiron Bioenergy là công ty toàn cầu tích hợp hàng đầu trong toàn bộ chuỗi sản phẩm năng lượng sinh học từ nguyên liệu đầu vào đến sản phẩm cuối cùng và phụ phẩm.', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 'Các hoạt động toàn cầu của chúng tôi bắt nguồn từ kiến thức và kinh nghiệm sâu rộng trong việc cải thiện chuỗi cung ứng, quản lý rủi ro và phân phối tập trung vào khách hàng để tạo ra một môi trường có giá trị và có lợi cho các nhà cung cấp và khách hàng của chúng tôi.', 'Our global operations stem from our extensive knowledge and experience in supply chain improvement, risk management, and client-focused distribution to create a valuable and profitable environment for our suppliers and customers.', 'Được thành lập vào năm 2007 với 15 năm hoạt động và thành tích tài chính. Chúng tôi đã giao hơn 500 triệu lít Dầu Đã Qua Sử Dụng (UCO) kể từ năm 2017.|Công ty dẫn đầu thị trường tại các thị trường xuất khẩu chính ở Châu Á.', 'Founded in 2007 with 15 years of operational and financial track record. We have delivered more than 500 million litres of UCO since 2017. |The market leader in key export markets in Asia.', 'https://apeironbioenergy.vn/images/posts/_about/2155d467c6451c1b4554.jpg', 'Tại sao phải tái chế dầu ăn đã qua sử dụng?', 'Why Recycle Used Cooking Oil?', '<p>Bạn có biết việc chuyển đổi từ dầu diesel xăng sang dầu diesel tái tạo làm bằng UCO dẫn đến lượng khí thải nhà kính thấp hơn 83% không? Bằng cách tái chế UCO, bạn đang góp phần tiết kiệm khí nhà kính và giúp bảo vệ trái đất của chúng ta thông qua nỗ lực phát triển bền vững của bạn.\r\n</p><p>\r\nViệc xử lý UCO không đúng cách làm tắc nghẽn nghiêm trọng hệ thống nước thải. Chỉ riêng San Francisco đã chi 3,5 triệu đô la hàng năm để thông cống rãnh chứa đầy chất béo, dầu và mỡ!</p>', '<p>Did you know switching from petroleum diesel to renewable diesel made of UCO results in more than 83% lower greenhouse gas emissions? By recycling UCO, you are contributing towards greenhouse gas savings and helping to preserve our earth through your sustainability effort.</p>\r\n<p>\r\nThe incorrect disposal of UCO severely clogs the sewage system. San Francisco alone spends $3.5 million annually to unclog sewers filled with fats, oils, and grease!</p>', 'https://apeironbioenergy.vn/images/posts/_about/about.jpg', 'Quy trình xử lý', 'Process', 'Lập kế hoạch chi tiết từ các nhóm quốc gia của chúng tôi với cộng đồng địa phương\r\n |Thu thập và giao cho các cơ sở thu gom và xử lý của chúng tôi\r\n  |Để yên, lọc và đun nóng để tách nước, cặn và dầu\r\n  |Cung cấp cho bể chứa trung tâm và xử lý nhiệt nhiều hơn\r\n  |Xuất khẩu đến các nhà máy lọc dầu diesel sinh học thông qua các tàu hàng rời', ' Detailed planning from our country teams with the local community\r\n |Collect and deliver to our collection and processing facilities\r\n |Rest, filter, and heat to separate water, residue, and oil\r\n |Deliver to central storage tanks and more heat treatment\r\n |Export to biodiesel refineries through bulk vessels', 'Liên hệ', 'Contact us', 'Xin vui lòng để lại thông tin bạn cần liên hệ', 'Feel Free To Contact Us', 'fa fa-map-marker|Địa chỉ|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email|hung.nguyen@apeironbioenergy.com||fa fa-phone|Gọi cho chúng tôi|+84977240268', 'fa fa-map-marker|Our Office|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email Us|hung.nguyen@apeironbioenergy.com||fa fa-envelope|fa fa-phone|+84977240268', 0, '<h3 class=\"text-white mb-3\">Giờ mở cửa</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 2 - Thứ 6</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 7</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Chủ nhật</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/contact\">Đặt lịch hẹn</a>', '<h3 class=\"text-white mb-3\">Li&ecirc;n hệ ngay</h3>\r\n<p class=\"text-white\">Bạn c&oacute; thể gọi đến số hotline của ch&uacute;ng t&ocirc;i để y&ecirc;u cầu dịch vụ hoặc cần li&ecirc;n hệ c&ocirc;ng việc</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', '<h3 class=\"text-white mb-3\">Opening Hours</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Mon - Fri</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Saturday</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Sunday</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/site/appointment\">Appointment</a>', '<h3 class=\"text-white mb-3\">Make Appointment</h3>\r\n<p class=\"text-white\">You can call our hotline to request service or need to contact work</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'Apeiron Bioenergy Vietnam', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 4, 5, 10, 5, 0, 'Giá Trị', 'Sustainability', '<h1>T&iacute;nh bền vững cốt l&otilde;i của ch&uacute;ng t&ocirc;i</h1>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom r&aacute;c thải với sứ mệnh bảo vệ m&ocirc;i trường, n&acirc;ng cao nhận thức v&agrave; đại diện cho lợi &iacute;ch của ng&agrave;nh năng lượng sinh học.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thực hiện c&aacute;c ti&ecirc;u ch&iacute; bền vững về x&atilde; hội v&agrave; sinh th&aacute;i nghi&ecirc;m ngặt trong quy tr&igrave;nh quản l&yacute; chuỗi cung ứng của m&igrave;nh. Qu&aacute; tr&igrave;nh n&agrave;y được kiểm tra thường xuy&ecirc;n v&agrave; c&aacute;c sản phẩm của ch&uacute;ng t&ocirc;i được chứng nhận với c&aacute;c ti&ecirc;u chuẩn bền vững như Chứng nhận Carbon &amp; Bền vững Quốc tế (ISCC) dầu mỏ.</p>\r\n<p>Th&ocirc;ng qua sự hợp t&aacute;c với c&aacute;c hộ gia đ&igrave;nh, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, nh&agrave; sản xuất thực phẩm địa phương, ch&uacute;ng t&ocirc;i n&acirc;ng cao nhận thức v&agrave; khuyến kh&iacute;ch việc xử l&yacute; r&aacute;c thải đ&uacute;ng c&aacute;ch.</p>\r\n<p>Đồng thời, ch&uacute;ng t&ocirc;i tạo cơ hội việc l&agrave;m cho c&aacute;c nền kinh tế địa phương th&ocirc;ng qua c&aacute;c hoạt động t&aacute;i chế.</p>\r\n<h1>T&aacute;c động của ch&uacute;ng t&ocirc;i về số lượng</h1>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image1.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image2.jpg\" alt=\"\" width=\"100%\" /></p>', '<h1 class=\"envionmnet-ttle\" data-w-id=\"23139613-11a9-b459-83dd-3d86c5ccdc8e\">Sustainability at Our Core<img class=\"environment-icon\" src=\"https://assets.website-files.com/622ecbb1fc363c1753ddeb5f/6230696327bb278eec2df55b_noun-green-city-1085044.svg\" alt=\"\" /></h1>\r\n<div class=\"enironmnet-content\">\r\n<div class=\"environmnet-text\">We collect wastes with the mission of protecting the environment, creating awareness, and representing the interests of the bioenergy industry.</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">We implement rigorous ecological and social sustainability criteria in our supply chain management process. This process is audited regularly and our products are certified with sustainability standards such as International Sustainability &amp; Carbon Certification (ISCC) .</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">Our business directly reduces the social costs of clogged sewage and reduced efficiency of wastewater treatment systems as a result of illegal disposal of used cooking oil.<br /><br />Through collaborations with local households, restaurants, hotels, food manufacturers, we create awareness and encourage the proper disposal of waste. At the same time, we create job opportunities for local economies through recycling activities.</div>\r\n<div class=\"environmnet-text\">&nbsp;</div>\r\n<div class=\"environmnet-text\">\r\n<h1 class=\"impact-title\" data-w-id=\"68f7fa92-83b1-c141-b7c7-897ff11d9b75\">Our Impact in Numbers</h1>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image1.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image2.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n</div>\r\n</div>', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `socials`
--

DROP TABLE IF EXISTS `socials`;
CREATE TABLE IF NOT EXISTS `socials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `icon` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `link` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `priority` tinyint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `socials`
--

INSERT INTO `socials` (`id`, `name`, `icon`, `link`, `priority`) VALUES
(1, 'Facebook', '<span class=\"icon-facebook\"></span>', 'facebook.com', 2),
(2, 'Twitter', '<span class=\"icon-twitter\"></span>', 'twitter.com', 1),
(3, 'Instagram', '<span class=\"icon-instagram\"></span>', 'instagram.com', 1),
(4, 'Youtube', '<span class=\"icon-youtube-play\"></span>', 'youtube.com', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tag_list`
--

DROP TABLE IF EXISTS `tag_list`;
CREATE TABLE IF NOT EXISTS `tag_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `slug` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int DEFAULT NULL,
  `seo_title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `tag_list`
--

INSERT INTO `tag_list` (`id`, `name`, `slug`, `date_created`, `user_created`, `seo_title`, `seo_description`) VALUES
(1, 'CÔNG BỐ', 'cong-bo', '2024-01-16 16:25:52', NULL, '', ''),
(2, 'HOẠT ĐỘNG', 'hoat-dong', '2024-01-16 16:25:52', NULL, '', ''),
(3, 'TUYỂN DỤNG', 'tuyen-dung', '2024-01-16 16:32:55', 1, '', ''),
(4, 'QUYẾT ĐỊNH', 'quyet-dinh', '2024-03-06 16:22:38', 1, '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `auth_key` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `confirmation_token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `superadmin` smallint DEFAULT '0',
  `created_at` int NOT NULL,
  `updated_at` int NOT NULL,
  `registration_ip` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email_confirmed` smallint NOT NULL DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `address` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `id_phong` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`, `name`, `phone`, `address`, `id_phong`) VALUES
(1, 'superadmin@gmail.com', 'kz2px152FAWlkHbkZoCiXgBAd-S8SSjF', '$2y$13$DSISRUJSkr4CPeb3Ciwl1u3ubaGF50gXzzgTaDmpi5ph2Hie8JL9q', NULL, 1, 1, 1426062188, 1586049758, NULL, '', 'superadmin@gmail.com', 1, 'Mr. Admin 1', '374711908', 'Càng Long - Trà Vinh 1', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `language` char(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  `visit_time` int NOT NULL,
  `browser` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `os` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '594b942a08db7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498125354, 'Chrome', 'Windows'),
(2, '594e6c6038079', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498311776, 'Chrome', 'Windows'),
(3, '594f4139aedb5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498366265, 'Chrome', 'Windows'),
(4, '595ef7d44d1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 1, 1499396052, 'Chrome', 'Windows'),
(5, '59e8a6d8a9558', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508419288, 'Chrome', 'Windows'),
(6, '59ee962cb327d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508808236, 'Chrome', 'Windows'),
(7, '59ef5ebdeec13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508859581, 'Chrome', 'Windows'),
(8, '59ef6a5ad7e55', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508862554, 'Chrome', 'Windows'),
(9, '59ef70a2e9811', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508864162, 'Chrome', 'Windows'),
(10, '59f0b2e7171a8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508946663, 'Chrome', 'Windows'),
(11, '59f0cd9d161a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508953501, 'Chrome', 'Windows'),
(12, '59f1304f26745', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508978767, 'Chrome', 'Windows'),
(13, '59f1456cbea96', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508984172, 'Chrome', 'Windows'),
(14, '59f1807420d18', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508999284, 'Chrome', 'Windows'),
(15, '59f29d6be7ea5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509072235, 'Chrome', 'Windows'),
(16, '59f2e74688480', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509091142, 'Chrome', 'Windows'),
(17, '59f3d7d1bcc8f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509152721, 'Chrome', 'Windows'),
(18, '59f688a11dd11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509329057, 'Chrome', 'Windows'),
(19, '59f6c6b702579', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509344951, 'Chrome', 'Windows'),
(20, '59f747ceb4e37', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509377998, 'Chrome', 'Windows'),
(21, '59f992dfa3650', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509528287, 'Chrome', 'Windows'),
(22, '59f9e7bbac6f9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509550011, 'Chrome', 'Windows'),
(23, '59fff730e5ab3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509947184, 'Chrome', 'Windows'),
(24, '5a005c828502a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509973122, 'Chrome', 'Windows'),
(25, '5a00833f42ef8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509983039, 'Chrome', 'Windows'),
(26, '5a008bd985854', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509985241, 'Chrome', 'Windows'),
(27, '5a032315d55e7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510155029, 'Chrome', 'Windows'),
(28, '5a09a9c638959', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510582726, 'Chrome', 'Windows'),
(29, '5a0bcc8d46ae1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510722701, 'Chrome', 'Windows'),
(30, '5a0c507c1bbc0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510756476, 'Chrome', 'Windows'),
(31, '5a158ee83c3a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511362280, 'Chrome', 'Windows'),
(32, '5a16e76aac9a0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511450474, 'Chrome', 'Windows'),
(33, '5a1c03e4e7758', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511785444, 'Chrome', 'Windows'),
(34, '5a1c2a002fa8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511795200, 'Chrome', 'Windows'),
(35, '5a1d8a8b23e08', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511885451, 'Chrome', 'Windows'),
(36, '5a202b327efa1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512057650, 'Chrome', 'Windows'),
(37, '5a24d16ba2ee7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512362347, 'Chrome', 'Windows'),
(38, '5a256932f0cc3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512401202, 'Chrome', 'Windows'),
(39, '5a26c795b5a20', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512490901, 'Chrome', 'Windows'),
(40, '5a2ab2d0d270e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512747728, 'Chrome', 'Windows'),
(41, '5a2e1341e8e0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512969025, 'Chrome', 'Windows'),
(42, '5a329a097ad3f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513265673, 'Chrome', 'Windows'),
(43, '5a33e86702cf4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513351271, 'Chrome', 'Windows'),
(44, '5b8566d214a65', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535469266, 'Chrome', 'Windows'),
(45, '5b878bb8d24fd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535609784, 'Chrome', 'Windows'),
(46, '5b880eecbba11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535643372, 'Chrome', 'Windows'),
(47, '5b8c87273a4fc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535936295, 'Chrome', 'Windows'),
(48, '5b8d23079177c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535976199, 'Chrome', 'Windows'),
(49, '5b8ddf31af79a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536024369, 'Chrome', 'Windows'),
(50, '5b8e819351601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536065939, 'Chrome', 'Windows'),
(51, '5b8e9d9d98f1c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536073117, 'Chrome', 'Windows'),
(52, '5b8ea8323c5b1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536075826, 'Chrome', 'Windows'),
(53, '5b8ea9e478538', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536076260, 'Chrome', 'Windows'),
(54, '5b8f277b1677c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536108411, 'Chrome', 'Windows'),
(55, '5b8f76b89e150', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536128696, 'Chrome', 'Windows'),
(56, '5b908f32ac6d8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536200498, 'Chrome', 'Windows'),
(57, '5b9a80b80c904', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536852152, 'Chrome', 'Windows'),
(58, '5b9a812bb36a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536852267, 'Chrome', 'Windows'),
(59, '5b9a860f21927', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853519, 'Chrome', 'Windows'),
(60, '5b9a876886dcd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853864, 'Chrome', 'Windows'),
(61, '5b9a881b4ba36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854043, 'Chrome', 'Windows'),
(62, '5b9a89a9e4cc1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854441, 'Chrome', 'Windows'),
(63, '5b9bbc7979e36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536932985, 'Chrome', 'Windows'),
(64, '5b9e6fa2dcd51', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537109922, 'Chrome', 'Windows'),
(65, '5ba1eeb6c9155', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537339062, 'Chrome', 'Windows'),
(66, '5ba7187e1e6ea', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36 Avast/69.0.792.81', 1, 1537677438, 'Chrome', 'Windows'),
(67, '5ba7195ab7712', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537677658, 'Chrome', 'Windows'),
(68, '5ba8816455e8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537769828, 'Chrome', 'Windows'),
(69, '5baa542ec53a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537889326, 'Chrome', 'Windows'),
(70, '5baa55d7d6912', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0', 1, 1537889751, 'Firefox', 'Windows'),
(71, '5bac244e659d1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538008142, 'Chrome', 'Windows'),
(72, '5bb1734b8dffa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538356043, 'Chrome', 'Windows'),
(73, '5bb433d544aad', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538536405, 'Chrome', 'Windows'),
(74, '5c2037ee33982', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 1, 1545615342, 'Chrome', 'Windows'),
(75, '5ca93b363c1d5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1, 1554594614, 'Chrome', 'Windows'),
(76, '5cb881f5a13b5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555595765, 'Chrome', 'Windows'),
(77, '5cb8a07a1a58a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555603578, 'Chrome', 'Windows'),
(78, '5cb8a3345894c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604276, 'Chrome', 'Windows'),
(79, '5cb8a46ceb412', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604588, 'Chrome', 'Windows'),
(80, '5cb8a4db8e4e6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604699, 'Chrome', 'Windows'),
(81, '5cb8a81ce9027', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555605532, 'Chrome', 'Windows'),
(82, '5cb8ad0e4d571', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606798, 'Chrome', 'Windows'),
(83, '5cb8ad3a61129', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606842, 'Chrome', 'Windows'),
(84, '5cb9245bd697b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555637339, 'Chrome', 'Windows'),
(85, '5cb94239a8a3c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555644985, 'Chrome', 'Windows'),
(86, '5cb9431be7c4e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555645211, 'Chrome', 'Windows'),
(87, '5cb943c69bec8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555645382, 'Chrome', 'Windows'),
(88, '5cb9f703675a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555691267, 'Chrome', 'Windows'),
(89, '5cba88e7ab1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555728615, 'Chrome', 'Windows'),
(90, '5cbb34767942f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555772534, 'Chrome', 'Windows'),
(91, '5cc11ae1685bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556159201, 'Chrome', 'Windows'),
(92, '5cc2b15586208', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556263253, 'Chrome', 'Windows'),
(93, '5cc3f0f405d84', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556345076, 'Chrome', 'Windows'),
(94, '5cc84741d0fbb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556629313, 'Chrome', 'Windows'),
(95, '5d4974633a124', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', 1, 1565095011, 'Chrome', 'Windows'),
(96, '5d4e27b421051', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565403060, 'Chrome', 'Windows'),
(97, '5d50b845dd0c4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565571141, 'Chrome', 'Windows'),
(98, '5d538429662db', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754409, 'Chrome', 'Windows'),
(99, '5d53854e94bdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754702, 'Chrome', 'Windows'),
(100, '5d5388a9aed8b', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565755561, 'Chrome', 'Windows'),
(101, '5d53abcf46651', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565764559, 'Chrome', 'Windows'),
(102, '5d779315820f5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568117525, 'Chrome', 'Windows'),
(103, '5d78a4f3c95dd', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568187635, 'Chrome', 'Windows'),
(104, '5d95b078d3259', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570091128, 'Chrome', 'Windows'),
(105, '5d96268fc2554', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570121359, 'Chrome', 'Windows'),
(106, '5d96269ed67ee', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', NULL, 1570121374, 'Chrome', 'Windows'),
(107, '5d96f34b0fc1e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570173771, 'Chrome', 'Windows'),
(108, '5d989cad3a601', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570282669, 'Chrome', 'Windows'),
(109, '5da82e7283d94', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571303026, 'Chrome', 'Windows'),
(110, '5da97c8d06f4e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571388557, 'Chrome', 'Windows'),
(111, '5dafaddb87cd8', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571794395, 'Chrome', 'Windows'),
(112, '5dbe1b954efdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1572739989, 'Chrome', 'Windows'),
(113, '5e4debc821c02', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582164936, 'Chrome', 'Windows'),
(114, '5e549263d8fb4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582600803, 'Chrome', 'Windows'),
(115, '5e5dad753e106', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583197557, 'Chrome', 'Windows'),
(116, '5e5f53a1b905f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583305633, 'Chrome', 'Windows'),
(117, '5e60722a6bedf', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583378986, 'Chrome', 'Windows'),
(118, '5e6116f3a4287', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583421171, 'Chrome', 'Windows'),
(119, '5e61f1a59e18a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583477157, 'Chrome', 'Windows'),
(120, '5e6607738f7eb', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583744883, 'Chrome', 'Windows'),
(121, '5e6659e348e5d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583765987, 'Chrome', 'Windows'),
(122, '5e674a99468e5', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583827609, 'Chrome', 'Windows'),
(123, '5e686bcb64f52', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583901643, 'Chrome', 'Windows'),
(124, '5e698721e44b9', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583974177, 'Chrome', 'Windows'),
(125, '5e69a03b878af', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583980603, 'Chrome', 'Windows'),
(126, '5e6ad745790df', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584060229, 'Chrome', 'Windows'),
(127, '5e6afa6675f2c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584069222, 'Chrome', 'Windows'),
(128, '5e6ecce078976', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584319712, 'Chrome', 'Windows'),
(129, '5e71c528c782c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584514344, 'Chrome', 'Windows'),
(130, '5e71c56635718', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584514406, 'Chrome', 'Windows'),
(131, '5e71c820cbd73', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584515104, 'Chrome', 'Windows'),
(132, '5e71d255f30c1', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584517717, 'Chrome', 'Windows'),
(133, '5e72c6a32ed18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584580259, 'Chrome', 'Windows'),
(134, '5e742c60879d0', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584671840, 'Chrome', 'Windows'),
(135, '5e78118d82a5c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584927117, 'Chrome', 'Windows'),
(136, '5e78667e3345d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584948862, 'Chrome', 'Windows'),
(137, '5e795d15dc80c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585011989, 'Chrome', 'Windows'),
(138, '5e7d6b5f90456', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585277791, 'Chrome', 'Windows'),
(139, '5e81a6f53943d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585555189, 'Chrome', 'Windows'),
(140, '5e829a6cdb25e', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585617516, 'Chrome', 'Windows'),
(141, '5e8448e4e9c92', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585727716, 'Chrome', 'Windows'),
(142, '5e848206686ae', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585742342, 'Chrome', 'Windows'),
(143, '5e86b5b0e7d81', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585886640, 'Chrome', 'Windows'),
(144, '5e86f3cc5e02c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585902540, 'Chrome', 'Windows'),
(145, '5e87060000c41', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585907200, 'Chrome', 'Windows'),
(146, '5e88323f677a6', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585984063, 'Chrome', 'Windows'),
(147, '5e8836c203a18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585985218, 'Chrome', 'Windows'),
(148, '5e884af3b7e61', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585990387, 'Chrome', 'Windows'),
(149, '5e88600ddd2db', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1585995789, 'Chrome', 'Windows'),
(150, '5e892beb48615', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586047979, 'Chrome', 'Windows'),
(151, '5e8932ae84461', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049710, 'Chrome', 'Windows'),
(152, '5e89331dd420c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049821, 'Chrome', 'Windows'),
(153, '5e8939720c509', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586051442, 'Chrome', 'Windows'),
(154, '5e89c3f053845', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586086896, 'Chrome', 'Windows'),
(155, '5e8d3f40373d6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586315072, 'Chrome', 'Windows'),
(156, '5e8d3f6a1189d', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586315114, 'Chrome', 'Windows'),
(157, '5e9080ca1b2ca', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586528458, 'Chrome', 'Windows'),
(158, '5e9256944d3d3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586648724, 'Chrome', 'Windows'),
(159, '5e957a1cdb486', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586854428, 'Chrome', 'Windows'),
(160, '5e97bffb6e420', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1587003387, 'Chrome', 'Windows'),
(161, '5eba4bcdba14c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36', 1, 1589267405, 'Chrome', 'Windows'),
(162, '5edd850fb15a0', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591575823, 'Chrome', 'Windows'),
(163, '5edd868884ab7', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591576200, 'Chrome', 'Windows'),
(164, '5edda481d9e66', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591583873, 'Chrome', 'Windows'),
(165, '5edee38066441', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591665536, 'Chrome', 'Windows'),
(166, '5edee3c6c76b1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665606, 'Chrome', 'Windows'),
(167, '5edee506e4fec', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665926, 'Chrome', 'Windows'),
(168, '5ef4c54e40700', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593099598, 'Chrome', 'Windows'),
(169, '5ef550a2613b5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593135266, 'Chrome', 'Windows'),
(170, '5f067152e1d34', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1594257746, 'Chrome', 'Windows'),
(171, '5f06719fc5bb6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', NULL, 1594257823, 'Chrome', 'Windows'),
(172, '5fa257308e037', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604474672, 'Chrome', 'Windows'),
(173, '5fa4b80680060', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604630534, 'Chrome', 'Windows'),
(174, '60372d29b9962', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', 1, 1614228777, 'Chrome', 'Windows'),
(175, '60372d6f5b7d8', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', NULL, 1614228847, 'Chrome', 'Windows'),
(176, '6046e9137ab3f', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615259923, 'Chrome', 'Windows'),
(177, '604819f5303f1', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615337973, 'Chrome', 'Windows'),
(178, '6049d8e5dd6b4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615452389, 'Chrome', 'Windows'),
(179, '6049dbfee39a9', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', NULL, 1615453182, 'Chrome', 'Windows'),
(180, '604ac159e6b22', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615511897, 'Chrome', 'Windows'),
(181, '60b9e1083005c', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622794504, 'Chrome', 'Windows'),
(182, '60bae34d258f6', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622860621, 'Chrome', 'Windows'),
(183, '60bae52d0535a', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622861101, 'Chrome', 'Windows'),
(184, '60bd8da9800d5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1623035305, 'Chrome', 'Windows'),
(185, '60eba51ba1bb3', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 1, 1626055963, 'Chrome', 'Windows'),
(186, '60eba6ba36295', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056378, 'Chrome', 'Windows'),
(187, '60eba751bbf8b', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056529, 'Chrome', 'Windows'),
(188, '60eba7aa864ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056618, 'Chrome', 'Windows'),
(189, '60eba8330509e', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056755, 'Chrome', 'Windows'),
(190, '60eba8ccdb5ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056908, 'Chrome', 'Windows'),
(191, '6194ce72de6c5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637142130, 'Chrome', 'Windows'),
(192, '619746aa90c09', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637303978, 'Chrome', 'Windows'),
(193, '619751d50efb4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637306837, 'Chrome', 'Windows'),
(194, '619ae916a5efa', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637542166, 'Chrome', 'Windows'),
(195, '619d151c20277', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637684508, 'Chrome', 'Windows'),
(196, '619e714974085', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637773641, 'Chrome', 'Windows'),
(197, '619f3511248ca', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637823761, 'Chrome', 'Windows'),
(198, '61a03438d06ce', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637889080, 'Chrome', 'Windows'),
(199, '61e8db9c551ae', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 1, 1642650524, 'Chrome', 'Windows'),
(200, '62067ec846026', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36', 1, 1644592840, 'Chrome', 'Windows'),
(201, '6320160e8ed28', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663047182, 'Chrome', 'Windows'),
(202, '6326dc416dd21', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663491137, 'Chrome', 'Windows'),
(203, '632eb85c535fa', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664006236, 'Chrome', 'Windows'),
(204, '632fe04cd5313', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664081996, 'Chrome', 'Windows'),
(205, '63331bf466694', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', NULL, 1664293876, 'Chrome', 'Windows'),
(206, '63331cd3edcd6', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', NULL, 1664294099, 'Chrome', 'Windows'),
(207, '63342574185ac', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664361844, 'Chrome', 'Windows'),
(208, '63382ff1e92e5', '14.191.61.205', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664626673, 'Chrome', 'Windows'),
(209, '633cefca2fdcc', '123.23.13.149', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664937930, 'Chrome', 'Windows'),
(210, '633fd7b3d7141', '118.68.56.13', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1665128371, 'Chrome', 'Windows'),
(211, '635b6b16f0db1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1666935574, 'Chrome', 'Windows'),
(212, '63a06823b2435', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1671456803, 'Chrome', 'Windows'),
(213, '63ee404a622f1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676558410, 'Chrome', 'Windows'),
(214, '63ef01ab72671', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676607915, 'Chrome', 'Windows'),
(215, '63f1c3c13350a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676788673, 'Chrome', 'Windows'),
(216, '63fdf6a9c8ce8', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677588137, 'Chrome', 'Windows'),
(217, '63fe0639a9d95', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677592121, 'Chrome', 'Windows'),
(218, '63fe0fc3cb2e3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677594563, 'Chrome', 'Windows'),
(219, '63fe8683cb897', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677624963, 'Chrome', 'Windows'),
(220, '64002a2aa8f01', '2001:ee0:56e8:8', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677732394, 'Chrome', 'Windows'),
(221, '64003618c41db', '2001:ee0:56e8:8', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677735448, 'Chrome', 'Windows'),
(222, '64003f4ad1878', '171.247.108.233', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57', 1, 1677737802, 'Chrome', 'Windows'),
(223, '64101d5c9879f', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.69', 1, 1678777692, 'Chrome', 'Windows'),
(224, '6412b1078c242', '1.52.109.14', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1678946567, 'Chrome', 'Windows'),
(225, '6413d22105926', '42.115.229.57', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1679020577, 'Chrome', 'Windows'),
(226, '642fbff3254ee', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62', 1, 1680850931, 'Chrome', 'Windows'),
(227, '642fc1e3791b1', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62', 1, 1680851427, 'Chrome', 'Windows'),
(228, '642fd39ece936', '113.188.229.40', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1680855966, 'Chrome', 'Windows'),
(229, '64322f2ef2155', '27.3.193.217', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1681010478, 'Chrome', 'Windows'),
(230, '64521421f2784', '113.183.205.19', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36', 1, 1683100705, 'Chrome', 'Windows'),
(231, '6489b99276bfe', '222.254.222.131', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1686747538, 'Chrome', 'Windows'),
(232, '648fbe8196ce8', '2402:800:63e5:b', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1687142017, 'Chrome', 'Windows'),
(233, '64b644ea0dc65', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689666794, 'Chrome', 'Windows'),
(234, '64b64661f3649', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689667169, 'Chrome', 'Windows'),
(235, '64b8a6eee72b4', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689822958, 'Chrome', 'Windows'),
(236, '64b8a87199516', '113.177.113.64', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.82', 1, 1689823345, 'Chrome', 'Windows'),
(237, '64bb4adf327cf', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.82', 1, 1689995999, 'Chrome', 'Windows'),
(238, '64bb51934194d', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689997715, 'Chrome', 'Windows'),
(239, '64c8ad0b4788c', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1690873099, 'Chrome', 'Windows'),
(240, '64cb67a9bddf2', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691051945, 'Chrome', 'Windows'),
(241, '64cb69950703a', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1691052437, 'Chrome', 'Windows'),
(242, '64d091b6611ec', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1691390390, 'Chrome', 'Windows'),
(243, '64d4fcb32ead7', '223.27.111.153', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.200', 1, 1691679923, 'Chrome', 'Windows'),
(244, '64d9d76a8d941', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.200', 1, 1691998058, 'Chrome', 'Windows'),
(245, '64deeb60a2bb6', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 1, 1692330848, 'Chrome', 'Windows'),
(246, '64e6c2cdeb4a9', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.203', 1, 1692844749, 'Chrome', 'Windows'),
(247, '64eb1941d6052', '223.27.111.153', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.54', 1, 1693129025, 'Chrome', 'Windows'),
(248, '64ec5153ad1e1', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62', 1, 1693208915, 'Chrome', 'Windows'),
(249, '64f83ca087454', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.69', 1, 1693990048, 'Chrome', 'Windows'),
(250, '655c5cde66819', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700551902, 'Chrome', 'Windows'),
(251, '655c6b108dc70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700555536, 'Chrome', 'Windows'),
(252, '655c6b689f7b8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700555624, 'Chrome', 'Windows'),
(253, '659bac63dde29', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704701027, 'Chrome', 'Windows'),
(254, '65a77eb9e64ea', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1705475769, 'Chrome', 'Windows'),
(255, '65b11d8dd7270', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1706106253, 'Chrome', 'Windows'),
(256, '65b9f23eb3fa9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1706684990, 'Chrome', 'Windows');
INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(257, '65be159aef6cb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1706956187, 'Chrome', 'Windows'),
(258, '65d45cf8bead5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708416248, 'Chrome', 'Windows'),
(259, '65d45d13e9cbe', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708416275, 'Chrome', 'Windows'),
(260, '65d57006d5478', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708486662, 'Chrome', 'Windows'),
(261, '65d5b60e91649', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708504590, 'Chrome', 'Windows'),
(262, '65d6a615e9dc8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708566037, 'Chrome', 'Windows'),
(263, '65d9aa7a93d94', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708763770, 'Chrome', 'Windows'),
(264, '65dbf57e9eca6', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1708914046, 'Chrome', 'Windows'),
(265, '65dda8f9912c7', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 1, 1709025529, 'Chrome', 'Windows'),
(266, '65de9db21a6ca', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709088178, 'Chrome', 'Windows'),
(267, '65de9eab478b4', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709088427, 'Chrome', 'Windows'),
(268, '65deac90a6d56', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709091984, 'Chrome', 'Windows'),
(269, '65ded9876c475', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709103495, 'Chrome', 'Windows'),
(270, '65e182c15a7b4', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709277889, 'Chrome', 'Windows'),
(271, '65e521a9173fb', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709515177, 'Chrome', 'Windows'),
(272, '65e56fb5c2da9', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709535157, 'Chrome', 'Windows'),
(273, '65e57d4d4a1a3', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709538637, 'Chrome', 'Windows'),
(274, '65e5d8ecd7202', '123.22.62.139', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709562092, 'Chrome', 'Windows'),
(275, '65e66d5b328c0', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709600091, 'Chrome', 'Windows'),
(276, '65e6770a88162', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709602570, 'Chrome', 'Windows'),
(277, '65e6be94a3d75', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709620884, 'Chrome', 'Windows'),
(278, '65e73309cb9f2', '27.71.98.117', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709650697, 'Chrome', 'Windows'),
(279, '65e751ba9b453', '123.22.62.139', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709658554, 'Chrome', 'Windows'),
(280, '65e7c3b881555', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709687736, 'Chrome', 'Windows'),
(281, '65e7de6cd70cb', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709694572, 'Chrome', 'Windows'),
(282, '65e7de6d8312f', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 1, 1709694573, 'Chrome', 'Windows'),
(283, '65e7e3997b490', '27.71.98.83', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709695897, 'Chrome', 'Windows'),
(284, '65e811761cd47', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709707638, 'Chrome', 'Windows'),
(285, '65e833e6b324c', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709716454, 'Chrome', 'Windows'),
(286, '65e910270f923', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709772839, 'Chrome', 'Windows'),
(287, '65e960efd21ff', '27.71.98.83', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709793519, 'Chrome', 'Windows'),
(288, '65e9d39abab6f', '27.71.98.117', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709822874, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `view_contact`
--

DROP TABLE IF EXISTS `view_contact`;
CREATE TABLE IF NOT EXISTS `view_contact` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `subject` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `message` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `services` tinyint DEFAULT NULL,
  `viewed` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `view_contact`
--

INSERT INTO `view_contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `services`, `viewed`, `date_created`) VALUES
(18, 'fasdfas', 'fasdf@gmail.com', '4444', '', 'fasdf', NULL, 0, '2024-02-24 16:19:08');

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

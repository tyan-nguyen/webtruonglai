-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 13, 2024 at 06:54 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fulladmin_nt`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', 1, 1556454369),
('bientapvien', 1, 1570155479),
('Default', 1, 1556454369),
('thongketruycap', 1, 1687142184);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/admin/*', 3, NULL, NULL, NULL, 1555604426, 1555604426, NULL),
('/admin/catelogies/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/default/*', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/default/index', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/links/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/del-folder-not-used', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/thong-ke-truy-cap/*', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/bulk-delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/create', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/index', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/update', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/view', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/page/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/about-us', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/captcha', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/contact', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/*', 3, NULL, NULL, NULL, 1555604424, 1555604424, NULL),
('/site/cat', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/index', 3, NULL, NULL, NULL, 1555604425, 1555604425, NULL),
('/site/news', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/newsletter', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/not-found', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/search', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1426062189, 1426062189, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('bientapvien', 1, 'Biên tập viên', NULL, NULL, 1570120917, 1570120917, NULL),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('cauhinh', 2, 'Cấu hình', NULL, NULL, 1570156160, 1570156160, 'userCommonPermissions'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1426062189, 1426062189, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1426062188, 1426062188, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('dangtin', 2, 'Đăng tin', NULL, NULL, 1570156034, 1570156034, 'userCommonPermissions'),
('Default', 1, 'Default', NULL, NULL, 1555604497, 1555604497, NULL),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('duyettin', 1, 'Duyệt tin', NULL, NULL, 1570120962, 1570120962, NULL),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('per_dashboard', 2, 'Access Dashboard', NULL, NULL, 1664291118, 1664291118, 'userManagement'),
('permission_thongketruycap', 2, 'Thống kê truy cập', NULL, NULL, 1586086798, 1586086798, 'userCommonPermissions'),
('qltaikhoan', 2, 'Quản lý tài khoản', NULL, NULL, 1570156229, 1570156229, 'userManagement'),
('thongketruycap', 1, 'Thống kê truy cập', NULL, NULL, 1586086766, 1586086766, NULL),
('truycaptrangadmin', 2, 'Truy cập trang admin', NULL, NULL, 1570121444, 1570121444, 'userCommonPermissions'),
('user-default', 2, 'user-default', NULL, NULL, 1555604419, 1555604419, 'userCommonPermissions'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1426062189, 1426062189, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('per_dashboard', '/admin/*'),
('per_dashboard', '/admin/catelogies/*'),
('per_dashboard', '/admin/default/*'),
('truycaptrangadmin', '/admin/default/*'),
('user-default', '/admin/default/*'),
('user-default', '/admin/default/index'),
('per_dashboard', '/admin/links/*'),
('per_dashboard', '/admin/news/*'),
('per_dashboard', '/admin/settings/*'),
('per_dashboard', '/admin/socials/*'),
('per_dashboard', '/admin/thong-ke-truy-cap/*'),
('permission_thongketruycap', '/admin/thong-ke-truy-cap/*'),
('user-default', '/site/*'),
('qltaikhoan', '/user-management/*'),
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('viewVisitLog', '/user-management/user-visit-log/grid-page-size'),
('viewVisitLog', '/user-management/user-visit-log/index'),
('viewVisitLog', '/user-management/user-visit-log/view'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'cauhinh'),
('Admin', 'changeOwnPassword'),
('bientapvien', 'changeOwnPassword'),
('duyettin', 'changeOwnPassword'),
('user-default', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'dangtin'),
('bientapvien', 'dangtin'),
('duyettin', 'dangtin'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('bientapvien', 'per_dashboard'),
('thongketruycap', 'permission_thongketruycap'),
('Admin', 'qltaikhoan'),
('Default', 'thongketruycap'),
('Admin', 'truycaptrangadmin'),
('bientapvien', 'truycaptrangadmin'),
('Default', 'truycaptrangadmin'),
('duyettin', 'truycaptrangadmin'),
('Admin', 'user-default'),
('bientapvien', 'user-default'),
('Default', 'user-default'),
('duyettin', 'user-default'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1426062189, 1426062189),
('userManagement', 'User management', 1426062189, 1426062189);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE IF NOT EXISTS `blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link_en` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `open_new_tab` tinyint(1) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `priority` tinyint(1) NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name`, `name_en`, `link`, `link_en`, `open_new_tab`, `pid`, `priority`, `type`, `lang`) VALUES
(1, 'Trang chủ', '', '/', '', 0, 0, 1, 'MENU_TOP', 'vi'),
(2, 'Thông tin chung ', '', '#', '', 0, 0, 2, 'MENU_TOP', 'vi'),
(3, 'Lĩnh vực hoạt động', '', '#', '', 0, 0, 3, 'MENU_TOP', 'vi'),
(5, 'Tin tức', '', '#', '', 0, 0, 3, 'MENU_TOP', 'vi'),
(6, 'Tuyển dụng', '', '/', '', 0, 0, 1, 'QUICK_LINK', 'vi'),
(7, 'Liên hệ', '', '/', '', 0, 0, 2, 'QUICK_LINK', 'vi'),
(8, 'Hồ sơ năng lực', '', '/', '', 0, 0, 3, 'QUICK_LINK', 'vi'),
(12, '<i class=\"fab fa-facebook-f\"></i>', '', '#', '', 1, 0, 1, 'SOCIAL_LINK', 'vi'),
(13, '<i class=\"fab fa-twitter\"></i>', '', '#', '', 1, 0, 1, 'SOCIAL_LINK', 'vi'),
(14, '<i   class=\"fab fa-instagram\"></i>', '', '#', '', 1, 0, 3, 'SOCIAL_LINK', 'vi'),
(15, '<i class=\"fab fa-github\"></i>', '', '#', '', 1, 0, 4, 'SOCIAL_LINK', 'vi'),
(19, 'Tuyển dụng', '', '/post/tuyen-dung', '', 0, 0, 5, 'MENU_TOP', 'vi'),
(20, 'Liên hệ', '', '/contact', '', 0, 0, 6, 'MENU_TOP', 'vi'),
(21, 'Về chúng tôi', '', '#', '', 0, 2, 1, 'MENU_TOP', 'vi'),
(23, 'Hồ sơ năng lực', '', '#', '', 0, 2, 2, 'MENU_TOP', 'vi'),
(24, 'Thành viên của chúng tôi', '', '#', '', 0, 2, 3, 'MENU_TOP', 'vi'),
(25, 'Thi công công trình', '', '#', '', 0, 3, 1, 'MENU_TOP', 'vi'),
(26, 'Cấu kiện bê tông đúc sẵn', '', '#', '', 0, 3, 2, 'MENU_TOP', 'vi'),
(27, 'Vật liệu xây dựng - Trang trí nội thất', '', '#', '', 0, 3, 3, 'MENU_TOP', 'vi'),
(28, 'Gạch không nung', '', '#', '', 0, 3, 4, 'MENU_TOP', 'vi'),
(29, 'Cửa nhôm', '', '#', '', 0, 3, 5, 'MENU_TOP', 'vi'),
(30, 'Đào tạo và sát hạch lái xe', '', '#', '', 0, 3, 6, 'MENU_TOP', 'vi'),
(31, 'Hoạt động doanh nghiệp', '', '/posts/hoat-dong-doanh-nghiep', '', 0, 5, 1, 'MENU_TOP', 'vi'),
(32, 'Công bố thông tin', '', '/posts/cong-bo-thong-tin', '', 0, 5, 2, 'MENU_TOP', 'vi'),
(33, 'Thi công xây dựng hạ tầng', '', '#', '', 0, 25, 1, 'MENU_TOP', 'vi'),
(34, 'Cầu đường', '', '#', '', 0, 25, 2, 'MENU_TOP', 'vi'),
(35, 'Thảm nhựa', '', '#', '', 0, 25, 3, 'MENU_TOP', 'vi'),
(36, 'Thi công ép cọc', '', '#', '', 0, 25, 4, 'MENU_TOP', 'vi'),
(37, 'Cọc LTUL thường', '', '#', '', 0, 26, 1, 'MENU_TOP', 'vi'),
(38, 'Cọc LTUL CĐ cao', '', '#', '', 0, 26, 2, 'MENU_TOP', 'vi'),
(39, 'Cống tròn BTCT', '', '#', '', 0, 26, 3, 'MENU_TOP', 'vi'),
(40, 'Cống họp BTCT', '', '#', '', 0, 26, 4, 'MENU_TOP', 'vi'),
(41, 'Cống BTLT dự ứng lực', '', '#', '', 0, 26, 5, 'MENU_TOP', 'vi'),
(42, 'Gạch men & Granite', '', '#', '', 0, 27, 1, 'MENU_TOP', 'vi'),
(43, 'Gạch bông', '', '#', '', 0, 27, 2, 'MENU_TOP', 'vi'),
(44, 'Thiết bị vệ sinh', '', '#', '', 0, 27, 3, 'MENU_TOP', 'vi'),
(45, 'Gạch kính', '', '#', '', 0, 27, 4, 'MENU_TOP', 'vi'),
(46, 'Về chúng tôi', '', '#', '', 0, 0, 1, 'FOOTER_LINK', 'vi'),
(47, 'Blogs', '', '#', '', 0, 0, 2, 'FOOTER_LINK', 'vi'),
(49, 'Chính sách', '', '#', '', 0, 0, 3, 'FOOTER_LINK', 'vi');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1480859869),
('m140209_132017_init', 1480859873),
('m140403_174025_create_account_table', 1480859874),
('m140504_113157_update_tables', 1480859876),
('m140504_130429_create_token_table', 1480859876),
('m140506_102106_rbac_init', 1480867652),
('m140830_171933_fix_ip_field', 1480859877),
('m140830_172703_change_account_table_name', 1480859877),
('m141222_110026_update_ip_field', 1480859877),
('m141222_135246_alter_username_length', 1480859877),
('m150425_012013_init', 1570158165),
('m150425_082737_redirects', 1570158165),
('m150614_103145_update_social_account_table', 1480859878),
('m150623_212711_fix_username_notnull', 1480859878),
('m151218_234654_add_timezone_to_profile', 1480859878);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `site`, `date_created`) VALUES
(16, 'thaipn@bachthuanan.com', 'localhost', '2023-09-19 14:09:04'),
(17, 'bouongsting@gmail.com', 'localhost', '2023-09-27 15:09:24');

-- --------------------------------------------------------

--
-- Table structure for table `news_catelogies`
--

DROP TABLE IF EXISTS `news_catelogies`;
CREATE TABLE IF NOT EXISTS `news_catelogies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cover` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news_catelogies`
--

INSERT INTO `news_catelogies` (`id`, `cover`, `name`, `slug`, `pid`, `priority`, `level`, `description`, `content`, `seo_title`, `seo_description`, `seo_image`, `lang`, `code`, `status`, `post_type`, `date_created`, `user_created`) VALUES
(1, NULL, 'Hoạt động doanh nghiệp', 'hoat-dong-doanh-nghiep', 0, 1, 1, '', NULL, '', '', NULL, 'vi', '44dnvz', 'PUBLISH', 'POST', '2024-02-24 09:42:32', 1),
(2, 'http://localhost:9999/images/posts/_categories/88chbn/banner3.jpg', 'Công bố thông tin', 'cong-bo-thong-tin', 0, 2, 1, '', '<p><img src=\"/images/posts/_categories/88chbn/bg_fact.png\" alt=\"bg_fact\" /></p>', '', '', '', 'vi', '88chbn', 'PUBLISH', 'POST', '2024-03-04 09:17:54', 1),
(5, NULL, 'Video', 'video', 0, 1, 1, '', NULL, '', '', NULL, 'vi', '21ntqm', 'PUBLISH', 'POST', '2024-03-07 14:29:15', 1),
(6, NULL, 'Cửa nhôm', 'cua-nhom', 0, 1, 1, '', NULL, '', '', NULL, 'vi', '79muwo', 'PUBLISH', 'PROJECT', '2024-03-07 15:41:57', 1),
(7, NULL, 'Vật liệu xây dựng - Trang trí nội thất', 'vat-lieu-xay-dung-trang-tri-noi-that', 0, 2, 1, '', NULL, '', '', NULL, 'vi', '54awyn', 'PUBLISH', 'PROJECT', '2024-03-07 15:42:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `input_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `group_type`, `name`, `value`, `input_type`) VALUES
(1, 'SETTING', 'site_name', 'DNTN SX-TM Nguyễn Trình', 'text'),
(2, 'SETTING', 'site_logo', '/ntweb/images/logo.png', 'image'),
(3, 'SETTING', 'site_logo_white', '/ntweb/images/footer-logo.png', 'image'),
(4, 'SETTING', 'site_copyright', 'Copyright © 2024 DNTN Sản xuất - Thương mại Nguyễn Trình. All rights reserved.', 'text'),
(5, 'SETTING', 'site_copyright', '<span>Copyright &copy; <script>\r\n              document.write(new Date().getFullYear()) \r\n            </script> </span> DNTN Sản xuất - Thương mại Nguyễn Trình. All rights reserved.', 'text'),
(6, 'SETTING', 'site_description', 'DNTN Sản xuất - Thương mại Nguyễn Trình', 'text'),
(7, 'SETTING', 'site_hotline', '0903336470', 'text'),
(8, 'SETTING', 'site_email', 'nguyentrinh@gmail.com', 'text'),
(9, 'SETTING', 'site_mst', '2100236683', 'text'),
(10, 'SETTING', 'site_address', 'Đường Nguyễn Đáng, Khóm 10, Phường 9, TP. Trà Vinh', 'text'),
(11, 'SETTING', 'site_hotline_text', '090.336.470', 'text'),
(12, 'SETTING', 'site_seo_title', 'Doanh nghiệp tư nhân Sản xuất - Thương mại Nguyễn Trình', 'text'),
(13, 'SETTING', 'site_seo_description', 'Website chính thức của DNTN SX-TM Nguyễn Trình', 'text');

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_by_day`
--

DROP TABLE IF EXISTS `pcounter_by_day`;
CREATE TABLE IF NOT EXISTS `pcounter_by_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_by_day`
--

INSERT INTO `pcounter_by_day` (`id`, `day`, `user`) VALUES
(125, '2024-03-03', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_save`
--

DROP TABLE IF EXISTS `pcounter_save`;
CREATE TABLE IF NOT EXISTS `pcounter_save` (
  `save_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `save_value` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`save_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_save`
--

INSERT INTO `pcounter_save` (`save_name`, `save_value`) VALUES
('counter', 2),
('day_time', 2460374),
('max_count', 1),
('max_time', 1),
('yesterday', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_users`
--

DROP TABLE IF EXISTS `pcounter_users`;
CREATE TABLE IF NOT EXISTS `pcounter_users` (
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_time` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_users`
--

INSERT INTO `pcounter_users` (`user_ip`, `user_time`) VALUES
('837ec5754f503cfaaee0929fd48974e7', 1709519472);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cover` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` text COLLATE utf8_unicode_ci,
  `summary` text COLLATE utf8_unicode_ci,
  `summary_one` text COLLATE utf8_unicode_ci,
  `summary_two` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `content_one` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1990 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `summary_one`, `summary_two`, `content`, `content_one`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1941, '99eqxm', NULL, NULL, 'New Post Title here...', 'new-post-title-here-19', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:16:13', '2024-01-25 09:16:13', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1942, '31rliy', NULL, NULL, 'New Post Title here...', 'new-post-title-here-20', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:17:25', '2024-01-25 09:17:25', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1943, '34izeq', NULL, NULL, 'New Post Title here...', 'new-post-title-here-21', NULL, NULL, NULL, NULL, NULL, '2024-01-25 09:17:32', '2024-01-25 09:17:32', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'PRODUCT'),
(1944, '52pnbu', '', NULL, 'New Post Title here...', 'new-post-title-here-22', '', NULL, NULL, '', NULL, '2024-01-25 09:23:32', '2024-01-31 16:29:24', 1, '', '', '', 'DRAFT', '', 'vi', 'PRODUCT'),
(1946, '92tlyc', NULL, 'yiytiyuiy', 'New Post Title here...', 'new-post-title-here-23', '', NULL, NULL, '', NULL, '2024-01-25 11:00:48', '2024-01-25 11:00:48', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1949, '98xhbg', NULL, NULL, 'New Post Title here...', 'new-post-title-here-25', NULL, NULL, NULL, NULL, NULL, '2024-01-31 14:10:33', '2024-01-31 14:10:33', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'DOCUMENT'),
(1950, '60ioqz', NULL, NULL, 'New Post Title here...', 'new-post-title-here-26', NULL, NULL, NULL, NULL, NULL, '2024-01-31 14:10:40', '2024-01-31 14:10:40', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'en', 'DOCUMENT'),
(1965, '88wzpe', '', 'hoat-dong-doanh-nghiep', 'Biệt thự với bể bơi \'treo\' lơ lửng ở mặt tiền', 'new-post-title-here', 'Công trình được tạo ra bởi các hình khối xếp so le theo trật tự và bố cục chặt chẽ, tạo khoảng vượt nhịp lớn, bể bơi nằm lơ lửng ở tầng hai.', NULL, NULL, '<p>Căn biệt thự c&oacute; quy m&ocirc; 3 tầng nổi v&agrave; một tầng b&aacute;n hầm, được x&acirc;y dựng tr&ecirc;n khu đất rộng 805 m2 tr&ecirc;n đảo Tuần Ch&acirc;u (Quảng Ninh). Với diện t&iacute;ch s&agrave;n x&acirc;y dựng 1.170 m2, c&ocirc;ng tr&igrave;nh được thiết kế với kiến tr&uacute;c hiện đại, tất cả c&aacute;c kh&ocirc;ng gian đều th&ocirc;ng tho&aacute;ng, tận dụng được hướng gi&oacute; m&aacute;t v&agrave; hướng tầm nh&igrave;n ra Vịnh Hạ Long.</p>\r\n<p>C&aacute;c kh&ocirc;ng gian chức năng như ph&ograve;ng kh&aacute;ch, ph&ograve;ng ngủ, bếp - ăn&hellip; được sắp xếp linh hoạt theo từng khối kiến tr&uacute;c. C&aacute;c khối nh&agrave; nằm so le, chồng l&ecirc;n nhau theo trật tự v&agrave; bố cục chặt chẽ, tạo khoảng đua v&agrave; vượt nhịp lớn. Thiết kế n&agrave;y gi&uacute;p tạo n&ecirc;n những khoảng hở đối lưu gi&oacute;, mang lại cảm gi&aacute;c tho&aacute;ng đ&atilde;ng v&agrave; tối ưu diện t&iacute;ch sử dụng.</p>\r\n<p><img src=\"/images/posts/88wzpe/429305838-368808942662814-4068321854074727112-n-1708735905%5B1%5D.jpg\" alt=\"429305838-368808942662814-4068321854074727112-n-1708735905[1]\" width=\"100%\" height=\"\" /></p>', NULL, '2024-02-24 09:54:26', '2024-02-24 09:57:22', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1966, '59sexz', '', 'hoat-dong-doanh-nghiep', 'Biệt thự với bể bơi \'treo\' lơ lửng ở mặt tiền 22', 'new-post-title-here-2', '', NULL, NULL, '<p>fasfasfd</p>', NULL, '2024-02-24 16:20:48', '2024-03-04 09:36:16', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1967, '56xawi', NULL, NULL, 'Tuyển dụng', 'tuyen-dung', 'Trang tuyển dụng', NULL, NULL, '<p>Trang tuyển dụng</p>', NULL, '2024-02-24 21:47:20', '2024-02-24 21:48:01', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PAGE'),
(1969, '16kqtb', 'http://localhost:9999/images/posts/16kqtb/bg5.jpg', NULL, 'Thi công công trình', 'xxxxxxxxx', 'Đội ngũ kỹ sư giàu kinh nghiệm', 'Với hơn 20 năm kinh nghiệm trong lĩnh vực thi công xây dựng hạ tầng, cầu đường, thảm nhựa', '#fdsaffdsafasfd', '<p>&nbsp;</p>\r\n<div class=\"ddict_btn\" style=\"top: 20px; left: 44.6406px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>', '<p>&nbsp;</p>\r\n<div class=\"ddict_btn\" style=\"top: 29px; left: 51.625px;\"><img src=\"chrome-extension://bpggmmljdiliancllaapiggllnkbjocb/logo/48.png\" /></div>', '2024-02-24 22:17:17', '2024-02-24 22:47:55', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'SLIDE'),
(1970, '90zwex', 'http://localhost:9999/images/posts/90zwex/bg4.jpg', NULL, 'Cấu kiện bê tông đúc sẵn', 'new-post-title-here-3', 'Phục vụ đa dạng cho công trình của bạn', '', 'ffffffffff', NULL, NULL, '2024-02-24 22:53:38', '2024-03-04 09:36:24', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SLIDE'),
(1971, '15mbpl', 'http://localhost:9999/images/posts/15mbpl/contruction.png', NULL, 'THI CÔNG XÂY DỰNG HẠ TẦNG', 'new-post-title-here-4', 'Lĩnh vực thi công xây dựng hạ tầng, lĩnh vực cầu đường, thảm nhựa, thi công ép cọc công trình', NULL, NULL, NULL, NULL, '2024-02-24 23:02:33', '2024-02-24 23:03:26', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1972, '88rnwb', 'http://localhost:9999/images/posts/88rnwb/service-icon1.png', NULL, 'CẤU KIỆN BÊ TÔNG ĐÚC SẴN', 'new-post-title-here-5', 'Sản xuất, kinh doanh cấu kiện bê tông đúc sẵn phục vụ đa dạng cho công trình của Quý khách hàng', NULL, NULL, NULL, NULL, '2024-02-24 23:04:39', '2024-02-24 23:05:36', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1973, '37owea', 'http://localhost:9999/images/posts/37owea/gach-khong-nung-icon.png', NULL, ' GẠCH KHÔNG NUNG', 'new-post-title-here-6', 'Sản xuất và kinh doanh Gạch không nung theo nhu cầu của Quý khách hàng', NULL, NULL, NULL, NULL, '2024-02-24 23:05:09', '2024-02-24 23:05:32', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1974, '18xvmc', 'http://localhost:9999/images/posts/18xvmc/vlxd.png', NULL, 'VẬT LIỆU XÂY DỰNG - TRANG TRÍ NỘI THẤT', 'new-post-title-here-7', 'Kinh doanh: Gạch men và Granite, gạch bông, gạch kính và thiết bị vệ sinh với giá thành cạnh tranh', NULL, NULL, NULL, NULL, '2024-02-24 23:05:40', '2024-02-24 23:06:10', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1975, '55lnty', 'http://localhost:9999/images/posts/55lnty/door.png', NULL, 'CỬA NHÔM', 'new-post-title-here-8', 'Thiết kế, sản xuất và lắp đặt cửa nhôm, cam kết bảo hành 10 năm bảo đảm lợi ích tối đa cho khách hàng', 'https://cua.nguyentrinh.com', NULL, NULL, NULL, '2024-02-24 23:06:11', '2024-02-24 23:15:41', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1976, '97vfaj', 'http://localhost:9999/images/posts/97vfaj/driving.png', NULL, 'ĐÀO TẠO VÀ SÁT HẠCH LÁI XE', 'new-post-title-here-9', 'Trung tâm đào tạo và sát hạch lái xe cơ giới đường bộ loại I chuyên đào tạo và sát hạch nghề lái xe các hạng', 'abc', NULL, NULL, NULL, '2024-02-24 23:06:36', '2024-02-24 23:15:24', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1977, '21ctrw', NULL, NULL, 'New Post Title here...', 'new-post-title-here-10', NULL, NULL, NULL, NULL, NULL, '2024-03-04 09:36:48', '2024-03-04 09:36:48', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'SLIDE'),
(1978, '41mdxs', NULL, NULL, 'New Post Title here...', 'new-post-title-here-11', NULL, NULL, NULL, NULL, NULL, '2024-03-04 09:37:03', '2024-03-04 09:37:03', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'POST'),
(1979, '45sibp', NULL, NULL, 'New Post Title here...', 'new-post-title-here-12', NULL, NULL, NULL, NULL, NULL, '2024-03-04 09:37:10', '2024-03-04 09:37:10', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'SERVICE'),
(1980, '33kbec', NULL, NULL, 'New Post Title here...', 'new-post-title-here-13', NULL, NULL, NULL, NULL, NULL, '2024-03-04 09:42:53', '2024-03-04 09:42:53', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', 'POST'),
(1981, '30jfkp', 'http://localhost:9999/images/posts/30jfkp/contruction.png', NULL, 'New Post Title here...', 'new-post-title-here-14', 'New Post Title here...', '', NULL, NULL, NULL, '2024-03-05 16:49:29', '2024-03-05 16:51:45', 1, NULL, NULL, NULL, 'PUBLISH', NULL, 'vi', 'SERVICE'),
(1982, '29plbw', '', 'video', 'CỬA ĐI MỞ LÙA NHÔM & KÍNH HỘP NAN ĐỒNG TẠI SHOWROOM NGUYỄN TRÌNH', 'cua-di-mo-lua-nhom-kinh-hop-nan-dong-tai-showroom-nguyen-trinh', 'Cửa đi mở lùa nhôm & kính nan đồng tại showroom ', NULL, NULL, '<p><iframe title=\"YouTube video player\" src=\"//www.youtube.com/embed/t6_he9wIOmc?si=y9CeitSH0Jt1WUbh\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>', NULL, '2024-03-07 14:11:11', '2024-03-07 14:31:54', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1983, '43eiyx', '', 'video', 'New Post Title here...', 'new-post-title-here-15', '', NULL, NULL, '', NULL, '2024-03-07 14:36:22', '2024-03-07 14:36:29', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1984, '54nlir', '', 'video', 'New Post Title here...', 'new-post-title-here-16', '', NULL, NULL, '', NULL, '2024-03-07 14:36:31', '2024-03-07 14:36:36', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1985, '50dsey', '', 'video', 'New Post Title here...', 'new-post-title-here-17', '', NULL, NULL, '', NULL, '2024-03-07 14:36:38', '2024-03-07 14:36:43', 1, '', '', '', 'PUBLISH', '', 'vi', 'POST'),
(1986, '56vrym', 'http://localhost:9999/images/posts/56vrym/project3.jpg', 'cua-nhom', 'Dự án 1', 'new-post-title-here-18', 'fsafdadsf', NULL, NULL, '', NULL, '2024-03-07 15:42:32', '2024-03-07 21:59:31', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PROJECT'),
(1987, '69ylxq', 'http://localhost:9999/images/posts/69ylxq/project5.jpg', 'cua-nhom;vat-lieu-xay-dung-trang-tri-noi-that', 'Dự án 2', 'new-post-title-here-24', 'fasdfasf', NULL, NULL, '<p>fdasfd</p>', NULL, '2024-03-07 15:43:16', '2024-03-07 22:00:05', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PROJECT'),
(1988, '82febs', 'http://localhost:9999/images/posts/82febs/project4.jpg', 'vat-lieu-xay-dung-trang-tri-noi-that', 'New Post Title here...', 'new-post-title-here-27', '', NULL, NULL, '', NULL, '2024-03-07 22:00:58', '2024-03-07 22:01:25', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PROJECT'),
(1989, '80eihm', 'http://localhost:9999/images/posts/80eihm/project2.jpg', 'cua-nhom', 'New Post Title here...', 'new-post-title-here-28', '', NULL, NULL, '', NULL, '2024-03-07 22:02:00', '2024-03-07 22:02:29', 1, '', '', '', 'PUBLISH', NULL, 'vi', 'PROJECT');

-- --------------------------------------------------------

--
-- Table structure for table `post_documents`
--

DROP TABLE IF EXISTS `post_documents`;
CREATE TABLE IF NOT EXISTS `post_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` float DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_documents`
--

INSERT INTO `post_documents` (`id`, `pid`, `name`, `url`, `file_name`, `file_extension`, `file_size`, `summary`, `date_created`, `user_created`) VALUES
(2, 4, 'xxxx', '4e00364886ba63c506cb9ea6888ffa8b.pdf', '[Nguyen Trinh] Quasoft Quotation (1).pdf', 'pdf', 586302, '', '2023-07-27 09:46:40', 1),
(3, 4, 'ddd', '49a2cf59b2fafed4a952d97561cb159d.xlsx', '_tinChi.xlsx', 'xlsx', 12009, '', '2023-07-27 13:46:06', 1),
(9, 4, 'test', '1e1848cc61ce6f23004dc03bcdfb7a33.xlsx', 'Book1.xlsx', 'xlsx', 71423, '', '2023-08-08 14:47:02', 1),
(23, 1939, 'z', 'dedc53d5cf13d6317fb41856b398dfdf.png', 'Screenshot 2023-10-12 at 7-48-03 PM.png', 'png', 0, 'z', '2024-01-17 16:44:17', 1),
(24, 1939, 'x', '7e9244d5fd393e63efc654b1c5e850b5.png', 'cua-di-2-canh-lam-sang-thumb.png', 'png', 55643, 'x', '2024-01-17 16:45:10', 1),
(25, 1939, 'xxx sgsdgs gsdfg ', 'e708dd3df9ea7d3aea67a7f8b4b3f720.png', 'Screenshot 2023-11-24 090111.png', 'png', 172554, ' gfdsgsfd sdg s', '2024-01-17 23:13:40', 1),
(26, 1939, 'gfds g gsg ', 'd8ef67bb4bf511833d4f292f20735c74.docx', '09.XN.NPT.TNCN.docx', 'docx', 21745, 'sfdfgd fd g', '2024-01-17 23:36:25', 1),
(27, 1939, '9', '917c3d9d6397f24609199967673b16ff.docx', '20.DK.TCT.docx', 'docx', 20300, '9', '2024-01-18 08:28:21', 1),
(30, 1963, 'hiển thị', '88b901dcde9176d182bb1200e7f1f65e.docx', '09.XN.NPT.TNCN.docx', 'docx', 21745, 'summary', '2024-02-03 17:38:40', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_images`
--

DROP TABLE IF EXISTS `post_images`;
CREATE TABLE IF NOT EXISTS `post_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_images`
--

INSERT INTO `post_images` (`id`, `pid`, `name`, `url`, `img_name`, `img_extension`, `img_size`, `img_wh`, `summary`, `date_created`, `user_created`) VALUES
(60, 4, '', 'ed3157a0407910d797205eb21ff9a536.png', 'fubusta_lines_qr_code_192720766.png', 'png', 318, NULL, '', '2023-07-27 09:46:55', 1),
(65, 4, '', '6c2b00941d0b18faa721d2c510164c68.jpg', 'tuyendung.jpg', 'jpg', 83283, NULL, '', '2023-08-08 14:46:49', 1),
(72, 1939, '8eb63e3c6d38ba66e329.jpg', 'b828a61c01a6ff029d9d289fa462dc68.jpg', NULL, 'jpg', 116459, NULL, '1', '2024-01-17 22:11:24', 1),
(74, 1939, 'post2.jpg', '73309892cc6ad5b701a7d3766d29e7a6.jpg', NULL, 'jpg', 389200, NULL, 'u', '2024-01-17 22:33:03', 1),
(75, 1939, 'post1.jpg', 'ab8c19d5dc848f789f80a8c239268615.jpg', NULL, 'jpg', 373978, NULL, 'b', '2024-01-17 22:36:18', 1),
(78, 1939, 'Screenshot 2023-11-24 090111.png', 'ba3e4ed5a5345fd87b32714a1637f51a.png', NULL, 'png', 172554, NULL, 'y', '2024-01-17 22:50:37', 1),
(80, 1963, 'post2-thumb.jpg', '881259fecb3abebc268a5ba6dd65d051.jpg', NULL, 'jpg', 62954, NULL, 'fdsaf', '2024-02-03 17:40:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_types`
--

DROP TABLE IF EXISTS `post_types`;
CREATE TABLE IF NOT EXISTS `post_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `enable` tinyint(1) DEFAULT NULL,
  `enable_images` tinyint(1) DEFAULT NULL,
  `enable_documents` tinyint(1) DEFAULT NULL,
  `enable_cover` tinyint(1) DEFAULT NULL,
  `enable_seo` tinyint(1) DEFAULT NULL,
  `enable_summary` tinyint(1) DEFAULT NULL,
  `enable_summary_one` tinyint(1) DEFAULT NULL,
  `enable_summary_two` tinyint(1) DEFAULT NULL,
  `enable_content` tinyint(1) DEFAULT NULL,
  `enable_content_one` tinyint(1) DEFAULT NULL,
  `enable_categories` tinyint(1) DEFAULT NULL,
  `enable_languages` tinyint(1) DEFAULT NULL,
  `enable_tags` tinyint(1) DEFAULT NULL,
  `layout` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enable_single_view` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_types`
--

INSERT INTO `post_types` (`id`, `code`, `name`, `enable`, `enable_images`, `enable_documents`, `enable_cover`, `enable_seo`, `enable_summary`, `enable_summary_one`, `enable_summary_two`, `enable_content`, `enable_content_one`, `enable_categories`, `enable_languages`, `enable_tags`, `layout`, `enable_single_view`) VALUES
(1, 'POST', 'Bài viết', 1, 0, 0, 1, 1, 1, NULL, NULL, 1, NULL, 1, 0, 1, NULL, 1),
(2, 'PRODUCT', 'Sản phẩm', 0, 1, 0, 1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'SLIDE', 'Slides', 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, NULL, NULL),
(4, 'PAGE', 'Trang tĩnh', 1, 0, 0, 0, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, 'page', NULL),
(5, 'SERVICE', 'Dịch vụ', 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, NULL, NULL),
(6, 'DOCUMENT', 'Tài liệu', 0, 0, 1, 0, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'GIATRI', 'Giá trị cốt lõi', 0, 0, 0, 1, 1, 1, NULL, NULL, 0, NULL, 0, 0, 0, NULL, NULL),
(9, 'PROJECT', 'Dự án', 1, 1, 0, 1, 1, 1, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site_logo` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_logo_small` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_copyright` text COLLATE utf8_unicode_ci NOT NULL,
  `site_source` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_hotline` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_copyright_en` text COLLATE utf8_unicode_ci,
  `site_source_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text_homepage` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `map` text COLLATE utf8_unicode_ci,
  `showcase_text` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_text_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_summary` text COLLATE utf8_unicode_ci,
  `showcase_summary_en` text COLLATE utf8_unicode_ci,
  `branches_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_summary` text COLLATE utf8_unicode_ci,
  `branches_summary_en` text COLLATE utf8_unicode_ci,
  `branches_page_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_seo_description` text COLLATE utf8_unicode_ci,
  `branches_fist_content` text COLLATE utf8_unicode_ci,
  `branches_fist_content_en` text COLLATE utf8_unicode_ci,
  `branches_fist_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_show_default` tinyint(1) DEFAULT NULL,
  `service_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_summary` text COLLATE utf8_unicode_ci,
  `service_summary_en` text COLLATE utf8_unicode_ci,
  `service_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_service_image` tinyint(1) DEFAULT NULL,
  `about_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_summary1` text COLLATE utf8_unicode_ci,
  `about_summary1_en` text COLLATE utf8_unicode_ci,
  `about_summary2` text COLLATE utf8_unicode_ci,
  `about_summary2_en` text COLLATE utf8_unicode_ci,
  `about_fact` text COLLATE utf8_unicode_ci,
  `about_fact_en` text COLLATE utf8_unicode_ci,
  `about_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_summary` text COLLATE utf8_unicode_ci,
  `about2_summary_en` text COLLATE utf8_unicode_ci,
  `about2_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_content` text COLLATE utf8_unicode_ci,
  `about3_content_en` text COLLATE utf8_unicode_ci,
  `contact_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_content` text COLLATE utf8_unicode_ci,
  `contact_content_en` text COLLATE utf8_unicode_ci,
  `show_index_block` tinyint(1) DEFAULT NULL,
  `site_index_block_1` text COLLATE utf8_unicode_ci,
  `site_index_block_2` text COLLATE utf8_unicode_ci,
  `site_index_block_1_en` text COLLATE utf8_unicode_ci,
  `site_index_block_2_en` text COLLATE utf8_unicode_ci,
  `site_index_bg_map` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_index_bg_blog` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_description` text COLLATE utf8_unicode_ci,
  `number_post_trending` tinyint(4) DEFAULT NULL,
  `number_post_catalog_home` tinyint(4) DEFAULT NULL,
  `number_post_per_page` tinyint(4) DEFAULT NULL,
  `number_post_like_in_news` tinyint(4) DEFAULT NULL,
  `show_cover_after_summary` tinyint(4) DEFAULT NULL,
  `sustainability_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_content` text COLLATE utf8_unicode_ci,
  `sustainability_content_en` text COLLATE utf8_unicode_ci,
  `sustainability_seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_logo`, `site_logo_small`, `site_copyright`, `site_source`, `top_text`, `top_email`, `top_hotline`, `site_copyright_en`, `site_source_en`, `top_text_en`, `text_homepage`, `map`, `showcase_text`, `showcase_text_en`, `showcase_title`, `showcase_title_en`, `showcase_summary`, `showcase_summary_en`, `branches_text`, `branches_text_en`, `branches_title`, `branches_title_en`, `branches_summary`, `branches_summary_en`, `branches_page_name`, `branches_page_name_en`, `branches_page_seo_title`, `branches_page_seo_description`, `branches_fist_content`, `branches_fist_content_en`, `branches_fist_image`, `branches_show_default`, `service_text`, `service_text_en`, `service_title`, `service_title_en`, `service_summary`, `service_summary_en`, `service_image`, `show_service_image`, `about_text`, `about_text_en`, `about_title`, `about_title_en`, `about_summary1`, `about_summary1_en`, `about_summary2`, `about_summary2_en`, `about_fact`, `about_fact_en`, `about_image`, `about2_title`, `about2_title_en`, `about2_summary`, `about2_summary_en`, `about2_image`, `about3_text`, `about3_text_en`, `about3_content`, `about3_content_en`, `contact_text`, `contact_text_en`, `contact_title`, `contact_title_en`, `contact_content`, `contact_content_en`, `show_index_block`, `site_index_block_1`, `site_index_block_2`, `site_index_block_1_en`, `site_index_block_2_en`, `site_index_bg_map`, `site_index_bg_blog`, `site_title`, `site_description`, `number_post_trending`, `number_post_catalog_home`, `number_post_per_page`, `number_post_like_in_news`, `show_cover_after_summary`, `sustainability_title`, `sustainability_title_en`, `sustainability_content`, `sustainability_content_en`, `sustainability_seo_title`, `sustainability_seo_description`) VALUES
(1, 'Apeiron Bioenergy', 'http://localhost:9999/images/posts/_default/logo%20(1).png', 'http://localhost:9999/images/posts/_default/favicon.png', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Giờ làm việc từ thứ Hai đến thứ Bảy : 6.00 am - 17.00 pm ', 'hung.nguyen@apeironbioenergy.com', '+84977240268', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Opening Hours: Mon - Tues : 6.00 am - 10.00 pm, Sunday Closed ', 'Trang chủ', 'Kho Bình Dương|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5723.825837906647!2d106.77691103005164!3d10.890222031753956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3174d75fb25e520d%3A0x869bfd7c0b43eca4!2sC%C3%B4ng%20ty%20TNHH%20APEIRON%20BIOENERGY%20(Vi%E1%BB%87t%20Nam)!5e0!3m2!1sen!2s!4v1681005437821!5m2!1sen!2s||Kho Cần Thơ|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3927.693039920593!2d105.687917!3d10.1241926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a0851a2a478199%3A0x18bd88ce74f3f82!2sKho%20C%E1%BA%A7n%20Th%C6%A1-%20C%C3%B4ng%20ty%20Apeiron%20Bioenergy%20(%20Viet%20Nam)!5e0!3m2!1sen!2s!4v1681006199837!5m2!1sen!2s||Kho Hà Nội|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3727.7535732850815!2d105.8643875!3d20.8819806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135b3ab78134ba1%3A0xb3a30b90ccd5f0e3!2sKho%20H%C3%A0%20N%E1%BB%99i-%20CTY%20TNHH%20APEIRON%20BIOENERGY%20(VI%E1%BB%86T%20NAM)!5e0!3m2!1sen!2s!4v1681007386542!5m2!1sen!2s', 'Nhà máy của chúng tôi', 'Showcase', 'Hình ảnh nhà máy của Apeiron Bioenergy tại Việt Nam', 'Image of Apeiron Bioenergy\'s factory in Vietnam', 'Công ty chúng tôi đầu tư các nhà máy với quy trình xử lý nghiêm ngặt, theo chuẩn của quốc tế và thân thiện với môi trường', 'Our company has a factory with a strict processing procedure that meets international standards and is environmentally friendly.', 'Văn phòng và Chi nhánh', 'Offices and Branches', 'Một viễn cảnh toàn cầu', 'A Global Perspective', 'Chúng tôi có trụ sở tại Singapore và hoạt động hai nhà máy lọc dầu cùng chín kho thu gom ở khắp châu Á. Sự mở rộng chiều dọc và tích hợp vào thị trường năng lượng sinh học đã giúp chúng tôi kiểm soát toàn bộ chuỗi cung ứng và cung cấp những giải pháp tốt hơn cho khách hàng.', 'Headquartered in Singapore, we operate two refineries and nine collection warehouses across Asia. Our vertical and horizontal expansion and integration into bioenergy markets has enabled us to gain better control over the entire supply chain, thereby providing more desirable solutions for our clients.', 'Chi Nhánh Toàn Cầu', 'Global Presence', '', '', '<h2>Trụ sở ch&iacute;nh</h2>\r\n<span style=\"font-size: 18pt;\">Singapore<br /><br /></span>\r\n<h2>Văn ph&ograve;ng chi nh&aacute;nh</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li class=\"list-item\"><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n</ol>', '<h2>Head Office</h2>\r\n<span style=\"font-size: 14pt;\">Singapore<br /><br /></span>\r\n<h2>Branch Offices</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n<li><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Cambodia</span></li>\r\n</ol>', 'https://apeironbioenergy.vn/images/posts/_services/map.png', 1, 'Sản phẩm của chúng tôi', 'Products', 'Nguồn nguyên liệu bền vững', 'The Source of Sustainable Feedstocks', 'Được tích hợp hoàn toàn vào toàn bộ chuỗi cung ứng, chúng tôi trực tiếp tìm  và thu gom chất thải trong các dự án thượng nguồn và có thể linh hoạt sử dụng chúng trong các dự án hạ nguồn của chúng tôi.\r\n\r\nCác sản phẩm của chúng tôi bao gồm dầu ăn đã qua sử dụng, nước thải của nhà máy sản  dầu cọ, metyl este từ dầu ăn đã qua sử dụng, glycerin thô và các sản phẩm khác.', 'Fully integrated into the entire supply chain, we directly source and collect wastes in upstream projects and have the flexibility to use them in our downstream projects.\r\n\r\nOur products include used cooking oil, palm oil mill effluent, used cooking oil methyl ester, crude glycerin, and other products.', 'https://apeironbioenergy.vn/images/posts/_services/2155d467c6451c1b4554.jpg', 0, 'Về chúng tôi', 'About Us', 'Công ty hàng đầu thế giới về năng lượng sinh học', 'Leading Global Player in Bioenergy', 'Apeiron Bioenergy là công ty toàn cầu tích hợp hàng đầu trong toàn bộ chuỗi sản phẩm năng lượng sinh học từ nguyên liệu đầu vào đến sản phẩm cuối cùng và phụ phẩm.', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 'Các hoạt động toàn cầu của chúng tôi bắt nguồn từ kiến thức và kinh nghiệm sâu rộng trong việc cải thiện chuỗi cung ứng, quản lý rủi ro và phân phối tập trung vào khách hàng để tạo ra một môi trường có giá trị và có lợi cho các nhà cung cấp và khách hàng của chúng tôi.', 'Our global operations stem from our extensive knowledge and experience in supply chain improvement, risk management, and client-focused distribution to create a valuable and profitable environment for our suppliers and customers.', 'Được thành lập vào năm 2007 với 15 năm hoạt động và thành tích tài chính. Chúng tôi đã giao hơn 500 triệu lít Dầu Đã Qua Sử Dụng (UCO) kể từ năm 2017.|Công ty dẫn đầu thị trường tại các thị trường xuất khẩu chính ở Châu Á.', 'Founded in 2007 with 15 years of operational and financial track record. We have delivered more than 500 million litres of UCO since 2017. |The market leader in key export markets in Asia.', 'https://apeironbioenergy.vn/images/posts/_about/2155d467c6451c1b4554.jpg', 'Tại sao phải tái chế dầu ăn đã qua sử dụng?', 'Why Recycle Used Cooking Oil?', '<p>Bạn có biết việc chuyển đổi từ dầu diesel xăng sang dầu diesel tái tạo làm bằng UCO dẫn đến lượng khí thải nhà kính thấp hơn 83% không? Bằng cách tái chế UCO, bạn đang góp phần tiết kiệm khí nhà kính và giúp bảo vệ trái đất của chúng ta thông qua nỗ lực phát triển bền vững của bạn.\r\n</p><p>\r\nViệc xử lý UCO không đúng cách làm tắc nghẽn nghiêm trọng hệ thống nước thải. Chỉ riêng San Francisco đã chi 3,5 triệu đô la hàng năm để thông cống rãnh chứa đầy chất béo, dầu và mỡ!</p>', '<p>Did you know switching from petroleum diesel to renewable diesel made of UCO results in more than 83% lower greenhouse gas emissions? By recycling UCO, you are contributing towards greenhouse gas savings and helping to preserve our earth through your sustainability effort.</p>\r\n<p>\r\nThe incorrect disposal of UCO severely clogs the sewage system. San Francisco alone spends $3.5 million annually to unclog sewers filled with fats, oils, and grease!</p>', 'https://apeironbioenergy.vn/images/posts/_about/about.jpg', 'Quy trình xử lý', 'Process', 'Lập kế hoạch chi tiết từ các nhóm quốc gia của chúng tôi với cộng đồng địa phương\r\n |Thu thập và giao cho các cơ sở thu gom và xử lý của chúng tôi\r\n  |Để yên, lọc và đun nóng để tách nước, cặn và dầu\r\n  |Cung cấp cho bể chứa trung tâm và xử lý nhiệt nhiều hơn\r\n  |Xuất khẩu đến các nhà máy lọc dầu diesel sinh học thông qua các tàu hàng rời', ' Detailed planning from our country teams with the local community\r\n |Collect and deliver to our collection and processing facilities\r\n |Rest, filter, and heat to separate water, residue, and oil\r\n |Deliver to central storage tanks and more heat treatment\r\n |Export to biodiesel refineries through bulk vessels', 'Liên hệ', 'Contact us', 'Xin vui lòng để lại thông tin bạn cần liên hệ', 'Feel Free To Contact Us', 'fa fa-map-marker|Địa chỉ|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email|hung.nguyen@apeironbioenergy.com||fa fa-phone|Gọi cho chúng tôi|+84977240268', 'fa fa-map-marker|Our Office|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email Us|hung.nguyen@apeironbioenergy.com||fa fa-envelope|fa fa-phone|+84977240268', 0, '<h3 class=\"text-white mb-3\">Giờ mở cửa</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 2 - Thứ 6</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 7</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Chủ nhật</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/contact\">Đặt lịch hẹn</a>', '<h3 class=\"text-white mb-3\">Li&ecirc;n hệ ngay</h3>\r\n<p class=\"text-white\">Bạn c&oacute; thể gọi đến số hotline của ch&uacute;ng t&ocirc;i để y&ecirc;u cầu dịch vụ hoặc cần li&ecirc;n hệ c&ocirc;ng việc</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', '<h3 class=\"text-white mb-3\">Opening Hours</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Mon - Fri</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Saturday</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Sunday</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/site/appointment\">Appointment</a>', '<h3 class=\"text-white mb-3\">Make Appointment</h3>\r\n<p class=\"text-white\">You can call our hotline to request service or need to contact work</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'Apeiron Bioenergy Vietnam', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 4, 5, 10, 5, 0, 'Giá Trị', 'Sustainability', '<h1>T&iacute;nh bền vững cốt l&otilde;i của ch&uacute;ng t&ocirc;i</h1>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom r&aacute;c thải với sứ mệnh bảo vệ m&ocirc;i trường, n&acirc;ng cao nhận thức v&agrave; đại diện cho lợi &iacute;ch của ng&agrave;nh năng lượng sinh học.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thực hiện c&aacute;c ti&ecirc;u ch&iacute; bền vững về x&atilde; hội v&agrave; sinh th&aacute;i nghi&ecirc;m ngặt trong quy tr&igrave;nh quản l&yacute; chuỗi cung ứng của m&igrave;nh. Qu&aacute; tr&igrave;nh n&agrave;y được kiểm tra thường xuy&ecirc;n v&agrave; c&aacute;c sản phẩm của ch&uacute;ng t&ocirc;i được chứng nhận với c&aacute;c ti&ecirc;u chuẩn bền vững như Chứng nhận Carbon &amp; Bền vững Quốc tế (ISCC) dầu mỏ.</p>\r\n<p>Th&ocirc;ng qua sự hợp t&aacute;c với c&aacute;c hộ gia đ&igrave;nh, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, nh&agrave; sản xuất thực phẩm địa phương, ch&uacute;ng t&ocirc;i n&acirc;ng cao nhận thức v&agrave; khuyến kh&iacute;ch việc xử l&yacute; r&aacute;c thải đ&uacute;ng c&aacute;ch.</p>\r\n<p>Đồng thời, ch&uacute;ng t&ocirc;i tạo cơ hội việc l&agrave;m cho c&aacute;c nền kinh tế địa phương th&ocirc;ng qua c&aacute;c hoạt động t&aacute;i chế.</p>\r\n<h1>T&aacute;c động của ch&uacute;ng t&ocirc;i về số lượng</h1>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image1.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image2.jpg\" alt=\"\" width=\"100%\" /></p>', '<h1 class=\"envionmnet-ttle\" data-w-id=\"23139613-11a9-b459-83dd-3d86c5ccdc8e\">Sustainability at Our Core<img class=\"environment-icon\" src=\"https://assets.website-files.com/622ecbb1fc363c1753ddeb5f/6230696327bb278eec2df55b_noun-green-city-1085044.svg\" alt=\"\" /></h1>\r\n<div class=\"enironmnet-content\">\r\n<div class=\"environmnet-text\">We collect wastes with the mission of protecting the environment, creating awareness, and representing the interests of the bioenergy industry.</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">We implement rigorous ecological and social sustainability criteria in our supply chain management process. This process is audited regularly and our products are certified with sustainability standards such as International Sustainability &amp; Carbon Certification (ISCC) .</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">Our business directly reduces the social costs of clogged sewage and reduced efficiency of wastewater treatment systems as a result of illegal disposal of used cooking oil.<br /><br />Through collaborations with local households, restaurants, hotels, food manufacturers, we create awareness and encourage the proper disposal of waste. At the same time, we create job opportunities for local economies through recycling activities.</div>\r\n<div class=\"environmnet-text\">&nbsp;</div>\r\n<div class=\"environmnet-text\">\r\n<h1 class=\"impact-title\" data-w-id=\"68f7fa92-83b1-c141-b7c7-897ff11d9b75\">Our Impact in Numbers</h1>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image1.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image2.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n</div>\r\n</div>', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
CREATE TABLE IF NOT EXISTS `socials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `name`, `icon`, `link`, `priority`) VALUES
(1, 'Facebook', '<span class=\"icon-facebook\"></span>', 'facebook.com', 2),
(2, 'Twitter', '<span class=\"icon-twitter\"></span>', 'twitter.com', 1),
(3, 'Instagram', '<span class=\"icon-instagram\"></span>', 'instagram.com', 1),
(4, 'Youtube', '<span class=\"icon-youtube-play\"></span>', 'youtube.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tag_list`
--

DROP TABLE IF EXISTS `tag_list`;
CREATE TABLE IF NOT EXISTS `tag_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tag_list`
--

INSERT INTO `tag_list` (`id`, `name`, `slug`, `date_created`, `user_created`, `seo_title`, `seo_description`) VALUES
(1, 'tag 1', 'tag-1', '2024-01-16 16:25:52', NULL, '', ''),
(2, 'tag 2', 'tag-2', '2024-01-16 16:25:52', NULL, NULL, NULL),
(3, 'tag 3', 'tag-3', '2024-01-16 16:32:55', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(1) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `id_phong` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`, `name`, `phone`, `address`, `id_phong`) VALUES
(1, 'superadmin@gmail.com', 'kz2px152FAWlkHbkZoCiXgBAd-S8SSjF', '$2y$13$DSISRUJSkr4CPeb3Ciwl1u3ubaGF50gXzzgTaDmpi5ph2Hie8JL9q', NULL, 1, 1, 1426062188, 1586049758, NULL, '', 'superadmin@gmail.com', 1, 'Mr. Admin 1', '374711908', 'Càng Long - Trà Vinh 1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `language` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(265, '65e53265bbd83', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709519461, 'Chrome', 'Windows'),
(266, '65e6eaa382839', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 1, 1709632163, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `view_contact`
--

DROP TABLE IF EXISTS `view_contact`;
CREATE TABLE IF NOT EXISTS `view_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  `services` tinyint(11) DEFAULT NULL,
  `viewed` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_contact`
--

INSERT INTO `view_contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `services`, `viewed`, `date_created`) VALUES
(12, 'Nguyễn Phương Thảo Nguyên', 'nguyenvantyan@gmail.com', '0374711908', '', 'fasdsfas', NULL, 0, '2024-02-24 15:38:33'),
(18, 'fasdfas', 'fasdf@gmail.com', '4444', '', 'fasdf', NULL, 0, '2024-02-24 16:19:08');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
